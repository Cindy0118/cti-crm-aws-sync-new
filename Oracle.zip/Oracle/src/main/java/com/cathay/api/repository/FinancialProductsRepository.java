package com.cathay.api.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cathay.api.domain.FinancialProducts;

public interface FinancialProductsRepository extends CrudRepository<FinancialProducts, String>{
	
	@Query(nativeQuery=true)
	FinancialProducts findByCustomerId(String customerId);
}

package com.cathay.api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "v_crm_party_info")
public class CustomerProfile {

	@Id
	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "customer_class_code")
	private String customerClassCode;

	@Column(name = "cc_vip_ind")
	private String ccVip;

	@JsonIgnore
	@Column(name = "is_aml_gov_ind")
	private String isAmlGovInd;

	@JsonIgnore
	@Column(name = "employee_ind")
	private String employeeInd;

	@JsonIgnore
	@Column(name = "cc_vip_1_ind")
	private String ccVip1Ind;

	@JsonIgnore
	@Column(name = "cub_manager_ind")
	private String cubManagerInd;

	@JsonInclude()
	@Transient
	private String specialIdentity;

	@JsonInclude()
	@Transient
	private String lastDateGreeted;

	public CustomerProfile() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerClassCode() {
		return customerClassCode;
	}

	public void setCustomerClassCode(String customerClassCode) {
		this.customerClassCode = customerClassCode;
	}

	public String getCcVip() {
		return ccVip;
	}

	public void setCcVip(String ccVip) {
		this.ccVip = ccVip;
	}

	public String getIsAmlGovInd() {
		return isAmlGovInd;
	}

	public void setIsAmlGovInd(String isAmlGovInd) {
		this.isAmlGovInd = isAmlGovInd;
	}

	public String getEmployeeInd() {
		return employeeInd;
	}

	public void setEmployeeInd(String employeeInd) {
		this.employeeInd = employeeInd;
	}

	public String getCcVip1Ind() {
		return ccVip1Ind;
	}

	public void setCcVip1Ind(String ccVip1Ind) {
		this.ccVip1Ind = ccVip1Ind;
	}

	public String getCubManagerInd() {
		return cubManagerInd;
	}

	public void setCubManagerInd(String cubManagerInd) {
		this.cubManagerInd = cubManagerInd;
	}

	public String getSpecialIdentity() {
		specialIdentity = null;

		if (ccVip1Ind != null && ccVip1Ind.equalsIgnoreCase("Y")) {
			specialIdentity = "CC_VIP_1_IND";
		} else if (cubManagerInd != null && cubManagerInd.equalsIgnoreCase("Y")) {
			specialIdentity = "CUB_MANAGER_IND";
		} else if (employeeInd != null && employeeInd.equalsIgnoreCase("Y")) {
			specialIdentity = "EMPLOYEE_IND";
		} else if (isAmlGovInd != null && isAmlGovInd.equalsIgnoreCase("Y")) {
			specialIdentity = "IS_AML_GOV_IND";
		}

		return specialIdentity;
	}

	public void setSpecialIdentity(String specialIdentity) {
		this.specialIdentity = specialIdentity;
	}

	public String getLastDateGreeted() {
		return lastDateGreeted;
	}

	public void setLastDateGreeted(String lastDateGreeted) {
		this.lastDateGreeted = lastDateGreeted;
	}

	@Override
	public String toString() {
		return new StringBuilder("{customerId=" + customerId + ", customerName=" + customerName + ", customerClassCode="
				+ customerClassCode + ", ccVip=" + ccVip + ", isAmlGovInd=" + isAmlGovInd + ", employeeInd="
				+ employeeInd + ", ccVip1Ind=" + ccVip1Ind + ", cubManagerInd=" + cubManagerInd + ", specialIdentity="
				+ getSpecialIdentity() + ", lastDateGreeted=" + lastDateGreeted + "}").toString();
	}

}
package com.cathay.api.domain;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class StoreRecommendationRequest {

	@Valid
	private Header header;

	@NotBlank
	private String customerId;

	private String customerName;

	@NotBlank
	private String productName;

	@Size(max = 1)
	private String customerTag;

	@NotBlank
	private String refResult;

	private String refMethod;

	private String refSource;

	@Size(max = 5)
	private String obEmployeeNo;

	private String obEmployeeLastName;

	@NotBlank
	private String refDate;

	@NotBlank
	private String refTime;

	@NotBlank
	private String trustKey;

	public StoreRecommendationRequest() {
		super();
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public Header getHeader() {
		return header;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductName() {
		return productName;
	}

	public void setCustomerTag(String customerTag) {
		this.customerTag = customerTag;
	}

	public String getCustomerTag() {
		return customerTag;
	}

	public void setRefResult(String refResult) {
		this.refResult = refResult;
	}

	public String getRefResult() {
		return refResult;
	}

	public void setRefMethod(String refMethod) {
		this.refMethod = refMethod;
	}

	public String getRefMethod() {
		return refMethod;
	}

	public void setRefSource(String refSource) {
		this.refSource = refSource;
	}

	public String getRefSource() {
		return refSource;
	}

	public void setObEmployeeNo(String obEmployeeNo) {
		this.obEmployeeNo = obEmployeeNo;
	}

	public String getObEmployeeNo() {
		return obEmployeeNo;
	}

	public void setObEmployeeLastName(String obEmployeeLastName) {
		this.obEmployeeLastName = obEmployeeLastName;
	}

	public String getObEmployeeLastName() {
		return obEmployeeLastName;
	}

	public void setRefDate(String refDate) {
		this.refDate = refDate;
	}

	public String getRefDate() {
		return refDate;
	}

	public void setRefTime(String refTime) {
		this.refTime = refTime;
	}

	public String getRefTime() {
		return refTime;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + ", customerId=" + customerId + ", customerName=" + customerName
				+ ", productName=" + productName + ", customerTag=" + customerTag + ", refResult=" + refResult
				+ ", refMethod=" + refMethod + ", refSource=" + refSource + ", obEmployeeNo=" + obEmployeeNo
				+ ", obEmployeeLastName=" + obEmployeeLastName + ", refDate=" + refDate + ", refTime=" + refTime
				+ ", trustKey=" + trustKey + "}").toString();
	}

}

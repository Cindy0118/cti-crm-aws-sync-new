package com.cathay.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cathay.api.domain.PaymentHabitsRecords;

public interface PaymentHabitsRepository extends CrudRepository<PaymentHabitsRecords, String>{
	
	@Query(value = "SELECT * FROM crm_event_cc_stmt_pay WHERE customer_id = :customerId ORDER BY txn_date DESC", nativeQuery = true)
	List<PaymentHabitsRecords> findByCustomerId(@Param(value = "customerId") String customerId);
	
}

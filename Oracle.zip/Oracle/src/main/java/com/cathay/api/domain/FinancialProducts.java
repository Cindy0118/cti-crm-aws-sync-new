package com.cathay.api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "v_crm_party_info")
public class FinancialProducts {

	@Id
	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "cub_primary_cc_card_cnt")
	private Integer primaryCcCount;

	@Column(name = "cub_secondary_cc_card_cnt")
	private Integer secondaryCcCount;

	@Column(name = "business_cc_card_cnt")
	private Integer businessCcCount;

	@Column(name = "primary_has_second_cc_cnt")
	private Integer primarySecondCcCount;

	@Column(name = "cc_stmt_auto_deduct_ind")
	private String ccStmtAutoDeductInd;

	@Column(name = "cc_public_auto_deduct_ind")
	private String ccPubAutoDeductInd;

	@Column(name = "all_dp_active_ind")
	private String allDpActiveInd;

	@Column(name = "house_loan_ind")
	private String houseLoanInd;

	@Column(name = "credit_loan_ind")
	private String creditLoanInd;

	@Column(name = "mf_ind")
	private String mfInd;

	@Column(name = "str_ind")
	private String strInd;

	@Column(name = "ins_agent_pty_ind")
	private String insAgentPtyInd;

	@Column(name = "ins_agent_life_ind")
	private String insAgentLifeInd;

	@Column(name = "autopay_fail_cnt")
	private Integer autoPayFailCnt;

	@Column(name = "autopay_rmb_fail_cnt")
	private Integer autoPayRmbFailCnt;

	@Column(name = "autopay_usa_fail_cnt")
	private Integer autoPayUsaFailCnt;

	@Column(name = "general_next_mon_expire_ps")
	private Integer generalNextMonExpirePs;

	@Column(name = "platinum_next_mon_expire_ps")
	private Integer platinumNextMonExpirePs;

	@Column(name = "cleared_costco_bonus_bal")
	private Double clearedCostcoBonusBal;

	@Column(name = "y1_asian_expire_miles")
	private Double y1AsianExpireMiles;

	@Column(name = "l3times_cc_pay_method_desc")
	private String l3TimesCcPayMethodDesc;

	@Column(name = "l3times_cc_pay_rate_desc")
	private String l3TimesCcPayRateDesc;

	@Column(name = "y1_eva_expire_miles")
	private Integer y1EvaExpireMiles;

	public FinancialProducts() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Integer getPrimaryCcCount() {
		return primaryCcCount;
	}

	public void setPrimaryCcCount(Integer primaryCcCount) {
		this.primaryCcCount = primaryCcCount;
	}

	public Integer getSecondaryCcCount() {
		return secondaryCcCount;
	}

	public void setSecondaryCcCount(Integer secondaryCcCount) {
		this.secondaryCcCount = secondaryCcCount;
	}

	public Integer getBusinessCcCount() {
		return businessCcCount;
	}

	public void setBusinessCcCount(Integer businessCcCount) {
		this.businessCcCount = businessCcCount;
	}

	public Integer getPrimarySecondCcCount() {
		return primarySecondCcCount;
	}

	public void setPrimarySecondCcCount(Integer primarySecondCcCount) {
		this.primarySecondCcCount = primarySecondCcCount;
	}

	public String getCcStmtAutoDeductInd() {
		return ccStmtAutoDeductInd;
	}

	public void setCcStmtAutoDeductInd(String ccStmtAutoDeductInd) {
		this.ccStmtAutoDeductInd = ccStmtAutoDeductInd;
	}

	public String getCcPubAutoDeductInd() {
		return ccPubAutoDeductInd;
	}

	public void setCcPubAutoDeductInd(String ccPubAutoDeductInd) {
		this.ccPubAutoDeductInd = ccPubAutoDeductInd;
	}

	public String getAllDpActiveInd() {
		return allDpActiveInd;
	}

	public void setAllDpActiveInd(String allDpActiveInd) {
		this.allDpActiveInd = allDpActiveInd;
	}

	public String getHouseLoanInd() {
		return houseLoanInd;
	}

	public void setHouseLoanInd(String houseLoanInd) {
		this.houseLoanInd = houseLoanInd;
	}

	public String getCreditLoanInd() {
		return creditLoanInd;
	}

	public void setCreditLoanInd(String creditLoanInd) {
		this.creditLoanInd = creditLoanInd;
	}

	public String getMfInd() {
		return mfInd;
	}

	public void setMfInd(String mfInd) {
		this.mfInd = mfInd;
	}

	public String getStrInd() {
		return strInd;
	}

	public void setStrInd(String strInd) {
		this.strInd = strInd;
	}

	public String getInsAgentPtyInd() {
		return insAgentPtyInd;
	}

	public void setInsAgentPtyInd(String insAgentPtyInd) {
		this.insAgentPtyInd = insAgentPtyInd;
	}

	public String getInsAgentLifeInd() {
		return insAgentLifeInd;
	}

	public void setInsAgentLifeInd(String insAgentLifeInd) {
		this.insAgentLifeInd = insAgentLifeInd;
	}

	public Integer getAutoPayFailCnt() {
		return autoPayFailCnt;
	}

	public void setAutoPayFailCnt(Integer autoPayFailCnt) {
		this.autoPayFailCnt = autoPayFailCnt;
	}

	public Integer getAutoPayRmbFailCnt() {
		return autoPayRmbFailCnt;
	}

	public void setAutoPayRmbFailCnt(Integer autoPayRmbFailCnt) {
		this.autoPayRmbFailCnt = autoPayRmbFailCnt;
	}

	public Integer getAutoPayUsaFailCnt() {
		return autoPayUsaFailCnt;
	}

	public void setAutoPayUsaFailCnt(Integer autoPayUsaFailCnt) {
		this.autoPayUsaFailCnt = autoPayUsaFailCnt;
	}

	public Integer getGeneralNextMonExpirePs() {
		return generalNextMonExpirePs;
	}

	public void setGeneralNextMonExpirePs(Integer generalNextMonExpirePs) {
		this.generalNextMonExpirePs = generalNextMonExpirePs;
	}

	public Integer getPlatinumNextMonExpirePs() {
		return platinumNextMonExpirePs;
	}

	public void setPlatinumNextMonExpirePs(Integer platinumNextMonExpirePs) {
		this.platinumNextMonExpirePs = platinumNextMonExpirePs;
	}

	public Double getClearedCostcoBonusBal() {
		return clearedCostcoBonusBal;
	}

	public void setClearedCostcoBonusBal(Double clearedCostcoBonusBal) {
		this.clearedCostcoBonusBal = clearedCostcoBonusBal;
	}

	public Double getY1AsianExpireMiles() {
		return y1AsianExpireMiles;
	}

	public void setY1AsianExpireMiles(Double y1AsianExpireMiles) {
		this.y1AsianExpireMiles = y1AsianExpireMiles;
	}

	public String getL3TimesCcPayMethodDesc() {
		return l3TimesCcPayMethodDesc;
	}

	public void setL3TimesCcPayMethodDesc(String l3TimesCcPayMethodDesc) {
		this.l3TimesCcPayMethodDesc = l3TimesCcPayMethodDesc;
	}

	public String getL3TimesCcPayRateDesc() {
		return l3TimesCcPayRateDesc;
	}

	public void setL3TimesCcPayRateDesc(String l3TimesCcPayRateDesc) {
		this.l3TimesCcPayRateDesc = l3TimesCcPayRateDesc;
	}

	public Integer getY1EvaExpireMiles() {
		return y1EvaExpireMiles;
	}

	public void setY1EvaExpireMiles(Integer y1EvaExpireMiles) {
		this.y1EvaExpireMiles = y1EvaExpireMiles;
	}

	@Override
	public String toString() {
		return new StringBuilder("{customerId=" + customerId + ", primaryCcCount=" + primaryCcCount
				+ ", secondaryCcCount=" + secondaryCcCount + ", businessCcCount=" + businessCcCount
				+ ", primarySecondCcCount=" + primarySecondCcCount + ", ccStmtAutoDeductInd=" + ccStmtAutoDeductInd
				+ ", ccPubAutoDeductInd=" + ccPubAutoDeductInd + ", allDpActiveInd=" + allDpActiveInd
				+ ", houseLoanInd=" + houseLoanInd + ", creditLoanInd=" + creditLoanInd + ", mfInd=" + mfInd
				+ ", strInd=" + strInd + ", insAgentPtyInd=" + insAgentPtyInd + ", insAgentLifeInd=" + insAgentLifeInd
				+ ", autoPayFailCnt=" + autoPayFailCnt + ", autoPayRmbFailCnt=" + autoPayRmbFailCnt
				+ ", autoPayUsaFailCnt=" + autoPayUsaFailCnt + ", generalNextMonExpirePs=" + generalNextMonExpirePs
				+ ", platinumNextMonExpirePs=" + platinumNextMonExpirePs + ", clearedCostcoBonusBal="
				+ clearedCostcoBonusBal + ", y1AsianExpireMiles=" + y1AsianExpireMiles + ", l3TimesCcPayMethodDesc="
				+ l3TimesCcPayMethodDesc + ", l3TimesCcPayRateDesc=" + l3TimesCcPayRateDesc + ", y1EvaExpireMiles="
				+ y1EvaExpireMiles + "}").toString();
	}

}

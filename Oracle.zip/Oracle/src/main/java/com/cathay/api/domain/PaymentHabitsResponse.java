package com.cathay.api.domain;

import java.sql.Date;

public class PaymentHabitsResponse {

	private String stmtYearMonth;
	private Date txnDate;
	private String payChannelTypeDesc;
	private double payAmt;

	public PaymentHabitsResponse() {
	}

	public PaymentHabitsResponse(String stmtYearMonth, Date txnDate, String payChannelTypeDesc, double payAmt) {
		this.stmtYearMonth = stmtYearMonth;
		this.txnDate = txnDate;
		this.payChannelTypeDesc = payChannelTypeDesc;
		this.payAmt = payAmt;
	}

	public void setStmtYearMonth(String stmtYearMonth) {
		this.stmtYearMonth = stmtYearMonth;
	}

	public String getStmtYearMonth() {
		return stmtYearMonth;
	}

	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}

	public Date getTxnDate() {
		return txnDate;
	}

	public void setPayChannelTypeDesc(String payChannelTypeDesc) {
		this.payChannelTypeDesc = payChannelTypeDesc;
	}

	public String getPayChannelTypeDesc() {
		return payChannelTypeDesc;
	}

	public void setPayAmt(double payAmt) {
		this.payAmt = payAmt;
	}

	public double getPayAmt() {
		return payAmt;
	}

	@Override
	public String toString() {
		return new StringBuilder("{stmtYearMonth=" + stmtYearMonth + ", txnDate=" + txnDate + ", payChannelTypeDesc="
				+ payChannelTypeDesc + ", payAmt=" + payAmt + "}").toString();
	}

}

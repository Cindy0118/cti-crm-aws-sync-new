package com.cathay.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cathay.api.domain.CardsRecords;

public interface CardsRepository extends CrudRepository<CardsRecords, String> {

	/* PRIMARY CARDS */
	@Query(value = "SELECT * FROM v_crm_acct_cc WHERE customer_id = :customerId "
			+ "AND card_type_code < 900 AND card_type_code NOT IN('720','620','395','695','795') "
			+ "AND cardholder_cust_id = customer_id " + "AND primary_card_ind = 'Y'", nativeQuery = true)
	List<CardsRecords> findPrimaryCards(@Param(value = "customerId") String customerId);

	/* SECONDARY CARDS */
	@Query(value = "SELECT * FROM v_crm_acct_cc WHERE cardholder_cust_id = :customerId "
			+ "AND card_type_code < 900 AND card_type_code NOT IN('720','620','395','695','795') "
			+ "AND cardholder_cust_id <> customer_id " + "AND primary_card_ind = 'N'", nativeQuery = true)
	List<CardsRecords> findSecondaryCards(@Param(value = "customerId") String customerId);

	/* BUSINESS CARDS */
	@Query(value = "SELECT * FROM v_crm_acct_cc WHERE SUBSTR(customer_id, 1, 10) = SUBSTR(cardholder_cust_id, 1, 10) "
			+ "AND SUBSTR(cardholder_cust_id, 1, 10) = :customerId "
			+ "AND card_type_code < 900 AND card_type_code IN('395','695','795')", nativeQuery = true)
	List<CardsRecords> findBusinessCards(@Param(value = "customerId") String customerId);

	/* PRIMARY HAS SECONDAY CARDS */
	@Query(value = "SELECT * FROM v_crm_acct_cc WHERE customer_id = :customerId "
			+ "AND card_type_code < 900 AND card_type_code NOT IN('720','620','395','695','795') "
			+ "AND cardholder_cust_id <> customer_id ", nativeQuery = true)
	List<CardsRecords> findPrimaryHasSecondaryCards(@Param(value = "customerId") String customerId);

}

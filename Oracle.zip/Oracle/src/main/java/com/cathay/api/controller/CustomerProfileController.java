package com.cathay.api.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cathay.api.domain.CommonRequest;
import com.cathay.api.domain.CommonResponse;
import com.cathay.api.domain.Constants;
import com.cathay.api.domain.CustomerGreetings;
import com.cathay.api.domain.CustomerGreetingsRequest;
import com.cathay.api.domain.ValidateTrustKeyResponse;
import com.cathay.api.service.CustomerProfileService;
import com.cathay.api.service.TrustKeyService;

@CrossOrigin
@RestController
public class CustomerProfileController {

	private static final Logger LOGGER = LogManager.getLogger(CustomerProfileController.class);

	@Autowired
	TrustKeyService trustKeyService;

	@Autowired
	CustomerProfileService customerProfileService;

	@PostMapping("${mapping.get-customer-profile}")
	public CommonResponse getCustomerProfile(@RequestBody @Valid CommonRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.CUSTOMER_PROFILE_REQUEST, request);
		CommonResponse response = null;

		ValidateTrustKeyResponse responseBodyValidateTrustKey = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (responseBodyValidateTrustKey.getCode().equals(Constants.SUCCESS_CODE)) {
			response = customerProfileService.getCustomerProfile(request.getCustomerId());
		} else {
			response = new CommonResponse(responseBodyValidateTrustKey.getCode(), Constants.ERROR_MESSAGE,
					responseBodyValidateTrustKey.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.CUSTOMER_PROFILE_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${mapping.customer-greetings}")
	public CommonResponse customerGreetings(@RequestBody @Valid CustomerGreetingsRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.CUSTOMER_GREETINGS_REQUEST, request);
		CommonResponse response = null;

		ValidateTrustKeyResponse responseBodyValidateTrustKey = trustKeyService
				.validateTrustKey(request.getHeader(), request.getTrustKey());

		if (responseBodyValidateTrustKey.getCode().equals(Constants.SUCCESS_CODE)) {
			response = customerProfileService.customerGreetings(new CustomerGreetings(request));
		} else {
			response = new CommonResponse(responseBodyValidateTrustKey.getCode(), Constants.ERROR_MESSAGE,
					responseBodyValidateTrustKey.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.CUSTOMER_GREETINGS_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

}

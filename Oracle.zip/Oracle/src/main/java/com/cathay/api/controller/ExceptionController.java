package com.cathay.api.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.cathay.api.domain.CommonResponse;
import com.cathay.api.domain.Constants;

@ControllerAdvice
@RestController
public class ExceptionController extends ResponseEntityExceptionHandler {

	private static final Logger _LOGGER = LogManager.getLogger(ExceptionController.class);

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		_LOGGER.error(Constants.BAD_REQUEST, ex);
		CommonResponse response = new CommonResponse(String.valueOf(status.value()), Constants.ERROR_MESSAGE,
				getInvalidArguments(ex.getBindingResult()), Constants.SOURCE);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		_LOGGER.error(Constants.TYPE_MISMATCH_ERROR, ex);
		CommonResponse response = new CommonResponse(String.valueOf(status.value()), Constants.ERROR_MESSAGE,
				Constants.TYPE_MISMATCH_ERROR, Constants.SOURCE);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	private String getInvalidArguments(BindingResult result) {
		StringBuilder builder = new StringBuilder();
		List<FieldError> errors = result.getFieldErrors();
		builder.append("Invalid Argument or Request parameters {");
		for (FieldError error : errors) {
			builder.append("  " + error.getField() + ": " + error.getDefaultMessage() + "  ");
		}
		builder.append("}");
		return builder.toString();
	}

}

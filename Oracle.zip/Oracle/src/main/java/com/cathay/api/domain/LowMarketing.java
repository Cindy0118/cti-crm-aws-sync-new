package com.cathay.api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "v_crm_party_info")
public class LowMarketing {

	@Id
	@JsonIgnore
	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "low_marketing_ind")
	private String lowMarketingInd;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getLowMarketingInd() {
		return lowMarketingInd;
	}

	public void setLowMarketingInd(String lowMarketingInd) {
		this.lowMarketingInd = lowMarketingInd;
	}

	@Override
	public String toString() {
		return new StringBuilder("{customerId=" + customerId + ", lowMarketingInd=" + lowMarketingInd + "}").toString();
	}

}

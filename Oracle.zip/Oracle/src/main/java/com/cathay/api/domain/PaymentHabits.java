package com.cathay.api.domain;

import java.util.List;

public class PaymentHabits {

	private String customerId;
	private int recordNum;
	private List<PaymentHabitsResponse> records;

	public PaymentHabits(String customerId, int recordNum, List<PaymentHabitsResponse> records) {
		this.customerId = customerId;
		this.recordNum = recordNum;
		this.records = records;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setRecordNum(int recordNum) {
		this.recordNum = recordNum;
	}

	public int getRecordNum() {
		return recordNum;
	}

	public void setRecords(List<PaymentHabitsResponse> records) {
		this.records = records;
	}

	public List<PaymentHabitsResponse> getRecords() {
		return records;
	}

	@Override
	public String toString() {
		return "PaymentHabits [customerId=" + customerId + ", recordNum=" + recordNum + ", records=" + records + "]";
	}

}

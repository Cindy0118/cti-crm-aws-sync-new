package com.cathay.api.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.cathay.api.domain.CommonResponse;
import com.cathay.api.domain.Constants;
import com.cathay.api.domain.LowMarketing;
import com.cathay.api.domain.ProductRecommendation;
import com.cathay.api.domain.ProductSalesPitch;
import com.cathay.api.repository.LowMarketingRepository;
import com.cathay.api.repository.ProductRecommendationRepository;
import com.cathay.api.repository.ProductSalesPitchRepository;

@Service
public class ProductRecommendationService {

	private static final Logger LOGGER = LogManager.getLogger(ProductRecommendationService.class);

	@Autowired
	ProductRecommendationRepository productRecommendationRepository;

	@Autowired
	ProductSalesPitchRepository productSalesPitchRepository;

	@Autowired
	LowMarketingRepository lowMarketingRepository;

	@Value("${start.date}")
	private String startDateConfig;

	@Value("${end.date}")
	private String endDateConfig;

	public CommonResponse storeRecommendation(ProductRecommendation productRecommendation) {
		CommonResponse response = null;

		try {
			ProductRecommendation returnedProductRecommendation = productRecommendationRepository
					.save(productRecommendation);

			if (returnedProductRecommendation != null) {
				response = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE);
			} else {
				response = new CommonResponse(Constants.INSERT_ERROR_CODE, Constants.ERROR_MESSAGE,
						Constants.PRODUCT_RECOMMENDATION_SAVE_UNSUCCESSFUL, Constants.SOURCE);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

	public CommonResponse retrieveProductPitch(String pitchClassify) {
		CommonResponse response = null;

		try {
			ProductSalesPitch productSalesPitch = (pitchClassify.equals(Constants.PLOAN) && isPLoanTaxSeason())
					? productSalesPitchRepository.findByPitchClassifyAndStartDateNotNullAndEndDateNotNull(pitchClassify)
					: productSalesPitchRepository.findByPitchClassifyAndStartDateIsNullAndEndDateIsNull(pitchClassify);

			if (productSalesPitch != null) {
				response = new CommonResponse(productSalesPitch);
			} else {
				response = new CommonResponse(Constants.NO_DATA_CODE, Constants.ERROR_MESSAGE, Constants.NO_DATA_ERROR,
						Constants.SOURCE);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

	public CommonResponse getLowMarketing(String customerId) {
		CommonResponse response = null;

		try {
			LowMarketing lowMarketing = lowMarketingRepository.findByCustomerId(customerId);

			if (lowMarketing != null) {
				response = new CommonResponse(lowMarketing);
			} else {
				response = new CommonResponse(Constants.NO_DATA_CODE, Constants.ERROR_MESSAGE, Constants.NO_DATA_ERROR,
						Constants.SOURCE);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

	private boolean isPLoanTaxSeason() {
		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat dfYear = new SimpleDateFormat("yyyy");

		Date dateToday = new Date();
		Date startDate = null;
		Date endDate = null;

		try {
			dateToday = df.parse(df.format(dateToday));
			String year = dfYear.format(dateToday);
			startDate = df.parse(new StringBuilder(startDateConfig + year).toString());
			endDate = df.parse(new StringBuilder(endDateConfig + year).toString());
		} catch (ParseException e) {
			LOGGER.error(e);
		}

		return dateToday.after(startDate) && dateToday.before(endDate);
	}

}

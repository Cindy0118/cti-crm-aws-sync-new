package com.cathay.api.domain;

import java.util.List;

public class Savings {

	private String customerId;
	private int recordNum;
	private List<SavingsRecords> records;

	public Savings(String customerId, int recordNum, List<SavingsRecords> records) {
		this.customerId = customerId;
		this.recordNum = recordNum;
		this.records = records;
	}

	public String getCustomerId() {
		return customerId;
	}

	public int getRecordNum() {
		return recordNum;
	}

	public List<SavingsRecords> getRecords() {
		return records;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public void setRecordNum(int recordNum) {
		this.recordNum = recordNum;
	}

	public void setRecords(List<SavingsRecords> records) {
		this.records = records;
	}

	@Override
	public String toString() {
		return new StringBuilder(
				"{customerId=" + customerId + ", recordNum=" + recordNum + ", records=" + records + "}").toString();
	}
}

package com.cathay.api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "v_crm_acct_dp")
public class SavingsRecords {
	
	@JsonIgnore
	@Column(name = "customer_id")
	private String customerId;
	
	@JsonIgnore
	@Column(name = "acct_nbr")
	private String acctNbr;
	
	@Id
	@Column(name = "product_id_desc")
	private String productDesc;
	
	public SavingsRecords() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAcctNbr() {
		return acctNbr;
	}

	public void setAcctNbr(String acctNbr) {
		this.acctNbr = acctNbr;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	@Override
	public String toString() {
		return "SavingsRecords [customerId=" + customerId + ", acctNbr=" + acctNbr + ", productDesc=" + productDesc
				+ "]";
	}

}

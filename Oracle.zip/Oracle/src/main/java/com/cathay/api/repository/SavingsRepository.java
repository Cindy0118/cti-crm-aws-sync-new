package com.cathay.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cathay.api.domain.SavingsRecords;

public interface SavingsRepository extends CrudRepository<SavingsRecords, String>{

	@Query(value = "SELECT product_id_desc, :customerId customer_id, 1 acct_nbr FROM crm_acct_dp "
			+ "WHERE customer_id = :customerId GROUP BY product_id_desc", 
			nativeQuery = true)
	List<SavingsRecords> findByCustomerId(@Param(value = "customerId") String customerId);
}

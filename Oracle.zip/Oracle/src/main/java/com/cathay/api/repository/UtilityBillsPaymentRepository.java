package com.cathay.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cathay.api.domain.UtilityBillsPaymentsRecords;

public interface UtilityBillsPaymentRepository extends CrudRepository<UtilityBillsPaymentsRecords, String>{
	
	@Query(nativeQuery = true)
	List<UtilityBillsPaymentsRecords> findByCustomerId(@Param(value = "customerId") String customerId);

}

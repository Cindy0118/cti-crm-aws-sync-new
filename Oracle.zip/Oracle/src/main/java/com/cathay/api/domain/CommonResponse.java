package com.cathay.api.domain;

public class CommonResponse {

	private String code;
	private String message;
	private String description;
	private String source;
	private Object result;

	public CommonResponse() {
		super();
	}

	public CommonResponse(String code, String message) {
		super();
		this.code = code;
		this.message = message;
		this.description = "";
		this.source = "";
	}

	public CommonResponse(String code, String message, String description, String source) {
		super();
		this.code = code;
		this.message = message;
		this.description = description;
		this.source = source;
	}

	public CommonResponse(String code, String message, CustomerProfile customerProfile) {
		super();
		this.code = code;
		this.message = message;
		description = "";
		source = "";
		result = customerProfile;
	}

	public CommonResponse(String code, String message, FinancialProducts financialProducts) {
		super();
		this.code = code;
		this.message = message;
		description = "";
		source = "";
		result = financialProducts;
	}
	
	public CommonResponse(String code, String message, Cards cardRecords) {
		super();
		this.code = code;
		this.message = message;
		this.description = "";
		this.source = "";
		this.result = cardRecords;
	}
	
	public CommonResponse(String code, String message, PaymentHabits paymentRecords) {
		super();
		this.code = code;
		this.message = message;
		this.description = "";
		this.source = "";
		this.result = paymentRecords;
	}
	
	public CommonResponse(String code, String message, AutoAccountDebiting autoAccountDebitingRecords) {
		super();
		this.code = code;
		this.message = message;
		this.description = "";
		this.source = "";
		this.result = autoAccountDebitingRecords;
	}
	
	public CommonResponse(String code, String message, UtilityBillsPayments utilityBillsPaymentsRecords) {
		super();
		this.code = code;
		this.message = message;
		this.description = "";
		this.source = "";
		this.result = utilityBillsPaymentsRecords;
	}
	
	public CommonResponse(String code, String message, Savings savingsRecords) {
		super();
		this.code = code;
		this.message = message;
		this.description = "";
		this.source = "";
		this.result = savingsRecords;
	}

	public CommonResponse(ProductSalesPitch productSalesPitch) {
		super();
		code = Constants.SUCCESS_CODE;
		message = Constants.SUCCESS_MESSAGE;
		description = "";
		source = "";
		result = productSalesPitch;
	}
	
	public CommonResponse(TransactionSequence transactionSequence) {
		super();
		code = Constants.SUCCESS_CODE;
		message = Constants.SUCCESS_MESSAGE;
		description = "";
		source = "";
		result = transactionSequence;
	}
	
	public CommonResponse(LowMarketing lowMarketing) {
		super();
		code = Constants.SUCCESS_CODE;
		message = Constants.SUCCESS_MESSAGE;
		description = "";
		source = "";
		result = lowMarketing;
	}
	
	public CommonResponse(GiftDetails giftDetails) {
		super();
		code = Constants.SUCCESS_CODE;
		message = Constants.SUCCESS_MESSAGE;
		description = "";
		source = "";
		result = giftDetails;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	@Override
	public String toString() {
		String tempResult = null;

		if (result != null) {
			if (result instanceof CustomerProfile) {
				tempResult = ((CustomerProfile) result).toString();
			} else if(result instanceof FinancialProducts) {
				tempResult = ((FinancialProducts) result).toString();
			} else if(result instanceof Cards) {
				tempResult = ((Cards) result).toString();
			} else if(result instanceof PaymentHabits) {
				tempResult = ((PaymentHabits) result).toString();
			} else if(result instanceof AutoAccountDebiting) {
				tempResult = ((AutoAccountDebiting) result).toString();
			} else if(result instanceof UtilityBillsPayments) {
				tempResult = ((UtilityBillsPayments) result).toString();
			} else if(result instanceof Savings) {
				tempResult = ((Savings) result).toString();
			}
		}

		return new StringBuilder("{code=" + code + ", message=" + message + ", description=" + description + ", source="
				+ source + ", result=" + tempResult + "}").toString();
	}

}

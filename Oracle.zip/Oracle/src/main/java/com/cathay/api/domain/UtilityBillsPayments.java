package com.cathay.api.domain;

import java.util.List;

public class UtilityBillsPayments {

	private String customerId;
	private int recordNum;
	private List<UtilityBillsPaymentsRecords> records;

	public UtilityBillsPayments(String customerId, int recordNum, List<UtilityBillsPaymentsRecords> records) {
		this.customerId = customerId;
		this.recordNum = recordNum;
		this.records = records;
	}

	public void setRecords(List<UtilityBillsPaymentsRecords> records) {
		this.records = records;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public int getRecordNum() {
		return recordNum;
	}

	public List<UtilityBillsPaymentsRecords> getRecords() {
		return records;
	}

	@Override
	public String toString() {
		return new StringBuilder("{customerId=" + customerId + ", recordNum=" + recordNum + "}").toString();
	}

}

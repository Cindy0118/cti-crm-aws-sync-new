package com.cathay.api.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cathay.api.domain.CommonRequest;
import com.cathay.api.domain.CommonResponse;
import com.cathay.api.domain.Constants;
import com.cathay.api.domain.ProductRecommendation;
import com.cathay.api.domain.RetrieveProductPitchRequest;
import com.cathay.api.domain.StoreRecommendationRequest;
import com.cathay.api.domain.ValidateTrustKeyResponse;
import com.cathay.api.service.ProductRecommendationService;
import com.cathay.api.service.TrustKeyService;

@CrossOrigin
@RestController
public class ProductRecommendationController {

	private static final Logger LOGGER = LogManager.getLogger(ProductRecommendationController.class);

	@Autowired
	TrustKeyService trustKeyService;

	@Autowired
	ProductRecommendationService productRecommendationService;

	@PostMapping("${mapping.store-recommendation}")
	public CommonResponse storeRecommendation(@RequestBody @Valid StoreRecommendationRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.STORE_PRODUCT_RECOMMENDATION_REQUEST, request);
		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = productRecommendationService.storeRecommendation(new ProductRecommendation(request));
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.STORE_PRODUCT_RECOMMENDATION_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${mapping.retrieve-product-pitch}")
	public CommonResponse retrieveProductPitch(@RequestBody @Valid RetrieveProductPitchRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.RETRIEVE_PRODUCT_PITCH_REQUEST, request);
		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = productRecommendationService.retrieveProductPitch(request.getPitchClassify());
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.RETRIEVE_PRODUCT_PITCH_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${mapping.get-low-marketing}")
	public CommonResponse getLowMarketing(@RequestBody @Valid CommonRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GET_LOW_MARKETING_REQUEST, request);
		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = productRecommendationService.getLowMarketing(request.getCustomerId());
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.GET_LOW_MARKETING_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

}

package com.cathay.api.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cathay.api.domain.LowMarketing;

public interface LowMarketingRepository extends CrudRepository<LowMarketing, String> {
	
	@Query(nativeQuery=true)
	LowMarketing findByCustomerId(String customerId);

}

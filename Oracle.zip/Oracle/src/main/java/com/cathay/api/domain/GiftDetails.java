package com.cathay.api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "crm_gift_details")
public class GiftDetails {
	
	@JsonIgnore
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "crm_gift_details_seq")
	@SequenceGenerator(sequenceName = "crm_gift_details_seq", initialValue = 1, allocationSize = 1, name = "crm_gift_details_seq")
	@Column(name = "seq_no")
	private long seqNo;
	
	@JsonIgnore
	@Column(name = "file_seq_no")
	private long fileSeqNo;

	@JsonIgnore
	@Column(name = "pid")
	private String pid;
	
	@JsonIgnore
	@Column(name = "p_name")
	private String pName;
	
	@JsonIgnore
	@Column(name = "f_flag")
	private String fFlag;
	
	@Column(name = "f_cnt")
	private int fCnt;
	
	@JsonIgnore
	@Column(name = "f_amt")
	private double fAmt;
	
	@JsonIgnore
	@Column(name = "t_flag")
	private String tFlag;
	
	@JsonIgnore
	@Column(name = "t_amt")
	private double tAmt;
	
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getfFlag() {
		return fFlag;
	}
	public void setfFlag(String fFlag) {
		this.fFlag = fFlag;
	}
	public int getfCnt() {
		return fCnt;
	}
	public void setfCnt(int fCnt) {
		this.fCnt = fCnt;
	}
	
	public String gettFlag() {
		return tFlag;
	}
	public void settFlag(String tFlag) {
		this.tFlag = tFlag;
	}
	public long getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(long seqNo) {
		this.seqNo = seqNo;
	}
	public long getFileSeqNo() {
		return fileSeqNo;
	}
	public void setFileSeqNo(long fileSeqNo) {
		this.fileSeqNo = fileSeqNo;
	}
	public double getfAmt() {
		return fAmt;
	}
	public void setfAmt(double fAmt) {
		this.fAmt = fAmt;
	}
	public double gettAmt() {
		return tAmt;
	}
	public void settAmt(double tAmt) {
		this.tAmt = tAmt;
	}
	
}

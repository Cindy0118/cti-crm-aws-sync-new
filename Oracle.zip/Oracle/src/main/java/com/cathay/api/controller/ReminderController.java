package com.cathay.api.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cathay.api.domain.CommonRequest;
import com.cathay.api.domain.CommonResponse;
import com.cathay.api.domain.Constants;
import com.cathay.api.domain.RemindersRequest;
import com.cathay.api.domain.ValidateTrustKeyResponse;
import com.cathay.api.service.ReminderService;
import com.cathay.api.service.TrustKeyService;

@CrossOrigin
@RestController
public class ReminderController {

	private static final Logger LOGGER = LogManager.getLogger(ReminderController.class);

	@Autowired
	TrustKeyService trustKeyService;

	@Autowired
	ReminderService reminderService;

	@PostMapping("${mapping.retrieve-card-count}")
	public CommonResponse retrieveCampaignCardCount(@RequestBody @Valid RemindersRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.REMINDERS_REQUEST, request);
		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = reminderService.getGiftDetails(request.getCampaignCode());
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.REMINDERS_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${mapping.retrieve-transaction-sequence}")
	public CommonResponse retrieveTransactionSequence(@RequestBody @Valid CommonRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.TRANSACTION_SEQUENCE_REQUEST, request);
		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = reminderService.getTransactionSequence();
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.TRANSACTION_SEQUENCE_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

}

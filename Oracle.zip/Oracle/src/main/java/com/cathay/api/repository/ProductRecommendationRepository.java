package com.cathay.api.repository;

import org.springframework.data.repository.CrudRepository;

import com.cathay.api.domain.ProductRecommendation;

public interface ProductRecommendationRepository extends CrudRepository<ProductRecommendation, Long> {

}

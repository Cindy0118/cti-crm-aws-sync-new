package com.cathay.api.domain;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class CustomerGreetingsRequest {

	@Valid
	private Header header;

	@NotBlank
	@Size(max = 18)
	private String customerId;

	@NotBlank
	private String trustKey;

	@NotBlank
	@Size(max = 10)
	private String recordDate;

	@NotBlank
	@Size(max = 20)
	private String recordTime;

	@Size(max = 1)
	private String bankVipInd;

	@Size(max = 1)
	private String ccVipInd;

	@Size(max = 80)
	private String customerName;

	public CustomerGreetingsRequest() {
		super();
	}

	public CustomerGreetingsRequest(Header header, String customerId, String trustKey) {
		this.header = header;
		this.customerId = customerId;
		this.trustKey = trustKey;

	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setCcVipInd(String ccVipInd) {
		this.ccVipInd = ccVipInd;
	}

	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}

	public void setRecordDate(String recordDate) {
		this.recordDate = recordDate;
	}

	public void setBankVipInd(String bankVipInd) {
		this.bankVipInd = bankVipInd;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public Header getHeader() {
		return header;
	}

	public String getCustomerId() {
		return customerId;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public String getBankVipInd() {
		return bankVipInd;
	}

	public String getRecordDate() {
		return recordDate;
	}

	public String getRecordTime() {
		return recordTime;
	}

	public String getCcVipInd() {
		return ccVipInd;
	}

	public String getCustomerName() {
		return customerName;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + ", customerId=" + customerId + ", trustKey=" + trustKey
				+ ", recordDate=" + recordDate + ", recordTime=" + recordTime + ", bankVipInd=" + bankVipInd
				+ ", ccVipInd=" + ccVipInd + ", customerName=" + customerName + "}").toString();
	}

}

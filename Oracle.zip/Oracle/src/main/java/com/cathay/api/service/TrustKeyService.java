package com.cathay.api.service;

import java.util.Collections;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.cathay.api.domain.Constants;
import com.cathay.api.domain.Header;
import com.cathay.api.domain.ValidateTrustKeyRequest;
import com.cathay.api.domain.ValidateTrustKeyResponse;

@Service
public class TrustKeyService {

	private static final Logger LOGGER = LogManager.getLogger(TrustKeyService.class);
	private RestTemplate restTemplate;

	@Value("${authentication-service}")
	protected String authenticationServiceUrl;

	public ValidateTrustKeyResponse validateTrustKey(Header header, String trustKey) {
		ValidateTrustKeyRequest requestBody = new ValidateTrustKeyRequest(header, trustKey);
		LOGGER.info(Constants.VALIDATING_TRUSTKEY, requestBody);
		ValidateTrustKeyResponse data = null;

		try {
			if (restTemplate == null) {
				restTemplate = new RestTemplate();
			}

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<ValidateTrustKeyRequest> entity = new HttpEntity<>(requestBody, httpHeaders);

			data = restTemplate.postForObject(authenticationServiceUrl, entity, ValidateTrustKeyResponse.class);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.LOGGER_REST_CLIENT_ERROR, authenticationServiceUrl);
			LOGGER.error(description, e);
			data = new ValidateTrustKeyResponse(header, e.getStatusCode().toString(), description,
					trustKey);
		} catch (IllegalArgumentException e) {
			LOGGER.error(requestBody, e);
			data = new ValidateTrustKeyResponse(header, Constants.BAD_REQUEST_CODE, Constants.ILLEGAL_ARGUMENT_ERROR,
					trustKey);
		}
		
		LOGGER.info(Constants.VALIDATION_RESPONSE, data);
		return data;
	}

}

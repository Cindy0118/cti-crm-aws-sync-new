package com.cathay.api.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cathay.api.domain.CustomerProfile;

public interface CustomerProfileRepository extends CrudRepository<CustomerProfile, String>{
	
	@Query(nativeQuery=true)
	CustomerProfile findByCustomerId(String customerId);
	
}



package com.cathay.api.domain;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "v_crm_event_cc_stmt_pay")
public class PaymentHabitsRecords {

	@JsonIgnore
	@Column(name = "customer_id")
	private String customerId;
	
	@EmbeddedId
	private PaymentHabitsPrimaryKeyObject id;
	
	public PaymentHabitsRecords() {
		super();
	}
	
	public PaymentHabitsPrimaryKeyObject getId() {
		return id;
	}

	public void setId(PaymentHabitsPrimaryKeyObject id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "PaymentHabitsRecords [id=" + id + "]";
	}
}

package com.cathay.api.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.cathay.api.domain.CardsRecords;
import com.cathay.api.domain.CommonResponse;
import com.cathay.api.domain.AutoAccountDebiting;
import com.cathay.api.domain.AutoAccountDebitingRecords;
import com.cathay.api.domain.Cards;
import com.cathay.api.domain.Constants;
import com.cathay.api.domain.FinancialProducts;
import com.cathay.api.domain.PaymentHabitsResponse;
import com.cathay.api.domain.PaymentHabits;
import com.cathay.api.domain.PaymentHabitsRecords;
import com.cathay.api.domain.Savings;
import com.cathay.api.domain.SavingsRecords;
import com.cathay.api.domain.UtilityBillsPayments;
import com.cathay.api.domain.UtilityBillsPaymentsRecords;
import com.cathay.api.repository.AutoAccountDebitingRepository;
import com.cathay.api.repository.CardsRepository;
import com.cathay.api.repository.FinancialProductsRepository;
import com.cathay.api.repository.PaymentHabitsRepository;
import com.cathay.api.repository.SavingsRepository;
import com.cathay.api.repository.UtilityBillsPaymentRepository;

@Service
public class FinancialProductsService {

	private static final Logger LOGGER = LogManager.getLogger(FinancialProductsService.class);

	@Autowired
	FinancialProductsRepository financialProductsRepository;

	@Autowired
	CardsRepository cardsRepository;

	@Autowired
	PaymentHabitsRepository paymentHabitsRepository;

	@Autowired
	AutoAccountDebitingRepository autoAccountDebitingRepository;

	@Autowired
	UtilityBillsPaymentRepository utilityBillsPaymentRepository;

	@Autowired
	SavingsRepository savingsRepository;

	public CommonResponse getCustomerFinancialProducts(String customerId) {
		CommonResponse response = null;

		try {
			FinancialProducts financialProducts = financialProductsRepository.findByCustomerId(customerId);

			if (financialProducts == null) {
				response = new CommonResponse(Constants.NO_DATA_CODE, Constants.ERROR_MESSAGE, Constants.NO_DATA_ERROR,
						Constants.SOURCE);
			} else {
				response = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE, financialProducts);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

	public CommonResponse getCards(String customerId, String queryInd) {
		CommonResponse response = null;
		List<CardsRecords> cardRecords = new ArrayList<>();

		try {

			if (queryInd.equalsIgnoreCase("P")) {
				cardRecords = cardsRepository.findPrimaryCards(customerId);
			} else if (queryInd.equalsIgnoreCase("S")) {
				cardRecords = cardsRepository.findSecondaryCards(customerId);
			} else if (queryInd.equalsIgnoreCase("B")) {
				cardRecords = cardsRepository.findBusinessCards(customerId);
			} else if (queryInd.equalsIgnoreCase("F")) {
				cardRecords = cardsRepository.findPrimaryHasSecondaryCards(customerId);
			} else {
				response = new CommonResponse(Constants.BAD_REQUEST_CODE, Constants.ERROR_MESSAGE,
						Constants.QUERY_INDICATOR_NOT_FOUND, Constants.SOURCE);
			}

			if (response == null) {
				int itemCount = cardRecords.size();
				Cards cards = new Cards(customerId, cardRecords, itemCount);

				if (cardRecords.isEmpty()) {
					response = new CommonResponse(Constants.NO_DATA_CODE, Constants.ERROR_MESSAGE,
							Constants.NO_DATA_ERROR, Constants.SOURCE);
				} else {
					response = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE, cards);
				}
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

	public CommonResponse getPaymentHabits(String customerId) {
		CommonResponse response = null;
		List<PaymentHabitsRecords> paymentRecords = new ArrayList<>();
		List<PaymentHabitsResponse> paymentResponse = new ArrayList<>();

		try {
			paymentRecords = paymentHabitsRepository.findByCustomerId(customerId);

			int itemCount = paymentRecords.size();

			if (itemCount > 0) {
				for (PaymentHabitsRecords recordsFromDB : paymentRecords) {
					PaymentHabitsResponse newRecord = new PaymentHabitsResponse();
					newRecord.setStmtYearMonth(recordsFromDB.getId().getStmtYearMonth());
					newRecord.setTxnDate(recordsFromDB.getId().getTxnDate());
					newRecord.setPayChannelTypeDesc(recordsFromDB.getId().getPayChannelTypeDesc());
					newRecord.setPayAmt(recordsFromDB.getId().getPayAmt());
					paymentResponse.add(newRecord);
				}
			}

			PaymentHabits paymentHabits = new PaymentHabits(customerId, itemCount, paymentResponse);

			if (paymentRecords.isEmpty()) {
				response = new CommonResponse(Constants.NO_DATA_CODE, Constants.ERROR_MESSAGE, Constants.NO_DATA_ERROR,
						Constants.SOURCE);
			} else {
				response = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE, paymentHabits);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

	public CommonResponse getAutoAccountDebiting(String customerId) {
		CommonResponse response = null;
		List<AutoAccountDebitingRecords> autoAccountDebitingRecords = new ArrayList<>();

		try {
			autoAccountDebitingRecords = autoAccountDebitingRepository.findByCustomerId(customerId);
			int itemCount = autoAccountDebitingRecords.size();
			AutoAccountDebiting autoAccountDebiting = new AutoAccountDebiting(customerId, itemCount,
					autoAccountDebitingRecords);

			if (autoAccountDebitingRecords.isEmpty()) {
				response = new CommonResponse(Constants.NO_DATA_CODE, Constants.SUCCESS_MESSAGE,
						Constants.NO_DATA_ERROR, Constants.SOURCE);
			} else {
				response = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE, autoAccountDebiting);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

	public CommonResponse getUtilityBillsPayments(String customerId) {
		CommonResponse response = null;
		List<UtilityBillsPaymentsRecords> utilityBillsPaymentsRecords = new ArrayList<>();

		try {
			utilityBillsPaymentsRecords = utilityBillsPaymentRepository.findByCustomerId(customerId);
			int itemCount = utilityBillsPaymentsRecords.size();
			UtilityBillsPayments autoAccountDebiting = new UtilityBillsPayments(customerId, itemCount,
					utilityBillsPaymentsRecords);

			if (utilityBillsPaymentsRecords.isEmpty()) {
				response = new CommonResponse(Constants.NO_DATA_CODE, Constants.SUCCESS_MESSAGE,
						Constants.NO_DATA_ERROR, Constants.SOURCE);
			} else {
				response = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE, autoAccountDebiting);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

	public CommonResponse getSavings(String customerId) {
		CommonResponse response = null;
		List<SavingsRecords> savingsRecords = new ArrayList<>();

		try {
			savingsRecords = savingsRepository.findByCustomerId(customerId);
			int itemCount = savingsRecords.size();
			Savings savings = new Savings(customerId, itemCount, savingsRecords);

			if (savingsRecords.isEmpty()) {
				response = new CommonResponse(Constants.NO_DATA_CODE, Constants.SUCCESS_MESSAGE,
						Constants.NO_DATA_ERROR, Constants.SOURCE);
			} else {
				response = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE, savings);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

}

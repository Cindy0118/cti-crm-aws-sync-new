package com.cathay.api.domain;

import java.util.List;

public class AutoAccountDebiting {

	private String customerId;
	private int recordNum;
	private List<AutoAccountDebitingRecords> records;

	public AutoAccountDebiting(String customerId, int recordNum, List<AutoAccountDebitingRecords> records) {
		this.customerId = customerId;
		this.recordNum = recordNum;
		this.records = records;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public int getRecordNum() {
		return recordNum;
	}

	public void setRecordNum(int recordNum) {
		this.recordNum = recordNum;
	}

	public List<AutoAccountDebitingRecords> getRecords() {
		return records;
	}

	public void setRecords(List<AutoAccountDebitingRecords> records) {
		this.records = records;
	}

	@Override
	public String toString() {
		return new StringBuilder("{customerId=" + customerId + ", recordNum=" + recordNum + ", records=" + records
				+ "}").toString();
	}
}

package com.cathay.api.domain;

public class ValidateTrustKeyRequest {

	private Header header;
	private String trustKey;

	public ValidateTrustKeyRequest() {
	}

	public ValidateTrustKeyRequest(Header header, String trustKey) {
		this.header = header;
		this.trustKey = trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public Header getHeader() {
		return header;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + ", trustKey=" + trustKey + "}").toString();
	}

}

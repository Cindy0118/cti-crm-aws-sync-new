package com.cathay.service.bean;

public class Journey {
	
	private String apiCode;
	private String message;
	private CustomerJourneyResult result;
	
	public Journey(String apiCode, String message, CustomerJourneyResult customerJourneyTimeSlot) {
		super();
		this.apiCode = apiCode;
		this.message = message;
		this.result = customerJourneyTimeSlot;
	}

	public String getApiCode() {
		return apiCode;
	}

	public void setApiCode(String apiCode) {
		this.apiCode = apiCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public CustomerJourneyResult getResult() {
		return result;
	}

	public void setResult(CustomerJourneyResult result) {
		this.result = result;
	}
}

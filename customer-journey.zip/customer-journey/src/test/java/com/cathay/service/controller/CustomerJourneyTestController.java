package com.cathay.service.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cathay.service.CustomerJourneyApplication;
import com.cathay.service.bean.CustomerJourneyResult;
import com.cathay.service.bean.EventsJourney;
import com.cathay.service.bean.EventsJourneyDetail;
import com.cathay.service.bean.Journey;
import com.cathay.service.bean.JourneyDetail;
import com.cathay.service.bean.TimeSlot;

@RunWith(SpringRunner.class)
@WebMvcTest(value = CustomerJourneyApplication.class, secure = false)
public class CustomerJourneyTestController {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private CustomerJourneyController customerJourneyController;
	
	@Value("${customer-journey.test}")
	private String customerJourneyUrl;
	
	@Value("${customer-journey-detail.test}")
	private String customerJourneyDetailUrl;
	
	public Journey getJourney() {
		EventsJourney events1Journey1 = new EventsJourney("atm");
		EventsJourney events1Journey2 = new EventsJourney("mybank");
		EventsJourney events1Journey3 = new EventsJourney("etbs");
		EventsJourney events1Journey4 = new EventsJourney("mmb");
		
		List<EventsJourney> customerJourneyList1 = new ArrayList<>();
		customerJourneyList1.add(events1Journey1);
		customerJourneyList1.add(events1Journey2);
		customerJourneyList1.add(events1Journey3);
		customerJourneyList1.add(events1Journey4);
		
		TimeSlot timeSlot1 = new TimeSlot(1522540800, customerJourneyList1);
		
		EventsJourney events2Journey1 = new EventsJourney("mmb");
		
		List<EventsJourney> customerJourneyList2 = new ArrayList<>();
		customerJourneyList2.add(events2Journey1);
		
		TimeSlot timeSlot2 = new TimeSlot(1522627200, customerJourneyList2);
		
		List<TimeSlot> customerJourneyTimeSlot = new ArrayList<>();
		customerJourneyTimeSlot.add(timeSlot1);
		customerJourneyTimeSlot.add(timeSlot2);
		
		CustomerJourneyResult customerJourneyResult = new CustomerJourneyResult(customerJourneyTimeSlot, 1524723762, 1523664000);
		
		Journey journey = new Journey("crm_0000", "", customerJourneyResult);
		
		return journey;
	}
	
	public JourneyDetail getJourneyDetails() {
		EventsJourneyDetail eventsJourneyDetails1 = new EventsJourneyDetail("Channel 1", 1523493624, "Description 1");
		EventsJourneyDetail eventsJourneyDetails2 = new EventsJourneyDetail("Channel 2", 1234567890, "Description 2");
		
		List<EventsJourneyDetail> customerJourneyDetailList = new ArrayList<>();
		customerJourneyDetailList.add(eventsJourneyDetails1);
		customerJourneyDetailList.add(eventsJourneyDetails2);
		
		JourneyDetail journeyDetail = new JourneyDetail("crm_0000", "", customerJourneyDetailList);
		
		return journeyDetail;
	}
	
	@Test
	public void testGetCustomerJourney() throws Exception {

		Mockito.when(customerJourneyController.getCustomerJourney(Mockito.anyString(), Mockito.anyString(), 
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyObject())).thenReturn(getJourney());
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(customerJourneyUrl).accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();

		String expectedData = "{\"apiCode\":\"crm_0000\"," 
				+ "\"message\":\"\"," 
				+ "\"result\":{" 
				+ "\"timeSlots\":[" 
				+ "{" 
				+ "\"timeStamp\":1522540800," 
				+ "\"events\":[" 
				+ "{" 
				+ "\"channel\":\"atm\"" 
				+ "}," 
				+ "{" 
				+ "\"channel\":\"mybank\"" 
				+ "}," 
				+ "{" 
				+ "\"channel\":\"etbs\"" 
				+ "}," 
				+ "{" 
				+ "\"channel\":\"mmb\"" 
				+ "}" 
				+ "]" 
				+ "}," 
				+ "{" 
				+ "\"timeStamp\":1522627200," 
				+ "\"events\":[" 
				+ "{" 
				+ "\"channel\":\"mmb\"" 
				+ "}" 
				+ "]" 
				+ "}"
				+ "],"
				+ "\"updateDate\":1524723762," 
				+ "\"currentDate\":1523664000" 
				+ "}" 
				+ "}";
		
		String actualData = mvcResult.getResponse().getContentAsString();
		
		JSONAssert.assertEquals(expectedData, actualData, false);
	}
	
	@Test
	public void testGetCustomerJourneyDetails() throws Exception {

		Mockito.when(customerJourneyController.getCustomerJourneyDetail(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(), 
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyObject())).
				thenReturn(getJourneyDetails());

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(customerJourneyDetailUrl).accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();

		String expectedData = "{" 
				+ "\"apiCode\":\"crm_0000\"," 
				+ "\"message\":\"\"," 
				+ "\"result\":[" 
				+ "{" 
				+ "\"channel\":\"Channel 1\"," 
				+ "\"time\":1523493624," 
				+ "\"detail\":\"Description 1\"" 
				+ "}," 
				+ "{" 
				+ "\"channel\":\"Channel 2\"," 
				+ "\"time\":1234567890," 
				+ "\"detail\":\"Description 2\"" 
				+ "}" 
				+ "]" 
				+ "}";

		String actualData = mvcResult.getResponse().getContentAsString();
		
		JSONAssert.assertEquals(expectedData, actualData, false);
	}
}
package com.cathay.service.bean;

public class EventsJourneyDetail {

	public String channel;
	public int time;
	public String detail;
	
	public EventsJourneyDetail(String channel, int time, String detail) {
		super();
		this.channel = channel;
		this.time = time;
		this.detail = detail;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}
	
	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}
}

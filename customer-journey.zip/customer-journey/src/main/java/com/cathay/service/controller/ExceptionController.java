package com.cathay.service.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cathay.service.exception.BadRequestException;
import com.cathay.service.exception.InternalServerException;
import com.cathay.service.exception.NotFoundException;

@ControllerAdvice
public class ExceptionController {
	
	@ExceptionHandler(BadRequestException.class)
	public ResponseEntity<Object> handleBadRequestException(BadRequestException e) {
		return new ResponseEntity<>(e.getErrorMessage(), HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(InternalServerException.class)
	public ResponseEntity<Object> handleInternalServerException(InternalServerException e) {
		return new ResponseEntity<>(e.getErrorMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(NotFoundException.class)
	public ResponseEntity<Object> handleNotFoundException(NotFoundException e) {
		return new ResponseEntity<>(e.getErrorMessage(), HttpStatus.NOT_FOUND);
	}
}

package com.cathay.service.exception;

import org.springframework.http.HttpStatus;

import com.cathay.service.bean.ErrorMessage;

public class BadRequestException extends Exception {

	private static final long serialVersionUID = -1402829952129489508L; 
	private static final int CODE = HttpStatus.BAD_REQUEST.value();
	private static final String STATUS = HttpStatus.BAD_REQUEST.getReasonPhrase();
	private ErrorMessage errorMessage;
	
	public BadRequestException(String error, String message) {
		super();
		errorMessage = new ErrorMessage(CODE, STATUS, error, message);
	}
	
	public ErrorMessage getErrorMessage() {
		return errorMessage;
	}
}

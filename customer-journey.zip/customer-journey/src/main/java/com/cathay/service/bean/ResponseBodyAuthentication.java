package com.cathay.service.bean;

public class ResponseBodyAuthentication {

	private String code;
	private String message;
	private String description;
	private String source;
	private Body result;
	
	public ResponseBodyAuthentication() {
		super();
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Body getResult() {
		return result;
	}

	public void setResult(Body result) {
		this.result = result;
	}
}

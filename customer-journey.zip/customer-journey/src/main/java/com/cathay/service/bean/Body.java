package com.cathay.service.bean;

public class Body {

	private String customerId;
	
	public Body() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}	
}

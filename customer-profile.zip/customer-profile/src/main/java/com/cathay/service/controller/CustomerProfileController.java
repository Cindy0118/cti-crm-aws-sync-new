package com.cathay.service.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.cathay.service.domain.AppAuditTrailRequest;
import com.cathay.service.domain.AuditTrailResponse;
import com.cathay.service.domain.AuthResult;
import com.cathay.service.domain.AuthenticationRequestBody;
import com.cathay.service.domain.BirthdayGreetingRequestBody;
import com.cathay.service.domain.Complaint;
import com.cathay.service.domain.CustomerOracleResponse;
import com.cathay.service.domain.Header;
import com.cathay.service.domain.OracleAPIRequestObject;
import com.cathay.service.domain.ParameterValidationResponse;
import com.cathay.service.domain.ProfileMongoResponse;
import com.cathay.service.domain.RequestBodyBirthdayGreeting;
import com.cathay.service.domain.RequestBodyProfile;
import com.cathay.service.domain.ResponseBody;
import com.cathay.service.service.AuthenticationService;
import com.cathay.service.utility.APIHelper;
import com.cathay.service.utility.ParamsValidator;

@CrossOrigin
@RestController
public class CustomerProfileController {
	private static final Logger LOGGER = LogManager.getLogger(CustomerProfileController.class);
	private static final String AP_ID = "ap_id";
	private static final String TELLER_ID = "teller_id";
	private static final String UNIQUE_NUMBER = "unique_number";
	private static final String CUSTOMER_ID = "customer_id";
	private static final String BRANCH = "branch";
	private static final String TOKEN = "token";
	private static final String ERROR_CODE="1111";
	private static final String IO_ERROR_CODE="0002";
	private static final String MISSING_PARAMS_CODE="500";
	private static final String SUCCESS_CODE="0000";
	private static final String SUCCESS_MESSAGE="Success";
	private static final String UNIQUE_NUM_VALID="Unique number is valid.";
	private static final String UNIQUE_NUM_INVALID="Unique number is invalid.";
	private static final String AUTH_IO_ERROR_MESSAGE = "Failed to call uniqueNumber Authentication Service.";
	private static final String MONGO_API_ERROR_MESSAGE = "Failed to call Customer Profile Mongo API.";
	private static final String MESSAGE_FAILURE = "Failure";
	private static final String AUDIT_TRAIL_NOT_SAVED = "Audit trail not saved";
	private static final String URL_SOURCE = "Data Source URL: {}";
	
	@Autowired
	private AuthenticationService authService;
	@Value("${api.code}")
	private String apiCode;
	@Value("${mongo.customer.profile}")
	private String tempMongoCustomerProfileUrl;
	@Value("${oracle.customer.profile}")
	private String tempOracleCustomerProfileUrl;
	@Value("${oracle.birthday.greeting}")
	private String birthdayGreetingUrl;
	@Value("${mongo.customer.complaints}")
	private String customerComplaintsUrl;
	@Value("${url.audit-trail-api}")
	private String saveAuditTrailUrl;

	AppAuditTrailRequest auditRequest;
	
	@Async("asyncExecutor")
	@GetMapping("/profile")
	public CompletableFuture<ResponseBody<ProfileMongoResponse>> getCustomerProfile(@RequestParam(value=AP_ID) String apId, @RequestParam(value=TELLER_ID) String tellerId,
			@RequestParam(value=UNIQUE_NUMBER) String uniqueNumber, @RequestParam(value=BRANCH) String branch, @RequestParam(value=TOKEN) String token, 
			HttpServletRequest request){
		LOGGER.info("[START @CustomerProfileController -getCustomerProfile()]");
		ResponseBody<ProfileMongoResponse> response = new ResponseBody<>();
		ParameterValidationResponse validResponse = ParamsValidator.validateCustomerProfileParams(apId, tellerId, uniqueNumber, branch, token);
		Header header = new Header(apId, branch, tellerId, request.getRemoteAddr());
		
		auditRequest =  new AppAuditTrailRequest();
		auditRequest.setHeader(header);
		auditRequest.setAccessObjectType("V");
		auditRequest.setActionType("P");
		auditRequest.setUserLoginAccount(header.getEmployeeId());
		auditRequest.setProgramName("getCustomerProfile_mongodb");
		auditRequest.setKeyField("YNYNNNNN");
		auditRequest.setCompanyType("2");
		
		if (validResponse.isValidParams()) {
			RestTemplate restTemplate = new RestTemplate();
			AuthenticationRequestBody authenticationRequestBody = new AuthenticationRequestBody();
			authenticationRequestBody.setHeader(header);
			authenticationRequestBody.setTrustKey(token);
			authenticationRequestBody.setUniqueNumber(uniqueNumber);
			CompletableFuture<ResponseBody<AuthResult>> compAuthResponse = authService.authenticateUniqueNumber(authenticationRequestBody);
			ResponseBody<AuthResult> authResponse;
			try {
				authResponse = compAuthResponse.get();
				
				if(authResponse.getCode().equalsIgnoreCase(SUCCESS_CODE)) {
					LOGGER.info(UNIQUE_NUM_VALID);
						//call api here
						HttpHeaders headers = new HttpHeaders();
						headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
						UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(tempMongoCustomerProfileUrl)
								.queryParam(AP_ID, apId)
								.queryParam(TELLER_ID, tellerId)
								.queryParam(CUSTOMER_ID, authResponse.getResult().getCustomerId())
								.queryParam(BRANCH, branch)
								.queryParam(TOKEN, token);
						HttpEntity<?> entity = new HttpEntity<>(headers);
						ParameterizedTypeReference<ResponseBody<ProfileMongoResponse>> responseType = new ParameterizedTypeReference<ResponseBody<ProfileMongoResponse>>() {};
						ResponseEntity<ResponseBody<ProfileMongoResponse>> profileResponse = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity,responseType);
						LOGGER.info("CustomerProfile response is: " + profileResponse.toString());
						if(profileResponse.getStatusCodeValue() == 200) {
							if(profileResponse.getBody().getCode().equals("0000".trim())) {
								response.setResult(profileResponse.getBody().getResult());
								response.setDescription(profileResponse.getBody().getDescription());
								response.setMessage(SUCCESS_MESSAGE);
								response.setCode(SUCCESS_CODE);
								auditRequest.setDataAccess(SUCCESS_MESSAGE);
								auditRequest.setRecordCount(1);
							}else if(profileResponse.getBody().getCode().equals("1111".trim())) {
								response.setResult(profileResponse.getBody().getResult());
								response.setDescription(profileResponse.getBody().getDescription());
								response.setMessage(profileResponse.getBody().getMessage());
								response.setCode(profileResponse.getBody().getCode());
								auditRequest.setDataAccess(MESSAGE_FAILURE);
								auditRequest.setRecordCount(0);
							}
							response.setSource(apiCode);
						}else {
							response.setCode(profileResponse.getBody().getCode());
							response.setSource(apiCode);
							response.setDescription(profileResponse.getBody().getDescription());
							response.setMessage(profileResponse.getStatusCode().getReasonPhrase());
							auditRequest.setDataAccess(MESSAGE_FAILURE);
							auditRequest.setRecordCount(0);
						}
				}else if(authResponse.getCode().equalsIgnoreCase(ERROR_CODE)){
					response.setMessage(authResponse.getMessage());
					response.setCode(authResponse.getCode());
					response.setSource(authResponse.getSource());
					auditRequest.setDataAccess(MESSAGE_FAILURE);
					auditRequest.setRecordCount(0);
				}else {
					response.setMessage(authResponse.getMessage());
					response.setSource(authResponse.getSource());
					response.setCode(authResponse.getCode());
					auditRequest.setDataAccess(MESSAGE_FAILURE);
					auditRequest.setRecordCount(0);
				}
			} catch (RestClientException | InterruptedException | ExecutionException e) {
				LOGGER.error(e.getMessage());
				response.setMessage(e.getMessage());
				response.setCode(ERROR_CODE);
				response.setSource(apiCode);
				auditRequest.setDataAccess(MESSAGE_FAILURE);
				auditRequest.setRecordCount(0);
				LOGGER.error(MONGO_API_ERROR_MESSAGE);
			}
		}else {
			response.setMessage(validResponse.getErrorMessage());
			response.setDescription(validResponse.getErrorMessage());
			response.setSource(request.getServerName());
			response.setCode(MISSING_PARAMS_CODE);
			auditRequest.setDataAccess(MESSAGE_FAILURE);
			auditRequest.setRecordCount(0);
			LOGGER.error("@CustomerProfileController -getCustomerProfile() " + validResponse.getErrorMessage());
		}
		
		LOGGER.info(" response is: " + response.toString());
		LOGGER.info("[END @CustomerProfileController -getCustomerProfile()]");
		saveAuditTrail(auditRequest);
		return CompletableFuture.completedFuture(response);
	}
	
	@PostMapping("/getCustomerProfile")
	public ResponseBody<CustomerOracleResponse> queryCustomerProfile(@RequestBody RequestBodyProfile requestBody, HttpServletRequest request) {
		LOGGER.info("[START @CustomerProfileController -queryCustomerProfile()]");
		ResponseBody<CustomerOracleResponse> profileResponse = new ResponseBody<>();
		Header header = new Header(requestBody.getApId(), requestBody.getBranchNo(), requestBody.getTellerId(), request.getRemoteAddr());
		RestTemplate restTemplate = new RestTemplate();
		AuthenticationRequestBody authenticationRequestBody = new AuthenticationRequestBody();
		authenticationRequestBody.setHeader(header);
		authenticationRequestBody.setTrustKey(requestBody.getTrustKey());
		authenticationRequestBody.setUniqueNumber(requestBody.getUniqueNumber());
		LOGGER.debug("++" +  authenticationRequestBody.toString());
		CompletableFuture<ResponseBody<AuthResult>> compAuthResponse = authService.authenticateUniqueNumber(authenticationRequestBody);
		OracleAPIRequestObject requestObj = new OracleAPIRequestObject();
		ResponseBody<AuthResult> authResponse;
		
		auditRequest =  new AppAuditTrailRequest();
		auditRequest.setHeader(header);
		auditRequest.setAccessObjectType("V");
		auditRequest.setActionType("P");
		auditRequest.setUserLoginAccount(header.getEmployeeId());
		auditRequest.setProgramName("queryCustomerProfile_oracle");
		auditRequest.setKeyField("YYNNNNNN");
		auditRequest.setCompanyType("2");
		
		try {
			authResponse = compAuthResponse.get();
			if(authResponse.getCode().equalsIgnoreCase(SUCCESS_CODE)) {
				LOGGER.info(UNIQUE_NUM_VALID);
				
					HttpHeaders headers = new HttpHeaders();
					headers.setContentType(MediaType.APPLICATION_JSON);
					headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
					requestObj.setCustomerId(authResponse.getResult().getCustomerId());
					requestObj.setHeader(header);
					requestObj.setTrustKey(requestBody.getTrustKey());
					HttpEntity<OracleAPIRequestObject> entity = new HttpEntity<>(requestObj, headers);
					ParameterizedTypeReference<ResponseBody<CustomerOracleResponse>> responseType = new ParameterizedTypeReference<ResponseBody<CustomerOracleResponse>>() {};
					ResponseEntity<ResponseBody<CustomerOracleResponse>> response = restTemplate.exchange(tempOracleCustomerProfileUrl, HttpMethod.POST, entity, responseType);
					LOGGER.info("Post CustomerProfile response is: " + response.toString());
					if(response.getStatusCodeValue() == 200) {
						if(response.getBody().getCode().equals("0000".trim())) {
							boolean hasGreeted = APIHelper.checkIfYearGreetedIsCurrentYear(response.getBody().getResult().getLastDateGreeted());
							response.getBody().getResult().setHasGreeted(hasGreeted);
							
							profileResponse.setResult(response.getBody().getResult());
							profileResponse.setDescription(response.getBody().getDescription());
							profileResponse.setCode(SUCCESS_CODE);
							profileResponse.setMessage(SUCCESS_MESSAGE);
							auditRequest.setDataAccess(SUCCESS_MESSAGE);
							auditRequest.setRecordCount(1);
							
						}else {
							profileResponse.setResult(response.getBody().getResult());
							profileResponse.setDescription(response.getBody().getDescription());
							profileResponse.setMessage(response.getBody().getMessage());
							profileResponse.setCode(response.getBody().getCode());
							auditRequest.setDataAccess(MESSAGE_FAILURE);
							auditRequest.setRecordCount(0);
						}
						profileResponse.setSource(apiCode);
						
					}else {
						profileResponse.setCode(response.getBody().getCode());
						profileResponse.setSource(apiCode);
						profileResponse.setDescription(response.getBody().getDescription());
						profileResponse.setMessage(response.getStatusCode().getReasonPhrase());
						auditRequest.setDataAccess(MESSAGE_FAILURE);
						auditRequest.setRecordCount(0);
					}
				}else if(authResponse.getCode().equalsIgnoreCase(ERROR_CODE)){
					LOGGER.info(UNIQUE_NUM_INVALID);
					profileResponse.setMessage(UNIQUE_NUM_INVALID);
					profileResponse.setCode(ERROR_CODE);
					auditRequest.setDataAccess(MESSAGE_FAILURE);
					auditRequest.setRecordCount(0);
				}else {
					profileResponse.setMessage(AUTH_IO_ERROR_MESSAGE);
					profileResponse.setCode(IO_ERROR_CODE);
					auditRequest.setDataAccess(MESSAGE_FAILURE);
					auditRequest.setRecordCount(0);
				}
		}  catch (RestClientException | InterruptedException | ExecutionException | ParseException e) {
			LOGGER.error(e.getMessage());
			profileResponse.setMessage(e.getMessage());
			profileResponse.setCode(ERROR_CODE);
			profileResponse.setDescription(e.getLocalizedMessage());
			auditRequest.setDataAccess(MESSAGE_FAILURE);
			auditRequest.setRecordCount(0);
		} 
		LOGGER.info("[END @CustomerProfileController -queryCustomerProfile()]");
		saveAuditTrail(auditRequest);
		return profileResponse;
	}
	
	@PostMapping("/greetCustomerBirthday")
	public ResponseBody<?> greetCustomerOnBirthMonth(@RequestBody BirthdayGreetingRequestBody requestBody, HttpServletRequest request){
		LOGGER.info("[START @CustomerProfileController -greetCustomerOnBirthMonth()]");
		ResponseBody<?> response = new ResponseBody<>();
		Header header = new Header(requestBody.getApId(), requestBody.getBranchNo(), requestBody.getTellerId(), request.getRemoteAddr());
		RestTemplate restTemplate = new RestTemplate();
		AuthenticationRequestBody authenticationRequestBody = new AuthenticationRequestBody();
		authenticationRequestBody.setHeader(header);
		authenticationRequestBody.setTrustKey(requestBody.getTrustKey());
		authenticationRequestBody.setUniqueNumber(requestBody.getUniqueNumber());
		CompletableFuture<ResponseBody<AuthResult>> compAuthResponse = authService.authenticateUniqueNumber(authenticationRequestBody);
		ResponseBody<AuthResult> authResponse;
		
		auditRequest =  new AppAuditTrailRequest();
		auditRequest.setHeader(header);
		auditRequest.setAccessObjectType("T");
		auditRequest.setActionType("A");
		auditRequest.setUserLoginAccount(header.getEmployeeId());
		auditRequest.setProgramName("greetCustomerOnBirthMonth_oracle");
		auditRequest.setKeyField("YNNNNNNN");
		auditRequest.setCompanyType("2");
		
		try {
			authResponse = compAuthResponse.get();
			RequestBodyBirthdayGreeting reqBody = new RequestBodyBirthdayGreeting();
			if(authResponse.getCode().equalsIgnoreCase(SUCCESS_CODE)) {
				LOGGER.info(UNIQUE_NUM_VALID);
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				reqBody.setHeader(header);
				reqBody.setTrustKey(requestBody.getTrustKey());
				reqBody.setCustomerId(authResponse.getResult().getCustomerId());
				reqBody.setCustomerName(requestBody.getCustomerName());
				reqBody.setCcVipInd(requestBody.getCcVipInd());
				reqBody.setBankVipInd(requestBody.getBankVipInd());
				//get current date today
				Date dateToday = new Date();
				
				String date = new SimpleDateFormat("MM/dd/yyyy").format(dateToday);
				String time = new SimpleDateFormat("HH:mm:ss").format(dateToday);

				reqBody.setRecordDate(date);
				reqBody.setRecordTime(time);
					
					HttpEntity<RequestBodyBirthdayGreeting> entity = new HttpEntity<>(reqBody, headers);
					ParameterizedTypeReference<ResponseBody<?>> responseType = new ParameterizedTypeReference<ResponseBody<?>>() {};
					ResponseEntity<ResponseBody<?>> responseEntity = restTemplate.exchange(birthdayGreetingUrl, HttpMethod.POST, entity, responseType);
					LOGGER.info("greeting response is: " + responseEntity.toString());
					if(responseEntity.getStatusCodeValue() == 200) {
						if(responseEntity.getBody().getCode().equals("0000".trim())) {
							response.setDescription(responseEntity.getBody().getDescription());
							response.setCode(SUCCESS_CODE);
							response.setMessage(SUCCESS_MESSAGE);
							auditRequest.setDataAccess(SUCCESS_MESSAGE);
							auditRequest.setRecordCount(1);
						}else {
							response.setDescription(responseEntity.getBody().getDescription());
							response.setMessage(responseEntity.getBody().getMessage());
							response.setCode(responseEntity.getBody().getCode());
							auditRequest.setDataAccess(MESSAGE_FAILURE);
							auditRequest.setRecordCount(0);
						}
						response.setSource(apiCode);
					}else {
						response.setCode(responseEntity.getBody().getCode());
						response.setSource(apiCode);
						response.setDescription(responseEntity.getBody().getDescription());
						response.setMessage(responseEntity.getStatusCode().getReasonPhrase());
						auditRequest.setDataAccess(MESSAGE_FAILURE);
						auditRequest.setRecordCount(0);
					}
				
				}else if(authResponse.getCode().equalsIgnoreCase(ERROR_CODE)){
					response.setMessage(UNIQUE_NUM_INVALID);
					response.setCode(ERROR_CODE);
					auditRequest.setDataAccess(MESSAGE_FAILURE);
					auditRequest.setRecordCount(0);
				}else {
					response.setMessage(AUTH_IO_ERROR_MESSAGE);
					response.setCode(IO_ERROR_CODE);
					auditRequest.setDataAccess(MESSAGE_FAILURE);
					auditRequest.setRecordCount(0);
				}
		} catch (RestClientException | InterruptedException | ExecutionException e) {
			LOGGER.error(e.getMessage());
			response.setMessage(e.getMessage());
			response.setCode(ERROR_CODE);
			response.setDescription(e.getLocalizedMessage());
			auditRequest.setDataAccess(MESSAGE_FAILURE);
			auditRequest.setRecordCount(0);
		}
		LOGGER.info("[END @CustomerProfileController -greetCustomerOnBirthMonth()]");
		saveAuditTrail(auditRequest);
		return response;
	}
	@Async("asyncExecutor")
	@GetMapping("/profile/complaint")
	public CompletableFuture<ResponseBody<List<Complaint>>> getComplaintRecords(@RequestParam(value=AP_ID) String apId, @RequestParam(value=TELLER_ID) String tellerId,
			@RequestParam(value=UNIQUE_NUMBER) String uniqueNumber, @RequestParam(value=BRANCH) String branch, @RequestParam(value=TOKEN) String token, 
			HttpServletRequest request){
		LOGGER.info("[START @CustomerProfileController -getComplaintRecords()]");
		ResponseBody<List<Complaint>> response = new ResponseBody<>();
		ParameterValidationResponse validResponse = ParamsValidator.validateCustomerProfileParams(apId, tellerId, uniqueNumber, branch, token);
		Header header = new Header(apId, branch, tellerId, request.getRemoteAddr());
		
		auditRequest =  new AppAuditTrailRequest();
		auditRequest.setHeader(header);
		auditRequest.setAccessObjectType("V");
		auditRequest.setActionType("P");
		auditRequest.setUserLoginAccount(header.getEmployeeId());
		auditRequest.setProgramName("getComplaintRecords_mongodb");
		auditRequest.setKeyField("YNNNNNNN");
		auditRequest.setCompanyType("2");
		
		if (validResponse.isValidParams()) {
			RestTemplate restTemplate = new RestTemplate();
			AuthenticationRequestBody authenticationRequestBody = new AuthenticationRequestBody();
			authenticationRequestBody.setHeader(header);
			authenticationRequestBody.setTrustKey(token);
			authenticationRequestBody.setUniqueNumber(uniqueNumber);
			CompletableFuture<ResponseBody<AuthResult>> compAuthResponse = authService.authenticateUniqueNumber(authenticationRequestBody);
			ResponseBody<AuthResult> authResponse;
			try {
				authResponse = compAuthResponse.get();
				if(authResponse.getCode().equalsIgnoreCase(SUCCESS_CODE)) {
					LOGGER.info(UNIQUE_NUM_VALID);
					
						HttpHeaders headers = new HttpHeaders();
						headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
						UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(customerComplaintsUrl)
								.queryParam(AP_ID, apId)
								.queryParam(TELLER_ID, tellerId)
								.queryParam(CUSTOMER_ID, authResponse.getResult().getCustomerId())
								.queryParam(BRANCH, branch)
								.queryParam(TOKEN, token);
						LOGGER.info("url: " + builder.toUriString());
						HttpEntity<?> entity = new HttpEntity<>(headers);
						ParameterizedTypeReference<ResponseBody<List<Complaint>>> responseType = new ParameterizedTypeReference<ResponseBody<List<Complaint>>>() {};
						ResponseEntity<ResponseBody<List<Complaint>>> profileResponse = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity,responseType);
						LOGGER.info("profile complaint response is: " + profileResponse.toString());
						if(profileResponse.getStatusCodeValue() == 200) {
							if(profileResponse.getBody().getCode().equals("0000".trim())) {
								response.setResult(profileResponse.getBody().getResult());
								response.setDescription(profileResponse.getBody().getDescription());
								response.setMessage(SUCCESS_MESSAGE);
								response.setCode(SUCCESS_CODE);
								auditRequest.setDataAccess(SUCCESS_MESSAGE);
								auditRequest.setRecordCount(1);
								
							}else if(profileResponse.getBody().getCode().equals("1111".trim())) {
								response.setResult(profileResponse.getBody().getResult());
								response.setDescription(profileResponse.getBody().getDescription());
								response.setMessage(profileResponse.getBody().getMessage());
								response.setCode(profileResponse.getBody().getCode());
								auditRequest.setDataAccess(MESSAGE_FAILURE);
								auditRequest.setRecordCount(0);
							}
							response.setSource(apiCode);
						}else {
							response.setCode(profileResponse.getBody().getCode());
							response.setSource(apiCode);
							response.setDescription(profileResponse.getBody().getDescription());
							response.setMessage(profileResponse.getStatusCode().getReasonPhrase());
							auditRequest.setDataAccess(MESSAGE_FAILURE);
							auditRequest.setRecordCount(0);
						}
							
					
				}else if(authResponse.getCode().equalsIgnoreCase(ERROR_CODE)){
					response.setMessage(authResponse.getMessage());
					response.setCode(authResponse.getCode());
					response.setSource(authResponse.getSource());
					auditRequest.setDataAccess(MESSAGE_FAILURE);
					auditRequest.setRecordCount(0);
				}else {
					response.setMessage(authResponse.getMessage());
					response.setSource(authResponse.getSource());
					response.setCode(authResponse.getCode());
					auditRequest.setDataAccess(MESSAGE_FAILURE);
					auditRequest.setRecordCount(0);
				}
			} catch (RestClientException | InterruptedException | ExecutionException e) {
				LOGGER.error(e.getMessage());
				response.setMessage(e.getMessage());
				response.setCode(ERROR_CODE);
				response.setSource(apiCode);
				auditRequest.setDataAccess(MESSAGE_FAILURE);
				auditRequest.setRecordCount(0);
				LOGGER.error(MONGO_API_ERROR_MESSAGE);
			}
		}else {
			response.setMessage(validResponse.getErrorMessage());
			response.setDescription(validResponse.getErrorMessage());
			response.setSource(request.getServerName());
			response.setCode(MISSING_PARAMS_CODE);
			auditRequest.setDataAccess(MESSAGE_FAILURE);
			auditRequest.setRecordCount(0);
			LOGGER.error("@CustomerProfileController -getComplaintRecords() " + validResponse.getErrorMessage());
		}
		LOGGER.info("Response is: " + response.toString());
		LOGGER.info("[END @CustomerProfileController -getComplaintRecords()]");
		saveAuditTrail(auditRequest);
		return CompletableFuture.completedFuture(response);
	}
	
	private void saveAuditTrail(AppAuditTrailRequest request) {
		LOGGER.info("[START @{} ({})]", this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		try {
			if (request != null) {
				RestTemplate restTemplate = new RestTemplate();
				restTemplate.postForObject(saveAuditTrailUrl, request, AuditTrailResponse.class);
				LOGGER.info("Saving audit trail");
			} else {
				LOGGER.error("Audit Trail Request is null");
				LOGGER.error(AUDIT_TRAIL_NOT_SAVED);
			}
		} catch (RestClientException e) {
			LOGGER.error("RestClientException occured in saving audit trail");
			LOGGER.error(URL_SOURCE, saveAuditTrailUrl);
			LOGGER.error(e);
			LOGGER.error(AUDIT_TRAIL_NOT_SAVED);
		} catch (Exception e) {
			LOGGER.error("An error occured, please see log details", e);
			LOGGER.error(AUDIT_TRAIL_NOT_SAVED);
		}
		LOGGER.info("[END @{} ({})]", this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
	}
}

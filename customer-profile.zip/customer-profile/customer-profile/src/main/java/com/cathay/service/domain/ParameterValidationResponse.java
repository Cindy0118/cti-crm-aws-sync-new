package com.cathay.service.domain;

public class ParameterValidationResponse {
	private String errorMessage;
	private boolean validParams;
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public boolean isValidParams() {
		return validParams;
	}
	public void setValidParams(boolean validParams) {
		this.validParams = validParams;
	}
	@Override
	public String toString() {
		return "ParameterValidationResponse [errorMessage=" + errorMessage + ", validParams=" + validParams + "]";
	}
}

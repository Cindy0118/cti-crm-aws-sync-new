package com.cathay.service.domain;

import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

import com.cathay.service.domain.Header;

public class AppAuditTrailRequest {

	@Valid
	private Header header;
	
	@NotBlank
	private String userLoginAccount;
	
	private String actionType;
	@NotBlank
	private String programName;
	
	private String accessObjectType;
	
	private String keyField;
	
	private String companyType;
	
	private String role;
	
	private int recordCount;
	
	private String dataAccess;
	
	private String oldValue;
	
	private String newValue;
	
	private String sqlStatement;
	
	public AppAuditTrailRequest() {
		super();
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getUserLoginAccount() {
		return userLoginAccount;
	}

	public void setUserLoginAccount(String userLoginAccount) {
		this.userLoginAccount = userLoginAccount;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getAccessObjectType() {
		return accessObjectType;
	}

	public void setAccessObjectType(String accessObjectType) {
		this.accessObjectType = accessObjectType;
	}

	public String getKeyField() {
		return keyField;
	}

	public void setKeyField(String keyField) {
		this.keyField = keyField;
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	
	public String getDataAccess() {
		return dataAccess;
	}

	public void setDataAccess(String dataAccess) {
		this.dataAccess = dataAccess;
	}

	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	public String getSqlStatement() {
		return sqlStatement;
	}

	public void setSqlStatement(String sqlStatement) {
		this.sqlStatement = sqlStatement;
	}

	@Override
	public String toString() {
		return "AppAuditTrailRequest [header=" + header + ", userLoginAccount=" + userLoginAccount + ", actionType="
				+ actionType + ", programName=" + programName + ", accessObjectType=" + accessObjectType + ", keyField="
				+ keyField + ", companyType=" + companyType + ", role=" + role + ", recordCount=" + recordCount
				+ ", oldValue=" + oldValue + ", newValue=" + newValue + ", sqlStatement=" + sqlStatement + "]";
	}


}

package com.cathay.service.domain;

public class CustomerProfileRequestBody {
	
	private String apId;
	private int tellerId;
	private String branchNo;
	private String sourceIp;
	private String customerId;
	private String trustKey;
	public String getApId() {
		return apId;
	}
	public void setApId(String apId) {
		this.apId = apId;
	}
	public int getTellerId() {
		return tellerId;
	}
	public void setTellerId(int tellerId) {
		this.tellerId = tellerId;
	}
	public String getBranchNo() {
		return branchNo;
	}
	public void setBranchNo(String branchNo) {
		this.branchNo = branchNo;
	}
	public String getSourceIp() {
		return sourceIp;
	}
	public void setSourceIp(String sourceIp) {
		this.sourceIp = sourceIp;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getTrustKey() {
		return trustKey;
	}
	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}
	@Override
	public String toString() {
		return "CustomerProfileRequestBody [apId=" + apId + ", tellerId=" + tellerId + ", branchNo=" + branchNo
				+ ", sourceIp=" + sourceIp + ", customerId=" + customerId + ", trustKey=" + trustKey + "]";
	}
	
}

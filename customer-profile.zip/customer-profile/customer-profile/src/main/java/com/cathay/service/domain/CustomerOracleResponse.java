package com.cathay.service.domain;



public class CustomerOracleResponse{
	private String customerId;
	private String customerName;
	private String ccVip;
	private String specialIdentity;
	private String lastDateGreeted;
	private String customerClassCode;
	private boolean hasGreeted;
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCcVip() {
		return ccVip;
	}
	public void setCcVip(String ccVip) {
		this.ccVip = ccVip;
	}
	public String getSpecialIdentity() {
		return specialIdentity;
	}
	public void setSpecialIdentity(String specialIdentity) {
		this.specialIdentity = specialIdentity;
	}
	public String getLastDateGreeted() {
		return lastDateGreeted;
	}
	public void setLastDateGreeted(String lastDateGreeted) {
		this.lastDateGreeted = lastDateGreeted;
	}
	public String getCustomerClassCode() {
		return customerClassCode;
	}
	public void setCustomerClassCode(String customerClassCode) {
		this.customerClassCode = customerClassCode;
	}
	public boolean getHasGreeted() {
		return hasGreeted;
	}
	public void setHasGreeted(boolean hasGreeted) {
		this.hasGreeted = hasGreeted;
	}
	@Override
	public String toString() {
		return "CustomerOracleResponse [customerId=" + customerId + ", customerName=" + customerName + ", ccVip="
				+ ccVip + ", specialIdentity=" + specialIdentity + ", lastDateGreeted=" + lastDateGreeted
				+ ", customerClassCode=" + customerClassCode + ", hasGreeted=" + hasGreeted + "]";
	}
	
}

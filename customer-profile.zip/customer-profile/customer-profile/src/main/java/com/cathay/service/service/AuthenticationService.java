package com.cathay.service.service;

import java.util.Collections;
import java.util.concurrent.CompletableFuture;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cathay.service.domain.AuthResult;
import com.cathay.service.domain.AuthenticationRequestBody;
import com.cathay.service.domain.ResponseBody;

@Service
public class AuthenticationService {
	
	private static final Logger LOGGER = LogManager.getLogger(AuthenticationService.class);
	private static final String IO_ERROR_MESSAGE="I/O Error";
	private static final String AUTH_SUCCESS_CODE="0000";
	private static final String NOT_EXISTING_ID_CODE="1111";
	private static final String AUTH_IO_ERROR_MESSAGE = "Failed to call uniqueNumber Authentication Service.";
	@Value("${authentication.uri}")
	private String authURL;
	
	@Async
	public CompletableFuture<ResponseBody<AuthResult>> authenticateUniqueNumber(AuthenticationRequestBody authenticationRequestBody) {
		LOGGER.info("[START @AuthenticationService -authenticateUniqueNumber() ]");
		CompletableFuture<ResponseBody<AuthResult>> compAuth = new CompletableFuture<>();
		ResponseBody<AuthResult> auth = new ResponseBody<>();
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		try {
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			HttpEntity<AuthenticationRequestBody> entity = new HttpEntity<>(authenticationRequestBody, headers);
			ParameterizedTypeReference<ResponseBody<AuthResult>> responseType = new ParameterizedTypeReference<ResponseBody<AuthResult>>() {};
			ResponseEntity<ResponseBody<AuthResult>> authResponse = restTemplate.exchange(authURL, HttpMethod.POST, entity, responseType);
			if(authResponse.getStatusCodeValue() == 200) {
				if(authResponse.getBody().getCode().equals(AUTH_SUCCESS_CODE)) {
					auth.setCode(AUTH_SUCCESS_CODE);
					auth.setResult(authResponse.getBody().getResult());
					LOGGER.info(" CustomerID : " + authResponse.getBody().getResult());
				}else if(authResponse.getBody().getCode().equals(NOT_EXISTING_ID_CODE)) {
					auth.setCode(NOT_EXISTING_ID_CODE);
					auth.setDescription(authResponse.getBody().getDescription());
					auth.setMessage(authResponse.getBody().getMessage());
					auth.setSource(authResponse.getBody().getSource());
					LOGGER.info(" retrieveCustomerID  response : " + authResponse.getBody().getMessage());
				}else {
					auth.setCode(authResponse.getBody().getCode());
					auth.setDescription(authResponse.getBody().getDescription());
					auth.setMessage(authResponse.getBody().getMessage());
					auth.setSource(authResponse.getBody().getSource());
					LOGGER.info(" retrieveCustomerID  response : " + authResponse.getBody().getMessage());
				}
				
				auth.setDescription(authResponse.getBody().getDescription());
				
				auth.setMessage(authResponse.getBody().getMessage());
				
			}else {
				auth.setCode(Integer.toString(authResponse.getStatusCodeValue()));
				auth.setDescription(authResponse.getBody().getDescription());
				auth.setMessage(authResponse.getStatusCode().getReasonPhrase());
				LOGGER.error(AUTH_IO_ERROR_MESSAGE);
			}
			
		} catch (RestClientException e) {
			LOGGER.error(AUTH_IO_ERROR_MESSAGE);
			auth.setMessage(IO_ERROR_MESSAGE + ":" +AUTH_IO_ERROR_MESSAGE);
			LOGGER.error(e.getLocalizedMessage());
		}
		compAuth.complete(auth);
		LOGGER.info("[END @AuthenticationService -authenticateUniqueNumber() ]");
		return compAuth;
	}
	
	
}

package com.cathay.service.domain;

import com.cathay.service.utility.APIHelper;

public class ProfileMongoResponse {
	private int age;
	private int birthMonth;
	private String bankVip;
	private int complaintCount;
	private int currentMonth;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getBirthMonth() {
		return birthMonth;
	}
	public void setBirthMonth(int birthMonth) {
		this.birthMonth = birthMonth;
	}
	public String getBankVip() {
		return bankVip;
	}
	public void setBankVip(String bankVip) {
		this.bankVip = bankVip;
	}
	public int getComplaintCount() {
		return complaintCount;
	}
	public void setComplaintCount(int complaintCount) {
		this.complaintCount = complaintCount;
	}
	public int getCurrentMonth() {
		this.currentMonth = APIHelper.getCurrentMonthInt();
		return currentMonth;
	}
	@Override
	public String toString() {
		return "ProfileMongoResponse [age=" + age + ", birthMonth=" + birthMonth + ", bankVip=" + bankVip
				+ ", complaintCount=" + complaintCount + ", currentMonth=" + currentMonth + "]";
	}
}

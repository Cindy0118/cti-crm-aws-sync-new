package com.cathay.service.domain;

public class Complaint {
	private int dateTime;
	private String complaint;
	public int getDateTime() {
		return dateTime;
	}
	public void setDateTime(int dateTime) {
		this.dateTime = dateTime;
	}
	public String getComplaint() {
		return complaint;
	}
	public void setComplaint(String complaint) {
		this.complaint = complaint;
	}
	@Override
	public String toString() {
		return "Complaint [dateTime=" + dateTime + ", complaint=" + complaint + "]";
	}
	
}

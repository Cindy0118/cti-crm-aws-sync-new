package com.cathay.service.utility;

import com.cathay.service.domain.ParameterValidationResponse;

public class ParamsValidator {
	private ParamsValidator() {
	    throw new IllegalStateException("ParameterValidator class");
	}
	
	public static ParameterValidationResponse validateCustomerProfileParams(String apID, String tellerId, String uniqueNumber, String branch, String token) {
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		validResponse.setValidParams(false);
		
		if(!checkIfStringIsNotNullOrEmpty(apID)) {
			validResponse.setErrorMessage("Query ap_id is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(tellerId)) {
			validResponse.setErrorMessage("Query teller_id is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(uniqueNumber)) {
			validResponse.setErrorMessage("Query unique_number is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(branch)) {
			validResponse.setErrorMessage("Query branch is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(token)) {
			validResponse.setErrorMessage("Query token is empty.");
		}else {
			validResponse.setValidParams(true);
		}
		return validResponse;
	}
	
	private static boolean checkIfStringIsNotNullOrEmpty(String stringToBeValidated) {
		boolean isNotNull = false;
		if(!stringToBeValidated.equals("".trim()) && stringToBeValidated != null) {
			isNotNull = true;
		}
		return isNotNull;
	}
}

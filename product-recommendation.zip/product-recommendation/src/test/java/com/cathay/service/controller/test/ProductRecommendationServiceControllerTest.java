/*package com.cathay.service.controller.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.cathay.service.controller.ProductRecommendationController;

public class ProductRecommendationServiceControllerTest {

	
	
	
	@Test
	public void testProductRecommendationServiceController() {
		fail("Not yet implemented");
	}

	@Test
	public void testStoreRecommendation() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetRecommendation() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testGetCustomerId() {
		fail("Not yet implemented");
		
		//RestTemplate customerIdRetrievalRestTemplate = new RestTemplate();
		
		//ProductRecommendationController productRecommendationController = new ProductRecommendationController(restTemplate, customerIdRetrievalRestTemplate);
	}


}
*/
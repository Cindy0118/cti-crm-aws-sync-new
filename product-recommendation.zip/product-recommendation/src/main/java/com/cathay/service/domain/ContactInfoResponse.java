package com.cathay.service.domain;

public class ContactInfoResponse extends BaseResponse {

	private ContactInfoResult result;

	public ContactInfoResponse() {
		super();
	}

	public ContactInfoResponse(String code, String description) {
		super();
		setCode(code);
		setMessage(Constants.ERROR_MESSAGE);
		setDescription(description);
		setSource(Constants.SOURCE);
	}

	public ContactInfoResult getResult() {
		return result;
	}

	public void setResult(ContactInfoResult result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}

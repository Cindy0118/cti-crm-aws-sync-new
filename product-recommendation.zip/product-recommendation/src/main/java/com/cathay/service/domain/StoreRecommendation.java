package com.cathay.service.domain;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class StoreRecommendation {

	private String customerName;

	@NotBlank
	private String productName;

	@Size(max = 1)
	private String customerTag;

	@NotBlank
	private String refResult;

	private String refMethod;

	private String refSource;

	@Size(max = 5)
	private String obEmployeeNo;

	private String obEmployeeLastName;

	private String refDate;

	private String refTime;

	@NotBlank
	private String trustKey;

	public StoreRecommendation() {
		super();
	}

	public StoreRecommendation(StoreRecommendationRequest request, String date, String time) {
		customerName = request.getCustomerName();
		productName = request.getProductName();
		customerTag = request.getCustomerTag();
		refResult = request.getRefResult();
		refMethod = request.getRefMethod();
		refSource = request.getRefSource();
		obEmployeeNo = request.getObEmployeeNo();
		obEmployeeLastName = request.getObEmployeeLastName();
		refDate = date;
		refTime = time;
		trustKey = request.getTrustKey();
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCustomerTag() {
		return customerTag;
	}

	public void setCustomerTag(String customerTag) {
		this.customerTag = customerTag;
	}

	public String getRefResult() {
		return refResult;
	}

	public void setRefResult(String refResult) {
		this.refResult = refResult;
	}

	public String getRefMethod() {
		return refMethod;
	}

	public void setRefMethod(String refMethod) {
		this.refMethod = refMethod;
	}

	public String getRefSource() {
		return refSource;
	}

	public void setRefSource(String refSource) {
		this.refSource = refSource;
	}

	public String getObEmployeeNo() {
		return obEmployeeNo;
	}

	public void setObEmployeeNo(String obEmployeeNo) {
		this.obEmployeeNo = obEmployeeNo;
	}

	public String getObEmployeeLastName() {
		return obEmployeeLastName;
	}

	public void setObEmployeeLastName(String obEmployeeLastName) {
		this.obEmployeeLastName = obEmployeeLastName;
	}

	public String getRefDate() {
		return refDate;
	}

	public void setRefDate(String refDate) {
		this.refDate = refDate;
	}

	public String getRefTime() {
		return refTime;
	}

	public void setRefTime(String refTime) {
		this.refTime = refTime;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return new StringBuilder("{customerName=" + customerName + ", productName=" + productName + ", customerTag="
				+ customerTag + ", refResult=" + refResult + ", refMethod=" + refMethod + ", refSource=" + refSource
				+ ", obEmployeeNo=" + obEmployeeNo + ", obEmployeeLastName=" + obEmployeeLastName + ", refDate="
				+ refDate + ", refTime=" + refTime + ", trustKey=" + trustKey + "}").toString();
	}
}

package com.cathay.service.domain;

public class RecommendationAndCTIResult extends GetRecommendationResponseBody {

	private boolean isHighlyResponsive;
	private boolean canSuggestCPIN;
	private boolean isContactInformationCorrect;
	private String lowMarketingInd;

	public boolean getIsHighlyResponsive() {
		return isHighlyResponsive;
	}

	public void setIsHighlyResponsive(boolean isHighlyResponsive) {
		this.isHighlyResponsive = isHighlyResponsive;
	}

	public boolean getCanSuggestCPIN() {
		return canSuggestCPIN;
	}

	public void setCanSuggestCPIN(boolean canSuggestCPIN) {
		this.canSuggestCPIN = canSuggestCPIN;
	}

	public boolean getIsContactInformationCorrect() {
		return isContactInformationCorrect;
	}

	public void setIsContactInformationCorrect(boolean isContactInformationCorrect) {
		this.isContactInformationCorrect = isContactInformationCorrect;
	}

	public String getLowMarketingInd() {
		return lowMarketingInd;
	}

	public void setLowMarketingInd(String lowMarketingInd) {
		this.lowMarketingInd = lowMarketingInd;
	}

	public void setOdsResponse(GetRecommendationAndCPINResponse odsResponse) {
		setInstallmentLoansCashAdv(odsResponse.getResult().getInstallmentLoansCashAdv());
		setMemo(odsResponse.getResult().getMemo());
		setMortgage(odsResponse.getResult().getMortgage());
		setPaymentInstallment(odsResponse.getResult().getPaymentInstallment());
		setPersonalLoan(odsResponse.getResult().getPersonalLoan());
	}

	public void setCpinResponse(GetCPINResponse cpinResponse) {
		canSuggestCPIN = cpinResponse.getResult().isCanSuggestCPIN();
		isHighlyResponsive = cpinResponse.getResult().getIsHighlyResponsive();
		isContactInformationCorrect = cpinResponse.getResult().getIsContactInformationCorrect();
	}

}

package com.cathay.service.domain;

public class StoreRecommendationResponse extends BaseResponse {

	private Object result;

	public StoreRecommendationResponse() {
		super();
	}

	public StoreRecommendationResponse(String code, String description) {
		super(code, description);
	}

	public StoreRecommendationResponse(String code, String message, String description, String source) {
		super(code, message, description, source);
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}

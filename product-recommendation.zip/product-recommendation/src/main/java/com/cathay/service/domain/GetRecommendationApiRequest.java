package com.cathay.service.domain;

public class GetRecommendationApiRequest {
	private Header header;
	private String customerId;
	private String trustKey;

	public GetRecommendationApiRequest(Header header, String trustKey, String customerId) {
		this.header = header;
		this.trustKey = trustKey;
		this.customerId = customerId;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + ", customerId=" + customerId + ", trustKey=" + trustKey + "}")
				.toString();
	}

}

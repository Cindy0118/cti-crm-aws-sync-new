package com.cathay.service.domain;

public class StoreRecommendationApiRequest extends StoreRecommendation{
	
	private Header header;
	private String customerId;

	public StoreRecommendationApiRequest(StoreRecommendationRequest request, String customerId, String date, String time) {
		super(request, date, time);
		header = request.getHeader();
		this.customerId = customerId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	} 

	
}

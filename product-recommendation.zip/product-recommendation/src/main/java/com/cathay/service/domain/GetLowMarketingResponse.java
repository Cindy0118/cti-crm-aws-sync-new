package com.cathay.service.domain;

public class GetLowMarketingResponse extends BaseResponse {

	private GetLowMarketingResult result;

	public GetLowMarketingResponse() {
		super();
	}

	public GetLowMarketingResponse(String code, String description) {
		super();
		setCode(code);
		setMessage(Constants.ERROR_MESSAGE);
		setDescription(description);
		setSource(Constants.SOURCE);
	}

	public GetLowMarketingResult getResult() {
		return result;
	}

	public void setResult(GetLowMarketingResult result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}

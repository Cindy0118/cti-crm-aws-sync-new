package com.cathay.service.domain;

public class GetCPINResponseBody {

	boolean isHighlyResponsive;
	boolean canSuggestCPIN;
	boolean isContactInformationCorrect;

	public boolean getIsHighlyResponsive() {
		return isHighlyResponsive;
	}

	public void setIsHighlyResponsive(boolean isHighlyResponsive) {
		this.isHighlyResponsive = isHighlyResponsive;
	}

	public boolean isCanSuggestCPIN() {
		return canSuggestCPIN;
	}

	public void setCanSuggestCPIN(boolean canSuggestCPIN) {
		this.canSuggestCPIN = canSuggestCPIN;
	}

	public boolean getIsContactInformationCorrect() {
		return isContactInformationCorrect;
	}

	public void setIsContactInformationCorrect(boolean isContactInformationCorrect) {
		this.isContactInformationCorrect = isContactInformationCorrect;
	}

}

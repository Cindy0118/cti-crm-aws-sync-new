package com.cathay.service.exception;

public class CPINRetrievalException extends Exception {
	
	private static final long serialVersionUID = -7847049426507097122L;

    public CPINRetrievalException() {
        this("Error while retrieving cpin.");
    }

    public CPINRetrievalException(String message) {
        super(message);
    }

    public CPINRetrievalException(Throwable throwable) {
        super(throwable);
    }

    public CPINRetrievalException(String message, Throwable throwable) {
        super(message, throwable);
    }
}

package com.cathay.service.domain;

public class CreditCardDetailsResponse extends BaseResponse {

	private CreditCardDetails result;

	public CreditCardDetailsResponse() {
		super();
	}

	public CreditCardDetailsResponse(String code, String description) {
		super(code, description);
	}

	public CreditCardDetailsResponse(String code, String message, String description, String source) {
		super(code, message, description, source);
	}

	public CreditCardDetails getResult() {
		return result;
	}

	public void setResult(CreditCardDetails result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}

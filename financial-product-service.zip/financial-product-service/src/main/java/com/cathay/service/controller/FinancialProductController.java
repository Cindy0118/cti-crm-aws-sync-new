package com.cathay.service.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.cathay.service.domain.AppAuditTrailRequest;
import com.cathay.service.domain.AuditTrailResponse;
import com.cathay.service.domain.AutoAcctDebitingResponse;
import com.cathay.service.domain.BaseResponse;
import com.cathay.service.domain.Constants;
import com.cathay.service.domain.CreditCardApiRequest;
import com.cathay.service.domain.CreditCardDetailsResponse;
import com.cathay.service.domain.FinancialProduct2ndLayerRequest;
import com.cathay.service.domain.FinancialProductApiRequest;
import com.cathay.service.domain.FinancialProductApiResponse;
import com.cathay.service.domain.FinancialProductRequest;
import com.cathay.service.domain.PaymentHabitsResponse;
import com.cathay.service.domain.RetrieveCustomerIdRequest;
import com.cathay.service.domain.RetrieveCustomerIdResponse;
import com.cathay.service.domain.SavingsResponse;
import com.cathay.service.domain.UtilityBillsPaymentResponse;

@CrossOrigin
@RestController
public class FinancialProductController {

	private static final Logger LOGGER = LogManager.getLogger(FinancialProductController.class);
	private static final String URL_SOURCE = "Data Source URL: {}";

	private RestTemplate restTemplate;

	@Value("${get-financial-products-api}")
	protected String getFinancialProductsApiUrl;

	@Value("${get-utility-bills-payment-api}")
	protected String getUtilityBillsPaymentUrl;

	@Value("${get-credit-cards-api}")
	protected String getCreditCardsUrl;

	@Value("${get-auto-acct-debiting-api}")
	protected String getAutoAccountDebitingUrl;

	@Value("${get-payment-habits-api}")
	protected String getPaymentHabitsUrl;

	@Value("${get-savings-api}")
	protected String getSavingsUrl;

	@Value("${get-customerid-api}")
	protected String getCustomerIdApiUrl;

	@Value("${ms-source-name}")
	protected String sourceNameMS;

	@Value("${url.audit-trail-api}")
	private String saveAuditTrailUrl;

	AppAuditTrailRequest auditRequest;

	@Autowired
	public FinancialProductController(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	@PostMapping("${get-financial-products}")
	public BaseResponse getFinancialProducts(@Valid @RequestBody FinancialProductRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GET_FINANCIAL_PRODUCTS_REQUEST, request);

		FinancialProductApiResponse response = null;

		auditRequest = new AppAuditTrailRequest();
		auditRequest.setHeader(request.getHeader());
		auditRequest.setAccessObjectType("V");
		auditRequest.setActionType("P");
		auditRequest.setUserLoginAccount(request.getHeader().getEmployeeId());
		auditRequest.setProgramName("getFinancialProducts_oracle");
		auditRequest.setKeyField(Constants.KEY_FIELD);
		auditRequest.setCompanyType("2");

		try {
			RetrieveCustomerIdRequest retrieveCustomerIdRequest = new RetrieveCustomerIdRequest(request.getHeader(),
					request.getUniqueNumber(), request.getTrustKey());
			RetrieveCustomerIdResponse retrieveCustomerIdResponse = getCustomerId(retrieveCustomerIdRequest);

			if (retrieveCustomerIdResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				String customerId = retrieveCustomerIdResponse.getResult().getCustomerId();

				FinancialProductApiRequest apiRequest = new FinancialProductApiRequest(request.getHeader(),
						request.getTrustKey(), customerId);

				response = restTemplate.postForObject(getFinancialProductsApiUrl, apiRequest,
						FinancialProductApiResponse.class);

				auditRequest.setDataAccess(Constants.SUCCESS);
				auditRequest.setRecordCount(1);
			} else {
				response = new FinancialProductApiResponse(retrieveCustomerIdResponse.getCode(),
						retrieveCustomerIdResponse.getMessage(), retrieveCustomerIdResponse.getDescription(),
						retrieveCustomerIdResponse.getSource());
			}
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.GET_FINANCIAL_PRODUCTS_HTTP_ERROR, getFinancialProductsApiUrl);
			LOGGER.error(description, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new FinancialProductApiResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new FinancialProductApiResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		saveAuditTrail(auditRequest);

		LOGGER.info(Constants.GET_FINANCIAL_PRODUCTS_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${get-savings}")
	public BaseResponse getSavings(@Valid @RequestBody FinancialProductRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GET_SAVINGS_REQUEST, request);

		SavingsResponse response = null;

		auditRequest = new AppAuditTrailRequest();
		auditRequest.setHeader(request.getHeader());
		auditRequest.setAccessObjectType("V");
		auditRequest.setActionType("P");
		auditRequest.setUserLoginAccount(request.getHeader().getEmployeeId());
		auditRequest.setProgramName("getSavings_oracle");
		auditRequest.setKeyField(Constants.KEY_FIELD);
		auditRequest.setCompanyType("2");

		try {
			RetrieveCustomerIdRequest retrieveCustomerIdRequest = new RetrieveCustomerIdRequest(request.getHeader(),
					request.getUniqueNumber(), request.getTrustKey());
			RetrieveCustomerIdResponse retrieveCustomerIdResponse = getCustomerId(retrieveCustomerIdRequest);

			if (retrieveCustomerIdResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				String customerId = retrieveCustomerIdResponse.getResult().getCustomerId();

				FinancialProductApiRequest apiRequest = new FinancialProductApiRequest(request.getHeader(),
						request.getTrustKey(), customerId);

				response = restTemplate.postForObject(getSavingsUrl, apiRequest, SavingsResponse.class);

				auditRequest.setDataAccess(Constants.SUCCESS);
				auditRequest.setRecordCount(response.getResult().getRecordNum());
			} else {
				auditRequest.setDataAccess(Constants.FAILURE);
				auditRequest.setRecordCount(0);
				response = new SavingsResponse(retrieveCustomerIdResponse.getCode(),
						retrieveCustomerIdResponse.getMessage(), retrieveCustomerIdResponse.getDescription(),
						retrieveCustomerIdResponse.getSource());
			}
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.GET_SAVINGS_HTTP_ERROR, getSavingsUrl);
			LOGGER.error(description, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new SavingsResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new SavingsResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		saveAuditTrail(auditRequest);

		LOGGER.info(Constants.GET_SAVINGS_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return response;
	}

	@PostMapping("${get-utility-bills-payment}")
	public BaseResponse getUtilityBillsPayment(@Valid @RequestBody FinancialProductRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GET_UTILITY_BILLS_PAYMENT_REQUEST, request);

		UtilityBillsPaymentResponse response = null;

		auditRequest = new AppAuditTrailRequest();
		auditRequest.setHeader(request.getHeader());
		auditRequest.setAccessObjectType("V");
		auditRequest.setActionType("P");
		auditRequest.setUserLoginAccount(request.getHeader().getEmployeeId());
		auditRequest.setProgramName("getUtilityBillsPayment_oracle");
		auditRequest.setKeyField("YNNNNNNY");
		auditRequest.setCompanyType("2");

		try {
			RetrieveCustomerIdRequest retrieveCustomerIdRequest = new RetrieveCustomerIdRequest(request.getHeader(),
					request.getUniqueNumber(), request.getTrustKey());
			RetrieveCustomerIdResponse retrieveCustomerIdResponse = getCustomerId(retrieveCustomerIdRequest);

			if (retrieveCustomerIdResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				String customerId = retrieveCustomerIdResponse.getResult().getCustomerId();

				FinancialProductApiRequest apiRequest = new FinancialProductApiRequest(request.getHeader(),
						request.getTrustKey(), customerId);

				response = restTemplate.postForObject(getUtilityBillsPaymentUrl, apiRequest,
						UtilityBillsPaymentResponse.class);

				auditRequest.setDataAccess(Constants.SUCCESS);
				auditRequest.setRecordCount(Integer.parseInt(response.getResult().getRecordNum()));
			} else {
				auditRequest.setDataAccess(Constants.FAILURE);
				auditRequest.setRecordCount(0);
				response = new UtilityBillsPaymentResponse(retrieveCustomerIdResponse.getCode(),
						retrieveCustomerIdResponse.getMessage(), retrieveCustomerIdResponse.getDescription(),
						retrieveCustomerIdResponse.getSource());
			}
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.GET_UTILITY_BILLS_PAYMENT_HTTP_ERROR,
					getUtilityBillsPaymentUrl);
			LOGGER.error(description, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new UtilityBillsPaymentResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new UtilityBillsPaymentResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		saveAuditTrail(auditRequest);

		LOGGER.info(Constants.GET_UTILITY_BILLS_PAYMENT_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${get-auto-acct-debiting}")
	public BaseResponse getAutoAccountDebiting(@Valid @RequestBody FinancialProductRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GET_AUTO_ACCOUNT_DEBITING_REQUEST, request);

		AutoAcctDebitingResponse response = null;

		auditRequest = new AppAuditTrailRequest();
		auditRequest.setHeader(request.getHeader());
		auditRequest.setAccessObjectType("V");
		auditRequest.setActionType("P");
		auditRequest.setUserLoginAccount(request.getHeader().getEmployeeId());
		auditRequest.setProgramName("getAutoAccountDebiting_oracle");
		auditRequest.setKeyField("YNNNNNYN");
		auditRequest.setCompanyType("2");

		try {
			RetrieveCustomerIdRequest retrieveCustomerIdRequest = new RetrieveCustomerIdRequest(request.getHeader(),
					request.getUniqueNumber(), request.getTrustKey());
			RetrieveCustomerIdResponse retrieveCustomerIdResponse = getCustomerId(retrieveCustomerIdRequest);

			if (retrieveCustomerIdResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				String customerId = retrieveCustomerIdResponse.getResult().getCustomerId();

				FinancialProductApiRequest apiRequest = new FinancialProductApiRequest(request.getHeader(),
						request.getTrustKey(), customerId);

				response = restTemplate.postForObject(getAutoAccountDebitingUrl, apiRequest,
						AutoAcctDebitingResponse.class);

				auditRequest.setDataAccess(Constants.SUCCESS);
				auditRequest.setRecordCount(Integer.parseInt(response.getResult().getRecordNum()));
			} else {
				auditRequest.setDataAccess(Constants.FAILURE);
				auditRequest.setRecordCount(0);
				response = new AutoAcctDebitingResponse(retrieveCustomerIdResponse.getCode(),
						retrieveCustomerIdResponse.getMessage(), retrieveCustomerIdResponse.getDescription(),
						retrieveCustomerIdResponse.getSource());
			}
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.GET_AUTO_ACCOUNT_DEBITING_HTTP_ERROR,
					getAutoAccountDebitingUrl);
			LOGGER.error(description, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new AutoAcctDebitingResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new AutoAcctDebitingResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		saveAuditTrail(auditRequest);

		LOGGER.info(Constants.GET_AUTO_ACCOUNT_DEBITING_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${get-payment-habits}")
	public BaseResponse getPaymentHabits(@Valid @RequestBody FinancialProductRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GET_PAYMENT_HABITS_REQUEST, request);

		PaymentHabitsResponse response = null;

		auditRequest = new AppAuditTrailRequest();
		auditRequest.setHeader(request.getHeader());
		auditRequest.setAccessObjectType("V");
		auditRequest.setActionType("P");
		auditRequest.setUserLoginAccount(request.getHeader().getEmployeeId());
		auditRequest.setProgramName("getPaymentHabits_oracle");
		auditRequest.setKeyField(Constants.KEY_FIELD);
		auditRequest.setCompanyType("2");

		try {
			RetrieveCustomerIdRequest retrieveCustomerIdRequest = new RetrieveCustomerIdRequest(request.getHeader(),
					request.getUniqueNumber(), request.getTrustKey());
			RetrieveCustomerIdResponse retrieveCustomerIdResponse = getCustomerId(retrieveCustomerIdRequest);

			if (retrieveCustomerIdResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				String customerId = retrieveCustomerIdResponse.getResult().getCustomerId();

				FinancialProductApiRequest apiRequest = new FinancialProductApiRequest(request.getHeader(),
						request.getTrustKey(), customerId);

				response = restTemplate.postForObject(getPaymentHabitsUrl, apiRequest, PaymentHabitsResponse.class);

				auditRequest.setDataAccess(Constants.SUCCESS);
				auditRequest.setRecordCount(Integer.parseInt(response.getResult().getRecordNum()));
			} else {
				auditRequest.setDataAccess(Constants.FAILURE);
				auditRequest.setRecordCount(0);
				response = new PaymentHabitsResponse(retrieveCustomerIdResponse.getCode(),
						retrieveCustomerIdResponse.getMessage(), retrieveCustomerIdResponse.getDescription(),
						retrieveCustomerIdResponse.getSource());
			}
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.GET_PAYMENT_HABITS_HTTP_ERROR, getPaymentHabitsUrl);
			LOGGER.error(description, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new PaymentHabitsResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new PaymentHabitsResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		saveAuditTrail(auditRequest);

		LOGGER.info(Constants.GET_PAYMENT_HABITS_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${get-credit-cards}")
	public BaseResponse getCreditCardDetails(@Valid @RequestBody FinancialProduct2ndLayerRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GET_CREDIT_CARDS_REQUEST, request);

		CreditCardDetailsResponse response = null;

		auditRequest = new AppAuditTrailRequest();
		auditRequest.setHeader(request.getHeader());
		auditRequest.setAccessObjectType("V");
		auditRequest.setActionType("P");
		auditRequest.setUserLoginAccount(request.getHeader().getEmployeeId());
		auditRequest.setProgramName("getCreditCardDetails_oracle");
		auditRequest.setKeyField("YNNNNNYY");
		auditRequest.setCompanyType("2");

		try {
			RetrieveCustomerIdRequest retrieveCustomerIdRequest = new RetrieveCustomerIdRequest(request.getHeader(),
					request.getUniqueNumber(), request.getTrustKey());
			RetrieveCustomerIdResponse retrieveCustomerIdResponse = getCustomerId(retrieveCustomerIdRequest);

			if (retrieveCustomerIdResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				String customerId = retrieveCustomerIdResponse.getResult().getCustomerId();

				CreditCardApiRequest apiRequest = new CreditCardApiRequest(request.getHeader(), request.getTrustKey(),
						customerId, request.getQueryCardInd());

				response = restTemplate.postForObject(getCreditCardsUrl, apiRequest, CreditCardDetailsResponse.class);

				auditRequest.setDataAccess(Constants.SUCCESS);
				auditRequest.setRecordCount(
						response.getResult() != null ? Integer.parseInt(response.getResult().getCountNo()) : 0);
			} else {
				auditRequest.setDataAccess(Constants.FAILURE);
				auditRequest.setRecordCount(0);
				response = new CreditCardDetailsResponse(retrieveCustomerIdResponse.getCode(),
						retrieveCustomerIdResponse.getMessage(), retrieveCustomerIdResponse.getDescription(),
						retrieveCustomerIdResponse.getSource());
			}
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.GET_CREDIT_CARDS_HTTP_ERROR, getCreditCardsUrl);
			LOGGER.error(description, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new CreditCardDetailsResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			auditRequest.setDataAccess(Constants.FAILURE);
			auditRequest.setRecordCount(0);
			response = new CreditCardDetailsResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		saveAuditTrail(auditRequest);

		LOGGER.info(Constants.GET_CREDIT_CARDS_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	private RetrieveCustomerIdResponse getCustomerId(RetrieveCustomerIdRequest request) {
		LOGGER.info(Constants.RETRIEVE_CUSTOMER_ID_REQUEST, request);
		RetrieveCustomerIdResponse response = null;

		try {
			response = restTemplate.postForObject(getCustomerIdApiUrl, request, RetrieveCustomerIdResponse.class);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.RETRIEVE_CUSTOMER_ID_HTTP_ERROR, getCustomerIdApiUrl);
			LOGGER.error(description, e);
			response = new RetrieveCustomerIdResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new RetrieveCustomerIdResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.RETRIEVE_CUSTOMER_ID_RESPONSE, response);
		return response;
	}

	private void saveAuditTrail(AppAuditTrailRequest request) {
		LOGGER.info(Constants.AUDIT_TRAIL_START);

		try {
			LOGGER.info(Constants.SAVING_AUDIT_TRAIL);
			restTemplate.postForObject(saveAuditTrailUrl, request, AuditTrailResponse.class);
			LOGGER.info(Constants.SUCCESS);
		} catch (HttpClientErrorException e) {
			LOGGER.error(Constants.FAILURE);
			LOGGER.error(URL_SOURCE, saveAuditTrailUrl);
			LOGGER.error(e);
		} catch (Exception e) {
			LOGGER.error(Constants.FAILURE);
			LOGGER.error(Constants.GENERIC_ERROR, e);
		}

		LOGGER.info(Constants.AUDIT_TRAIL_END);
	}

}

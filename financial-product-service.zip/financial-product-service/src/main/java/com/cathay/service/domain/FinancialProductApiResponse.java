package com.cathay.service.domain;

public class FinancialProductApiResponse extends BaseResponse {

	private FinancialProductApiResponseBody result;

	public FinancialProductApiResponse() {
		super();
	}

	public FinancialProductApiResponse(String code, String description) {
		super(code, description);
	}

	public FinancialProductApiResponse(String code, String message, String description, String source) {
		super(code, message, description, source);
	}

	public FinancialProductApiResponseBody getResult() {
		return result;
	}

	public void setResult(FinancialProductApiResponseBody result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}

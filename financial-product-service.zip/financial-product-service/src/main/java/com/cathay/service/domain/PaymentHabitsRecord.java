package com.cathay.service.domain;

public class PaymentHabitsRecord {

	private String stmtYearMonth;
	private String txnDate;
	private String payChannelTypeDesc;
	private String payAmt;

	public String getStmtYearMonth() {
		return stmtYearMonth;
	}

	public void setStmtYearMonth(String stmtYearMonth) {
		this.stmtYearMonth = stmtYearMonth;
	}

	public String getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

	public String getPayChannelTypeDesc() {
		return payChannelTypeDesc;
	}

	public void setPayChannelTypeDesc(String payChannelTypeDesc) {
		this.payChannelTypeDesc = payChannelTypeDesc;
	}

	public String getPayAmt() {
		return payAmt;
	}

	public void setPayAmt(String payAmt) {
		this.payAmt = payAmt;
	}

	@Override
	public String toString() {
		return new StringBuilder("{stmtYearMonth=" + stmtYearMonth + ", txnDate=" + txnDate + ", payChannelTypeDesc="
				+ payChannelTypeDesc + ", payAmt=" + payAmt + "}").toString();
	}
}

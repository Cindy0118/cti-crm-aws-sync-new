package com.cathay.service.domain;

import java.util.List;

public class Savings {

	private String customerId;
	private int recordNum;
	private List<SavingsRecord> records;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public int getRecordNum() {
		return recordNum;
	}

	public void setRecordNum(int recordNum) {
		this.recordNum = recordNum;
	}

	public List<SavingsRecord> getRecords() {
		return records;
	}

	public void setRecords(List<SavingsRecord> records) {
		this.records = records;
	}

	@Override
	public String toString() {
		return new StringBuilder(
				"{customerId=" + customerId + ", recordNum=" + recordNum + ", records=" + records + "}").toString();
	}

}

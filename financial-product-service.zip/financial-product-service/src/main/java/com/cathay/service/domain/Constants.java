package com.cathay.service.domain;

public class Constants {

	// Logging scope format
	public static final String LOGGER_START = "[START @{} ({})]";
	public static final String LOGGER_END = "[END @{} ({})]";

	// Response Code
	public static final String SUCCESS_CODE = "0000";
	public static final String NO_DATA_CODE = "1001";
	public static final String ERROR_CODE = "1111";

	// Response Message
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String ERROR_MESSAGE = "Error";

	// Origin or Source
	public static final String SOURCE = "Financial Product Service";

	// Get financial products
	public static final String GET_FINANCIAL_PRODUCTS_REQUEST = "Get financial products request: {}";
	public static final String GET_FINANCIAL_PRODUCTS_RESPONSE = "Get financial products response: {}";

	// Get savings
	public static final String GET_SAVINGS_REQUEST = "Get savings request: {}";
	public static final String GET_SAVINGS_RESPONSE = "Get savings response: {}";

	// Get utility bills payment
	public static final String GET_UTILITY_BILLS_PAYMENT_REQUEST = "Get utility bills payment request: {}";
	public static final String GET_UTILITY_BILLS_PAYMENT_RESPONSE = "Get utility bills payment response: {}";

	// Get auto account debiting
	public static final String GET_AUTO_ACCOUNT_DEBITING_REQUEST = "Get auto account debiting request: {}";
	public static final String GET_AUTO_ACCOUNT_DEBITING_RESPONSE = "Get auto account debiting response: {}";

	// Get payment habits
	public static final String GET_PAYMENT_HABITS_REQUEST = "Get payment habits request: {}";
	public static final String GET_PAYMENT_HABITS_RESPONSE = "Get payment habits response: {}";
	
	// Get credit cards
	public static final String GET_CREDIT_CARDS_REQUEST = "Get credit cards request: {}";
	public static final String GET_CREDIT_CARDS_RESPONSE = "Get credit cards response: {}";

	// Get trust key service
	public static final String RETRIEVE_CUSTOMER_ID_REQUEST = "Retrieve customer id request: {}";
	public static final String RETRIEVE_CUSTOMER_ID_RESPONSE = "Retrieve customer id response: {}";

	/** Error Description **/
	public static final String GENERIC_ERROR = "An error occured, please see log details";
	public static final String BAD_REQUEST = "Invalid argument or request parameters";
	public static final String TYPE_MISMATCH_ERROR = "Type mismatch error, please check your request parameters";
	public static final String RETRIEVE_CUSTOMER_ID_HTTP_ERROR = "Error retrieving customer id using this url %s";
	public static final String GET_FINANCIAL_PRODUCTS_HTTP_ERROR = "Error getting financial products using this url %s";
	public static final String GET_SAVINGS_HTTP_ERROR = "Error getting savings using this url %s";
	public static final String GET_UTILITY_BILLS_PAYMENT_HTTP_ERROR = "Error getting utility bills payment using this url %s";
	public static final String GET_AUTO_ACCOUNT_DEBITING_HTTP_ERROR = "Error getting auto account debiting using this url %s";
	public static final String GET_PAYMENT_HABITS_HTTP_ERROR = "Error getting payment habits using this url %s";
	public static final String GET_CREDIT_CARDS_HTTP_ERROR = "Error credit cards using this url %s";

	public static final String AUDIT_TRAIL_START = "Audit trail start";
	public static final String SAVING_AUDIT_TRAIL = "Saving audit trail..";
	public static final String KEY_FIELD = "YNNNNNNN";
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	public static final String AUDIT_TRAIL_END = "Audit trail end";

	private Constants() {
	}

}

package com.cathay.service.domain;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class FinancialProductRequest {
	
	@NotNull
	@Valid
	private Header header;
	@NotBlank
	private String trustKey;
	@NotBlank
	private String uniqueNumber;

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public String getUniqueNumber() {
		return uniqueNumber;
	}

	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}

	@Override
	public String toString() {
		return new StringBuilder(
				"{header=" + header + ", trustKey=" + trustKey + ", uniqueNumber=" + uniqueNumber + "}").toString();
	}

}

package com.cathay.service.helper;

import com.cathay.service.domain.Header;
import com.cathay.service.domain.ParameterValidationResponse;

public class ParamsValidator {
	private ParamsValidator() {
	    throw new IllegalStateException("ParameterValidator class");
	}
	
	public static ParameterValidationResponse validateFinancialProductParams(Header header, String trustKey, String uniqueNumber) {
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		validResponse.setValidParams(false);
		
		if(StringHelper.isEmpty(header.getApId())) {
			validResponse.setErrorMessage("Query ap_id is empty.");
		}else if(StringHelper.isEmpty(header.getEmployeeId())) {
			validResponse.setErrorMessage("Query employee_id is empty.");
		}else if(StringHelper.isEmpty(header.getBranchId())) {
			validResponse.setErrorMessage("Query branch_id is empty.");
		}else if(StringHelper.isEmpty(header.getClientIp())) {
			validResponse.setErrorMessage("Query client_ip is empty.");
		}else if(StringHelper.isEmpty(header.getTxnDateTime())) {
			validResponse.setErrorMessage("Query txn_date_time is empty.");
		}else if(StringHelper.isEmpty(uniqueNumber)) {
			validResponse.setErrorMessage("Query unique_number is empty.");
		}else if(StringHelper.isEmpty(trustKey)) {
			validResponse.setErrorMessage("Query trustKey is empty.");
		}else {
			validResponse.setValidParams(true);
		}
		return validResponse;
	}
	
	public static ParameterValidationResponse validateCreditCardParams(Header header, String trustKey, String uniqueNumber, String queryCardInd) {
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		validResponse.setValidParams(false);
		
		if(StringHelper.isEmpty(header.getApId())) {
			validResponse.setErrorMessage("Query ap_id is empty.");
		}else if(StringHelper.isEmpty(header.getEmployeeId())) {
			validResponse.setErrorMessage("Query employee_id is empty.");
		}else if(StringHelper.isEmpty(header.getBranchId())) {
			validResponse.setErrorMessage("Query branch_id is empty.");
		}else if(StringHelper.isEmpty(header.getClientIp())) {
			validResponse.setErrorMessage("Query client_ip is empty.");
		}else if(StringHelper.isEmpty(header.getTxnDateTime())) {
			validResponse.setErrorMessage("Query txn_date_time is empty.");
		}else if(StringHelper.isEmpty(uniqueNumber)) {
			validResponse.setErrorMessage("Query unique_number is empty.");
		}else if(StringHelper.isEmpty(trustKey)) {
			validResponse.setErrorMessage("Query trustKey is empty.");
		}else if(StringHelper.isEmpty(queryCardInd)) {
			validResponse.setErrorMessage("Query query_card_ind is empty.");
		}else {
			validResponse.setValidParams(true);
		}
		return validResponse;
	}
}

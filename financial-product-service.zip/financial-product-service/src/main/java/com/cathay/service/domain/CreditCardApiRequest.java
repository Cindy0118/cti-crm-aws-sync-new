package com.cathay.service.domain;

public class CreditCardApiRequest extends FinancialProductApiRequest {

	private String queryCardInd;

	public CreditCardApiRequest(Header header, String trustKey, String customerId, String queryCardInd) {
		super(header, trustKey, customerId);
		this.queryCardInd = queryCardInd;
	}

	public String getQueryCardInd() {
		return queryCardInd;
	}

	public void setQueryCardInd(String queryCardInd) {
		this.queryCardInd = queryCardInd;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + getHeader() + ", trustKey=" + getTrustKey() + ", customerId="
				+ getCustomerId() + ", queryCardInd=" + queryCardInd + "}").toString();
	}

}

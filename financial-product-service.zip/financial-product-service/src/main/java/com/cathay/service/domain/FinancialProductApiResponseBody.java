package com.cathay.service.domain;

public class FinancialProductApiResponseBody {

	private String customerId;
	private int primaryCcCount;
	private int secondaryCcCount;
	private int businessCcCount;
	private int primarySecondCcCount;
	private String ccStmtAutoDeductInd;
	private String ccPubAutoDeductInd;
	private String allDpActiveInd;
	private String houseLoanInd;
	private String creditLoanInd;
	private String mfInd;
	private String strInd;
	private String insAgentLifeInd;
	private String insAgentPtyInd;
	private int autoPayFailCnt;
	private int autoPayRmbFailCnt;
	private int autoPayUsaFailCnt;
	private int generalNextMonExpirePs;
	private int platinumNextMonExpirePs;
	private int clearedCostcoBonusBal;
	private int y1AsianExpireMiles;
	private String l3TimesCcPayMethodDesc;
	private String l3TimesCcPayRateDesc;

	public FinancialProductApiResponseBody() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public int getPrimaryCcCount() {
		return primaryCcCount;
	}

	public void setPrimaryCcCount(int primaryCcCount) {
		this.primaryCcCount = primaryCcCount;
	}

	public int getSecondaryCcCount() {
		return secondaryCcCount;
	}

	public void setSecondaryCcCount(int secondaryCcCount) {
		this.secondaryCcCount = secondaryCcCount;
	}

	public int getBusinessCcCount() {
		return businessCcCount;
	}

	public void setBusinessCcCount(int businessCcCount) {
		this.businessCcCount = businessCcCount;
	}

	public int getPrimarySecondCcCount() {
		return primarySecondCcCount;
	}

	public void setPrimarySecondCcCount(int primarySecondCcCount) {
		this.primarySecondCcCount = primarySecondCcCount;
	}

	public String getCcStmtAutoDeductInd() {
		return ccStmtAutoDeductInd;
	}

	public void setCcStmtAutoDeductInd(String ccStmtAutoDeductInd) {
		this.ccStmtAutoDeductInd = ccStmtAutoDeductInd;
	}

	public String getCcPubAutoDeductInd() {
		return ccPubAutoDeductInd;
	}

	public void setCcPubAutoDeductInd(String ccPubAutoDeductInd) {
		this.ccPubAutoDeductInd = ccPubAutoDeductInd;
	}

	public String getAllDpActiveInd() {
		return allDpActiveInd;
	}

	public void setAllDpActiveInd(String allDpActiveInd) {
		this.allDpActiveInd = allDpActiveInd;
	}

	public String getHouseLoanInd() {
		return houseLoanInd;
	}

	public void setHouseLoanInd(String houseLoanInd) {
		this.houseLoanInd = houseLoanInd;
	}

	public String getCreditLoanInd() {
		return creditLoanInd;
	}

	public void setCreditLoanInd(String creditLoanInd) {
		this.creditLoanInd = creditLoanInd;
	}

	public String getMfInd() {
		return mfInd;
	}

	public void setMfInd(String mfInd) {
		this.mfInd = mfInd;
	}

	public String getStrInd() {
		return strInd;
	}

	public void setStrInd(String strInd) {
		this.strInd = strInd;
	}

	public String getInsAgentLifeInd() {
		return insAgentLifeInd;
	}

	public void setInsAgentLifeInd(String insAgentLifeInd) {
		this.insAgentLifeInd = insAgentLifeInd;
	}

	public int getAutoPayFailCnt() {
		return autoPayFailCnt;
	}

	public void setAutoPayFailCnt(int autoPayFailCnt) {
		this.autoPayFailCnt = autoPayFailCnt;
	}

	public int getAutoPayRmbFailCnt() {
		return autoPayRmbFailCnt;
	}

	public void setAutoPayRmbFailCnt(int autoPayRmbFailCnt) {
		this.autoPayRmbFailCnt = autoPayRmbFailCnt;
	}

	public int getAutoPayUsaFailCnt() {
		return autoPayUsaFailCnt;
	}

	public void setAutoPayUsaFailCnt(int autoPayUsaFailCnt) {
		this.autoPayUsaFailCnt = autoPayUsaFailCnt;
	}

	public int getGeneralNextMonExpirePs() {
		return generalNextMonExpirePs;
	}

	public void setGeneralNextMonExpirePs(int generalNextMonExpirePs) {
		this.generalNextMonExpirePs = generalNextMonExpirePs;
	}

	public int getPlatinumNextMonExpirePs() {
		return platinumNextMonExpirePs;
	}

	public void setPlatinumNextMonExpirePs(int platinumNextMonExpirePs) {
		this.platinumNextMonExpirePs = platinumNextMonExpirePs;
	}

	public int getClearedCostcoBonusBal() {
		return clearedCostcoBonusBal;
	}

	public void setClearedCostcoBonusBal(int clearedCostcoBonusBal) {
		this.clearedCostcoBonusBal = clearedCostcoBonusBal;
	}

	public int getY1AsianExpireMiles() {
		return y1AsianExpireMiles;
	}

	public void setY1AsianExpireMiles(int y1AsianExpireMiles) {
		this.y1AsianExpireMiles = y1AsianExpireMiles;
	}

	public String getL3TimesCcPayMethodDesc() {
		return l3TimesCcPayMethodDesc;
	}

	public void setL3TimesCcPayMethodDesc(String l3TimesCcPayMethodDesc) {
		this.l3TimesCcPayMethodDesc = l3TimesCcPayMethodDesc;
	}

	public String getL3TimesCcPayRateDesc() {
		return l3TimesCcPayRateDesc;
	}

	public void setL3TimesCcPayRateDesc(String l3TimesCcPayRateDesc) {
		this.l3TimesCcPayRateDesc = l3TimesCcPayRateDesc;
	}

	public String getInsAgentPtyInd() {
		return insAgentPtyInd;
	}

	public void setInsAgentPtyInd(String insAgentPtyInd) {
		this.insAgentPtyInd = insAgentPtyInd;
	}

	@Override
	public String toString() {
		return new StringBuilder("{customerId=" + customerId + ", primaryCcCount=" + primaryCcCount
				+ ", secondaryCcCount=" + secondaryCcCount + ", businessCcCount=" + businessCcCount
				+ ", primarySecondCcCount=" + primarySecondCcCount + ", ccStmtAutoDeductInd=" + ccStmtAutoDeductInd
				+ ", ccPubAutoDeductInd=" + ccPubAutoDeductInd + ", allDpActiveInd=" + allDpActiveInd
				+ ", houseLoanInd=" + houseLoanInd + ", creditLoanInd=" + creditLoanInd + ", mfInd=" + mfInd
				+ ", strInd=" + strInd + ", insAgentLifeInd=" + insAgentLifeInd + ", insAgentPtyInd=" + insAgentPtyInd
				+ ", autoPayFailCnt=" + autoPayFailCnt + ", autoPayRmbFailCnt=" + autoPayRmbFailCnt
				+ ", autoPayUsaFailCnt=" + autoPayUsaFailCnt + ", generalNextMonExpirePs=" + generalNextMonExpirePs
				+ ", platinumNextMonExpirePs=" + platinumNextMonExpirePs + ", clearedCostcoBonusBal="
				+ clearedCostcoBonusBal + ", y1AsianExpireMiles=" + y1AsianExpireMiles + ", l3TimesCcPayMethodDesc="
				+ l3TimesCcPayMethodDesc + ", l3TimesCcPayRateDesc=" + l3TimesCcPayRateDesc + "}").toString();
	}

}

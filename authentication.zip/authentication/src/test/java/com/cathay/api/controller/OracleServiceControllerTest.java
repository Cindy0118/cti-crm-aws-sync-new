package com.cathay.api.controller;
/*import static org.springframework.test.web.client.ExpectedCount.once;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import com.cathay.api.controller.OracleServiceController;
import com.cathay.api.domain.Header;
import com.cathay.api.domain.RetrieveCustomerIdRequest;
import com.cathay.api.domain.StoreUniqueNumberRequest;
import com.cathay.api.exception.TrustKeyValidationException;
import com.cathay.api.repository.mock.MockCustUniqueNumberRepository;
import com.google.gson.Gson;

public class OracleServiceControllerTest {

	private RestTemplate restTemplate;
		
	private Gson gson;
	
	private MockCustUniqueNumberRepository mockCustUniqueNumberRepository;
	
	@Before
    public void setUp() {
		
	 restTemplate = new RestTemplate();
	 gson = new Gson();

    }
	
	@Test
	public void testStoreUniqueNumberAndCustomerId() throws JSONException {

		mockCustUniqueNumberRepository = new MockCustUniqueNumberRepository();
		
		String url = "https://virtserver.swaggerhub.com/jicunxi05/token_validation/1.0.0/crm-encrypt/p2/validateTrustKey";
		
		OracleServiceController oracleServiceController = new OracleServiceController(restTemplate, mockCustUniqueNumberRepository);
		oracleServiceController.authenticationServiceUrl = url;
		
		String mockedDefaultResponseData = "{\r\n" + 
				"  \"Header\": {\r\n" + 
				"    \"apId\": \"CRMLXCRM01\",\r\n" + 
				"    \"branchId\": 15,\r\n" + 
				"    \"employeeId\": 13063,\r\n" + 
				"    \"clientIp\": \"127.0.0.1\",\r\n" + 
				"    \"txnDateTime\": \"string\"\r\n" + 
				"  },\r\n" + 
				"  \"code\": \"0000\",\r\n" + 
				"  \"desc\": \"Success\",\r\n" + 
				"  \"trustKey\": \"db04b549-c602-40bc-ad4b-4500b61ee0c0-1525750484063\"\r\n" + 
				"}";

		
		MockRestServiceServer server = MockRestServiceServer.bindTo(restTemplate).build();
		
		server.expect(once(), requestTo(url)).andExpect(method(HttpMethod.POST))
		.andRespond(withSuccess(mockedDefaultResponseData, MediaType.APPLICATION_JSON));
		
		
		StoreUniqueNumberRequest storeUniqueNumberRequest = new StoreUniqueNumberRequest();
		Header Header = new Header();
		
		Header.setApId("CRMLXCRM01");
		Header.setBranchId("15");
		Header.setEmployeeId("13063");
		Header.setClientIp("127.0.0.1");
		Header.setTxnDateTime("kahitanongdate");
		storeUniqueNumberRequest.setCustomerId("123");
		storeUniqueNumberRequest.setUniqueNumber("111");
		storeUniqueNumberRequest.setTrustKey("454");
		storeUniqueNumberRequest.setHeader(Header);
	
		Object response = oracleServiceController.storeUniqueNumber(storeUniqueNumberRequest);
		
		String expected = "{\r\n" + 
				"    \"message\": \"Success\",\r\n" + 
				"    \"body\": {\r\n" + 
				"        \"description\": \"New unique number has been stored\"\r\n" + 
				"    }\r\n" + 
				"}";
		
		JSONAssert.assertEquals(expected, gson.toJson(response), false);	
		
	}
	
	@Test
	public void testGetCustomerId() throws JSONException, TrustKeyValidationException {
		
		mockCustUniqueNumberRepository = new MockCustUniqueNumberRepository();
		
		String url = "https://virtserver.swaggerhub.com/jicunxi05/token_validation/1.0.0/crm-encrypt/p2/validateTrustKey";
		
		OracleServiceController oracleServiceController = new OracleServiceController(restTemplate, mockCustUniqueNumberRepository);
		oracleServiceController.authenticationServiceUrl = url;
		
		String mockedDefaultResponseData = "{\r\n" + 
				"  \"Header\": {\r\n" + 
				"    \"apId\": \"CRMLXCRM01\",\r\n" + 
				"    \"branchId\": 15,\r\n" + 
				"    \"employeeId\": 13063,\r\n" + 
				"    \"clientIp\": \"127.0.0.1\",\r\n" + 
				"    \"txnDateTime\": \"string\"\r\n" + 
				"  },\r\n" + 
				"  \"code\": \"0000\",\r\n" + 
				"  \"desc\": \"Success\",\r\n" + 
				"  \"trustKey\": \"db04b549-c602-40bc-ad4b-4500b61ee0c0-1525750484063\"\r\n" + 
				"}";

		MockRestServiceServer server = MockRestServiceServer.bindTo(restTemplate).build();
		
		server.expect(once(), requestTo(url)).andExpect(method(HttpMethod.POST))
		.andRespond(withSuccess(mockedDefaultResponseData, MediaType.APPLICATION_JSON));
		
		
		RetrieveCustomerIdRequest retrieveCustomerIdRequest = new RetrieveCustomerIdRequest();
		Header Header = new Header();
		
		Header.setApId("CRMLXCRM01");
		Header.setBranchId("15");
		Header.setEmployeeId("13063");
		Header.setClientIp("127.0.0.1");
		Header.setTxnDateTime("kahitanongdate");
		retrieveCustomerIdRequest.setUniqueNumber("111");
		retrieveCustomerIdRequest.setTrustKey("454");
		retrieveCustomerIdRequest.setHeader(Header);
	
		Object response = oracleServiceController.retrieveCustomerId(retrieveCustomerIdRequest);
		
		String expected = "{\"message\":\"Success\",\"body\":{\"customerId\":\"01\",\"description\":\"Customer ID was retrieved: 01\"}}";

		JSONAssert.assertEquals(expected, gson.toJson(response), false);	
		
}
}*/
package com.cathay.api.domain;

public class Constants {

	// Logging scope format
	public static final String LOGGER_START = "[START @{} ({})]";
	public static final String LOGGER_END = "[END @{} ({})]";

	// Response Code
	public static final String SUCCESS_CODE = "0000";
	public static final String ERROR_CODE = "1111";
	public static final String NO_DATA_CODE = "1001";
	public static final String DATA_INTEGRITY_CODE = "409";
	public static final String INSERT_ERROR_CODE = "500";
	public static final String UNIQUE_NUMBER_EXPIRED_CODE = "1003";
	public static final String UNIQUE_NUMBER_NOT_FOUND_CODE = "1004";

	// Response Message
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String ERROR_MESSAGE = "Error";

	// Origin or Source
	public static final String SOURCE = "Authentication API";

	// Store unique number
	public static final String STORE_UNIQUE_NUMBER_REQUEST = "Store unique number request: {}";
	public static final String STORE_UNIQUE_NUMBER_RESPONSE = "Store unique number response: {}";

	// Retrieve Customer Id
	public static final String RETRIEVE_CUSTOMER_ID_REQUEST = "Retrieve customer id request: {}";
	public static final String RETRIEVE_CUSTOMER_ID_RESPONSE = "Retrieve customer id response: {}";

	// Validate trust key
	public static final String VALIDATE_TRUST_KEY_REQUEST = "Validate trust key request: {}";
	public static final String VALIDATE_TRUST_KEY_RESPONSE = "Validate trust key response: {}";

	/** Error Description **/
	public static final String GENERIC_ERROR = "An error occured, please see log details";
	public static final String BAD_REQUEST = "Invalid arguments or Request parameters";
	public static final String TYPE_MISMATCH_ERROR = "Type mismatch error, please check your request parameters";
	public static final String DATA_INTEGRITY_VIOLATION_ERROR = "Data integrity error! Unique number might have already existed";
	public static final String UNIQUE_NUMBER_NOT_FOUND = "Unique number not found";
	public static final String UNIQUE_NUMBER_EXPIRED = "Unique number has expired";

	// Validate Trust Key
	public static final String VALIDATE_TRUST_KEY_HTTP_ERROR = "Error while validating trust key using this url %s";

	// Store unique number
	public static final String STORE_UNIQUE_NUMBER_FAILED = "Store unique number failed";

	private Constants() {
	}

}

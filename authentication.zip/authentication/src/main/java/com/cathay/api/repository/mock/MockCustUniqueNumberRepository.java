package com.cathay.api.repository.mock;

import com.cathay.api.domain.CustUniqueNumber;
import com.cathay.api.repository.CustUniqueNumberRepository;

public class MockCustUniqueNumberRepository implements CustUniqueNumberRepository {

	@Override
	public CustUniqueNumber findByUniqueNumber(String uniqueNumber) {
		CustUniqueNumber custUniqueNumber = new CustUniqueNumber();
		custUniqueNumber.setCustomerId("01");
		custUniqueNumber.setUniqueNumber("01");
		return custUniqueNumber;
	}

	@Override
	public <S extends CustUniqueNumber> S save(S entity) {
		return null;
	}

	@Override
	public <S extends CustUniqueNumber> Iterable<S> save(Iterable<S> entities) {
		return null;
	}

	@Override
	public CustUniqueNumber findOne(Long id) {
		return null;
	}

	@Override
	public boolean exists(Long id) {
		return false;
	}

	@Override
	public Iterable<CustUniqueNumber> findAll() {
		return null;
	}

	@Override
	public Iterable<CustUniqueNumber> findAll(Iterable<Long> ids) {
		return null;
	}

	@Override
	public long count() {
		return 0;
	}

	@Override
	public void delete(Long id) {
		// Do nothing because it's just a mock
	}

	@Override
	public void delete(CustUniqueNumber entity) {
		// Do nothing because it's just a mock
	}

	@Override
	public void delete(Iterable<? extends CustUniqueNumber> entities) {
		// Do nothing because it's just a mock
	}

	@Override
	public void deleteAll() {
		// Do nothing because it's just a mock
	}
}

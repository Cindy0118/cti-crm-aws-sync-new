package com.cathay.api.config;


import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.cathaybk.encrypt.Decrypter;

import oracle.ucp.jdbc.PoolDataSource;
import oracle.ucp.jdbc.PoolDataSourceFactory;
import oracle.ucp.jdbc.PoolDataSourceImpl;

@Configuration
public class DbConfig {
	private static final Logger LOGGER = LogManager.getLogger(DbConfig.class);
	
	@Value("${db.key}")
	private String dbKey;
	
	@Value("${db.file-name}")
	private String fileName;
	
	@Value("${db.max-pool-size}")
	private int maxPoolSize;
	
	@Value("${db.min-pool-size}")
	private int minPoolSize;
	
	@Value("${db.host1}")
	private String host1; 
	
	@Value("${db.host2}")
	private String host2; 
	
	@Value("${db.port1}")
	private String port1; 
	
	@Value("${db.port2}")
	private String port2;
	
	@Value("${db.service-name}")
	private String serviceName; 
	
	@ConfigurationProperties(prefix = "spring.datasource")
    @Bean
    @Profile({"prod"})
    public DataSource getProdPoolDataSource() throws Exception {
		LOGGER.info("Loading PROD database config...");
		String[] dbInfo = Decrypter.getPassword(fileName, dbKey);
		PoolDataSource pds = (PoolDataSourceImpl) PoolDataSourceFactory.getPoolDataSource();

        pds.setUser(dbInfo[0]);
        pds.setPassword(dbInfo[1]);
        pds.setURL("jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(LOAD_BALANCE=off)(FAILOVER=on)(ADDRESS=(PROTOCOL=TCP)(HOST=" + host1 + ")(PORT=" + port1 + "))(ADDRESS=(PROTOCOL=TCP)(HOST="+ host2 +")(PORT=" + port2 + ")))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=" + serviceName + ")))");
        pds.setConnectionFactoryClassName("oracle.jdbc.pool.OracleDataSource");
        pds.setFastConnectionFailoverEnabled(true);
        pds.setMinPoolSize(minPoolSize);
        pds.setMaxPoolSize(maxPoolSize); 
        pds.setValidateConnectionOnBorrow(true); 
        pds.setSQLForValidateConnection("select user from dual");

        return pds;
    }
	
    @Bean
    @Profile({"uat"})
    public DataSource getUatPoolDataSource() throws Exception {
		LOGGER.info("Loading PROD database config...");
		String[] dbInfo = Decrypter.getPassword(fileName, dbKey);
		PoolDataSource pds = (PoolDataSourceImpl) PoolDataSourceFactory.getPoolDataSource();
		
        pds.setUser(dbInfo[0]);
        pds.setPassword(dbInfo[1]);
        pds.setURL("jdbc:oracle:thin:@" + host1 + ":" + port1 + ":" + serviceName);
        pds.setConnectionFactoryClassName("oracle.jdbc.pool.OracleDataSource");
        pds.setFastConnectionFailoverEnabled(true);
        pds.setMinPoolSize(minPoolSize);
        pds.setMaxPoolSize(maxPoolSize); 
        pds.setValidateConnectionOnBorrow(true); 
        pds.setSQLForValidateConnection("select user from dual");

        return pds;
    }
}



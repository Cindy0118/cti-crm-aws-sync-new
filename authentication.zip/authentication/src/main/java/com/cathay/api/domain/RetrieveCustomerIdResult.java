package com.cathay.api.domain;

public class RetrieveCustomerIdResult {

	private String customerId;

	public RetrieveCustomerIdResult() {
	}

	public RetrieveCustomerIdResult(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return new StringBuilder("{customerId=" + customerId + "}").toString();
	}

}

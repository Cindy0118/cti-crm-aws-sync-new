package com.cathay.api.domain;

public class RetrieveCustomerIdResponse extends BaseResponse {

	private RetrieveCustomerIdResult result;

	public RetrieveCustomerIdResponse() {
	}

	public RetrieveCustomerIdResponse(RetrieveCustomerIdResult result) {
		super(Constants.SUCCESS_CODE);
		this.result = result;
	}

	public RetrieveCustomerIdResponse(String code, String description) {
		super(code, description);
	}

	@Override
	public RetrieveCustomerIdResult getResult() {
		return result;
	}

	public void setResult(RetrieveCustomerIdResult result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}

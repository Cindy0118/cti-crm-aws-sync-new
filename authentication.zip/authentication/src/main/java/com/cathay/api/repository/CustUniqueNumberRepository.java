package com.cathay.api.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cathay.api.domain.CustUniqueNumber;

public interface CustUniqueNumberRepository extends CrudRepository<CustUniqueNumber, Long>{
	
	@Query(nativeQuery=true)
	CustUniqueNumber findByUniqueNumber(String uniqueNumber);
}

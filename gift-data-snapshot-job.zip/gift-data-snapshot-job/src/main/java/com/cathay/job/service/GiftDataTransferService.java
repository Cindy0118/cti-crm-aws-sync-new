package com.cathay.job.service;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cathay.job.domain.GiftDetails;
import com.cathay.job.domain.GiftFile;
import com.cathay.job.repository.GiftDetailsRepository;
import com.cathay.job.repository.GiftFileRepository;

public class GiftDataTransferService {
	
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	private static final Logger LOGGER = LogManager.getLogger(GiftDataTransferService.class);
	
	private GiftDetailsRepository giftDetailsRepository;
	
	private GiftFileRepository giftFileRepository;
	
	public GiftDataTransferService(GiftDetailsRepository giftDetailsRepository, GiftFileRepository giftFileRepository){
		this.giftDetailsRepository = giftDetailsRepository;
		this.giftFileRepository = giftFileRepository;
	}

	public void save(List<GiftDetails> data, String fileName) {
		
		LOGGER.info(LOGGER_START, 
				this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());		
		
		//insert file to file history
		LOGGER.info("Started inserting on file history");
		GiftFile giftFile = giftFileRepository.save(new GiftFile(fileName));
		
			LOGGER.info("Successfully inserted on file history");
			if(giftFile != null) {
			for(GiftDetails giftDetails: data) {
				giftDetails.setFileSeqNo(giftFile.getSeqNo());
			}
			//insert file details
			LOGGER.info("Started inserting on file details");
			
			giftDetailsRepository.save(data);
			
			LOGGER.info("Successfully inserted on file details");
		} else {
			LOGGER.error("Failed inserting on file details");
		}
		LOGGER.info(LOGGER_END, 
				this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
	}
}

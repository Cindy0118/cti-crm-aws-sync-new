package com.cathay.job.repository;

import org.springframework.data.repository.CrudRepository;

import com.cathay.job.domain.GiftFile;

public interface GiftFileRepository extends CrudRepository<GiftFile, Long>{
	
}

package com.cathay.job;

import java.io.File;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.PropertySource;
import com.cathay.job.domain.GiftDetails;
import com.cathay.job.repository.GiftDetailsRepository;
import com.cathay.job.repository.GiftFileRepository;
import com.cathay.job.service.GiftDataRetrievalService;
import com.cathay.job.service.GiftDataTransferService;

@SpringBootApplication
@PropertySource("classpath:application.properties")
public class GiftDataTransferJobApplication {
	
	@Value("${data-location}")
	private String path;
	
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	
	private static final Logger LOGGER = LogManager.getLogger(GiftDataRetrievalService.class);
	
	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(GiftDataTransferJobApplication.class, args);
		GiftDataTransferJobApplication app = context.getBean(GiftDataTransferJobApplication.class);
       
		app.doJob(context);
	}
	
	public void doJob(ConfigurableApplicationContext context) {
		try {		
			LOGGER.info(LOGGER_START, 
					GiftDataRetrievalService.class.getSimpleName(),
					Thread.currentThread().getStackTrace()[1].getMethodName());	
	
		    GiftDetailsRepository giftDetailsRepository = (GiftDetailsRepository) context.getBeanFactory().getBean("giftDetailsRepository");
		    GiftFileRepository giftFileRepository = (GiftFileRepository) context.getBeanFactory().getBean("giftFileRepository");
			
			GiftDataRetrievalService giftDataRetrievalService = new GiftDataRetrievalService();
			GiftDataTransferService giftDataTransferService = new GiftDataTransferService(
					giftDetailsRepository, giftFileRepository);
			
			File file = new File(path);
			LOGGER.info("File to read: {}", path);
			
			String fileName = file.getName();
			
			LOGGER.info("Retrieving data from text file...");
			List<GiftDetails> data = giftDataRetrievalService.retrieveDataFromFile(file);
	
			if(data != null && !data.isEmpty()) {
				LOGGER.info("Number of records found: {}", data.size());
				giftDataTransferService.save(data, fileName);

			} else {
				LOGGER.info("File is empty.");
			}

			LOGGER.info(LOGGER_END, 
					GiftDataRetrievalService.class.getSimpleName(),
					Thread.currentThread().getStackTrace()[1].getMethodName());
			
		} catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
		} finally {
			context.close();	
		}
	}
}

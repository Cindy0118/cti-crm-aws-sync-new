package com.api.cub.mongoserviceapi.domain;

public class TransformedCaseForwardingContactInfo {
	private String apId;
	private Boolean bkcEmail;
	private Boolean bkcComTel;
	private Boolean bkcHomeTel;
	private Boolean bkcPhone;
	private Boolean bkcPermanentAddress;
	private Boolean bkcResidentialAddress;
	private Boolean ccEmail;
	private Boolean ccComTel;
	private Boolean ccHomeTel;
	private Boolean ccPhone;
	private Boolean ccPermanentAddress;
	private Boolean ccResidentialAddress;
	
	public String getApId() {
		return apId;
	}
	public void setApId(String apId) {
		this.apId = apId;
	}
	public Boolean getBkcEmail() {
		return bkcEmail;
	}
	public void setBkcEmail(Boolean bkcEmail) {
		this.bkcEmail = bkcEmail;
	}
	public Boolean getBkcComTel() {
		return bkcComTel;
	}
	public void setBkcComTel(Boolean bkcComTel) {
		this.bkcComTel = bkcComTel;
	}
	public Boolean getBkcHomeTel() {
		return bkcHomeTel;
	}
	public void setBkcHomeTel(Boolean bkcHomeTel) {
		this.bkcHomeTel = bkcHomeTel;
	}
	public Boolean getBkcPhone() {
		return bkcPhone;
	}
	public void setBkcPhone(Boolean bkcPhone) {
		this.bkcPhone = bkcPhone;
	}
	public Boolean getBkcPermanentAddress() {
		return bkcPermanentAddress;
	}
	public void setBkcPermanentAddress(Boolean bkcPermanentAddress) {
		this.bkcPermanentAddress = bkcPermanentAddress;
	}
	public Boolean getBkcResidentialAddress() {
		return bkcResidentialAddress;
	}
	public void setBkcResidentialAddress(Boolean bkcResidentialAddress) {
		this.bkcResidentialAddress = bkcResidentialAddress;
	}
	public Boolean getCcEmail() {
		return ccEmail;
	}
	public void setCcEmail(Boolean ccEmail) {
		this.ccEmail = ccEmail;
	}
	public Boolean getCcComTel() {
		return ccComTel;
	}
	public void setCcComTel(Boolean ccComTel) {
		this.ccComTel = ccComTel;
	}
	public Boolean getCcHomeTel() {
		return ccHomeTel;
	}
	public void setCcHomeTel(Boolean ccHomeTel) {
		this.ccHomeTel = ccHomeTel;
	}
	public Boolean getCcPhone() {
		return ccPhone;
	}
	public void setCcPhone(Boolean ccPhone) {
		this.ccPhone = ccPhone;
	}
	public Boolean getCcPermanentAddress() {
		return ccPermanentAddress;
	}
	public void setCcPermanentAddress(Boolean ccPermanentAddress) {
		this.ccPermanentAddress = ccPermanentAddress;
	}
	public Boolean getCcResidentialAddress() {
		return ccResidentialAddress;
	}
	public void setCcResidentialAddress(Boolean ccResidentialAddress) {
		this.ccResidentialAddress = ccResidentialAddress;
	}
	@Override
	public String toString() {
		return "TransformedCaseForwardingContactInfo [apId=" + apId + ", bkcEmail=" + bkcEmail + ", bkcComTel="
				+ bkcComTel + ", bkcHomeTel=" + bkcHomeTel + ", bkcPhone=" + bkcPhone + ", bkcPermanentAddress="
				+ bkcPermanentAddress + ", bkcResidentialAddress=" + bkcResidentialAddress + ", ccEmail=" + ccEmail
				+ ", ccComTel=" + ccComTel + ", ccHomeTel=" + ccHomeTel + ", ccPhone=" + ccPhone
				+ ", ccPermanentAddress=" + ccPermanentAddress + ", ccResidentialAddress=" + ccResidentialAddress + "]";
	}
}

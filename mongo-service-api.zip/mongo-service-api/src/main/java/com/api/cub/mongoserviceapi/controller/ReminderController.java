package com.api.cub.mongoserviceapi.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.api.cub.mongoserviceapi.domain.EncryptDataRequest;
import com.api.cub.mongoserviceapi.domain.EncryptDataResponse;
import com.api.cub.mongoserviceapi.domain.ParameterValidationResponse;
import com.api.cub.mongoserviceapi.domain.RequestTokenObject;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TokenValidator;
import com.api.cub.mongoserviceapi.domain.TransformedCardCampaigns;
import com.api.cub.mongoserviceapi.domain.TransformedReminder;
import com.api.cub.mongoserviceapi.helper.APIHelper;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.helper.LogServiceHelper;
import com.api.cub.mongoserviceapi.helper.ParameterValidator;
import com.api.cub.mongoserviceapi.service.EncryptedDataService;
import com.api.cub.mongoserviceapi.service.ReminderService;
import com.api.cub.mongoserviceapi.service.TokenValidatorService;

@CrossOrigin
@RestController
public class ReminderController {

	private static final Logger logger = LogManager.getLogger(ReminderController.class);
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	private static final String ERROR = "ERROR";
	private static final String CODE_ERROR = "1111";
	
	@Autowired
	TokenValidatorService tokenValidatorService;
	
	@Autowired
	ReminderService reminderService;
	
	@Autowired
	EncryptedDataService encryptedDataService;
	
	@GetMapping("/reminder")
	public ResponseObject<TransformedReminder> getReminder(@RequestParam(value = "ap_id") String apId,
			@RequestParam(value = "teller_id") String tellerId,	@RequestParam(value = "customer_id") String customerId,
			@RequestParam(value = "branch") String branch, @RequestParam(value = "token") String token) {
		
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		TokenValidator tokenResponse = new TokenValidator();
		ResponseObject<TransformedReminder> transformedReminderResponse = new ResponseObject<>();
		EncryptDataResponse encryptDataResponse = new EncryptDataResponse();
		EncryptDataRequest encryptedDataRequest = new EncryptDataRequest();
		
		try {
			logger.info("validating parameters");
			validResponse = ParameterValidator.validateParameters(apId, tellerId, customerId, branch, token);
			if (validResponse.isValidParams()) {
				RequestTokenObject requestTokenObject = APIHelper.requestObjectTokenBuilder(apId, tellerId, branch,
						token);
				logger.info("requestTokenObject: " + requestTokenObject.toString());
				tokenResponse = tokenValidatorService.validateToken(requestTokenObject);
				if (tokenResponse.isTokenValid()) {
					encryptedDataRequest = APIHelper.encryptDataRequestBuilder(apId, branch, tellerId, "127.0.0.1", customerId, encryptedDataService.getPlainDataType(customerId), token);
					logger.info("encryptedDataRequest: " + encryptedDataRequest.toString());
					encryptDataResponse = encryptedDataService.encryptData(encryptedDataRequest);
					logger.info("encryptDataResponse: " + encryptDataResponse.toString());
					transformedReminderResponse = reminderService.getReminder(encryptDataResponse.getEncrytedData(), apId);
				} else {
					transformedReminderResponse.setCode(tokenResponse.getCode());
					transformedReminderResponse.setMessage(ERROR);
					transformedReminderResponse.setDescription(tokenResponse.getErrorMessage());
					transformedReminderResponse.setSource("Mongo-API Validating Token ReminderController.java [method] getReminder()");
				}
			} else {
				transformedReminderResponse.setCode(validResponse.getCode());
				transformedReminderResponse.setMessage(ERROR);
				transformedReminderResponse.setDescription(validResponse.getErrorMessage());
				transformedReminderResponse.setSource("Mongo-API Validating Parameters ReminderController.java [method] getReminder()");
			}
		} catch (RestClientException e) {
			transformedReminderResponse.setCode(CODE_ERROR);
			transformedReminderResponse.setMessage(ERROR);
			transformedReminderResponse.setDescription("RestClientException occured during token validator in ReminderController.java");
			transformedReminderResponse.setSource("ReminderController.java [method] getReminder()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("RestClientException occured during token validator.", exceptionDetails.toString());
		} catch (Exception e) {
			transformedReminderResponse.setCode(CODE_ERROR);
			transformedReminderResponse.setMessage(ERROR);
			transformedReminderResponse.setDescription("Exception occured during token validator in ReminderController.java");
			transformedReminderResponse.setSource("ReminderController.java [method] getReminder()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("Exception occured during token validator. ", exceptionDetails.toString());
		}
		
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return transformedReminderResponse;
	}
	
	@GetMapping("/reminder/activities")
	public ResponseObject<List<TransformedCardCampaigns>> getReminderActivities(@RequestParam(value = "ap_id") String apId,
			@RequestParam(value = "teller_id") String tellerId, @RequestParam(value = "customer_id") String customerId,
			@RequestParam(value = "branch") String branch, @RequestParam(value = "token") String token) {
		
		ResponseObject<List<TransformedCardCampaigns>> transformedCardCampaignsResponse = new ResponseObject<>();
		
		logger.info("*START* {}", LogServiceHelper.getCurrentClassAndMethodName());
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		TokenValidator tokenResponse = new TokenValidator();
		EncryptDataResponse encryptDataResponse = new EncryptDataResponse();
		EncryptDataRequest encryptedDataRequest = new EncryptDataRequest();
		
		try {
			validResponse = ParameterValidator.validateParameters(apId, tellerId,
					customerId, branch, token);
			if (validResponse.isValidParams()) {
				RequestTokenObject requestTokenObject = APIHelper.requestObjectTokenBuilder(apId, tellerId, branch,
						token);
				logger.info("requestTokenObject: " + requestTokenObject.toString());
				tokenResponse = tokenValidatorService.validateToken(requestTokenObject);
				if (tokenResponse.isTokenValid()) {
					encryptedDataRequest = APIHelper.encryptDataRequestBuilder(apId, branch, tellerId, "127.0.0.1", customerId, encryptedDataService.getPlainDataType(customerId), token);
					logger.info("encryptedDataRequest: " + encryptedDataRequest.toString());
					encryptDataResponse = encryptedDataService.encryptData(encryptedDataRequest);
					logger.info("encryptDataResponse: " + encryptDataResponse.toString());
					transformedCardCampaignsResponse = reminderService.getReminderActivities(encryptDataResponse.getEncrytedData());
				} else {
					transformedCardCampaignsResponse.setCode(tokenResponse.getCode());
					transformedCardCampaignsResponse.setMessage(ERROR);
					transformedCardCampaignsResponse.setDescription(tokenResponse.getErrorMessage());
					transformedCardCampaignsResponse.setSource("Mongo-API Validating Token ReminderController.java [method] getReminderActivities()");
				}
			} else {
				transformedCardCampaignsResponse.setCode(validResponse.getCode());
				transformedCardCampaignsResponse.setMessage(ERROR);
				transformedCardCampaignsResponse.setDescription(validResponse.getErrorMessage());
				transformedCardCampaignsResponse.setSource("Mongo-API Validating Parameters ReminderController.java [method] getReminderActivities()");
			}
		} catch (RestClientException e) {
			transformedCardCampaignsResponse.setCode(CODE_ERROR);
			transformedCardCampaignsResponse.setMessage(ERROR);
			transformedCardCampaignsResponse.setDescription("RestClientException occured during token validator in ReminderController.java");
			transformedCardCampaignsResponse.setSource("ReminderController.java [method] getReminderActivities()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("RestClientException occured during token validator.", exceptionDetails.toString());
		} catch (Exception e) {
			transformedCardCampaignsResponse.setCode(CODE_ERROR);
			transformedCardCampaignsResponse.setMessage(ERROR);
			transformedCardCampaignsResponse.setDescription("Exception occured during token validator in ReminderController.java [method] getReminderActivities()");
			transformedCardCampaignsResponse.setSource("ReminderController.java [method] getReminderActivities()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("Exception occured during token validator. ", exceptionDetails.toString());
		}

		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return transformedCardCampaignsResponse;
	}
}

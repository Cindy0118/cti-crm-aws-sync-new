package com.api.cub.mongoserviceapi.domain;

public class TransformedEvent {
	private String channel;

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}
	
}

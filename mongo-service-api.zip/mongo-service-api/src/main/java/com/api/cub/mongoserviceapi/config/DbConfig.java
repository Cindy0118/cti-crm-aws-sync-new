package com.api.cub.mongoserviceapi.config;

import java.util.Arrays;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;

import com.cathaybk.encrypt.Decrypter;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

@Configuration
public class DbConfig extends AbstractMongoConfiguration {
	
	private static final Logger LOGGER = LogManager.getLogger(DbConfig.class);
	
	@Value("${db.fileName}")
    private String fileName;

    @Value("${db.key}")
    private String dbKey;

    @Value("${spring.data.mongodb.host}")
    private String mongoHost;

    @Value("${spring.data.mongodb.port}")
    private int mongoPort;

    @Value("${spring.data.mongodb.database}")
    private String mongoDB;

    @Profile({ "prod", "uat"})
    @Override
    @Bean
    @ConfigurationProperties(prefix = "spring.data")
    public Mongo mongo() throws Exception {
    	LOGGER.warn("Loading PRODUCTION database config...");
    	
    	String[] dbInfo = Decrypter.getPassword(fileName, dbKey);
   
    	MongoCredential credential = MongoCredential.createCredential(dbInfo[0], mongoDB, dbInfo[1].toCharArray());
    	return new MongoClient(new ServerAddress(mongoHost, mongoPort), Arrays.asList(credential));
    }
    
    @Override
    protected String getDatabaseName() {
    	return mongoDB;
    }
}



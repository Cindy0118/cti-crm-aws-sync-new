package com.api.cub.mongoserviceapi.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.api.cub.mongoserviceapi.domain.CaseForwarding;
import com.api.cub.mongoserviceapi.domain.CaseForwardingContactInfo;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TransformedCaseForwarding;
import com.api.cub.mongoserviceapi.domain.TransformedCaseForwardingContactInfo;
import com.api.cub.mongoserviceapi.helper.APIHelper;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.repository.CaseForwardingContactInfoMongoRepository;
import com.api.cub.mongoserviceapi.repository.CaseForwardingMongoRepository;

@Service
public class CaseForwardingService {
	private static final Logger logger = LogManager.getLogger(CustomerProfileService.class);
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	private static final String CODE_SUCCESS = "0000";
	private static final String CODE_ERROR = "1111";
	private static final String MESSAGE_SUCCESS = "SUCCESS";
	private static final String MESSAGE_ERROR = "ERROR";
	
	@Autowired
	CaseForwardingMongoRepository caseForwardingMongoRepository;
	
	@Autowired
	CaseForwardingContactInfoMongoRepository caseForwardingContactInfoMongoRepository;
		
	public ResponseObject<TransformedCaseForwarding> getCaseForwarding(String customerId, String apId){
		ResponseObject<TransformedCaseForwarding> transformedCaseForwardingResponse = new ResponseObject<>();
		CaseForwarding caseForwarding = new CaseForwarding();
		TransformedCaseForwarding transformedCaseForwarding = new TransformedCaseForwarding();
		
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		try {
			String highlyResponsive;
			String cpin;
			String locationInd;
			
			caseForwarding = caseForwardingMongoRepository.showCaseForwardingAndProductsRecommendation(customerId);
			
			if(caseForwarding != null) {
				logger.info("caseForwarding is: " + caseForwarding.toString());
				
				highlyResponsive = caseForwarding.getHighlyResponsive();
				cpin = caseForwarding.getCpin();
				locationInd = caseForwarding.getLocationInd();
				
				transformedCaseForwarding.setApId(apId);
				
				transformedCaseForwarding.setIsHighlyResponsive(caseForwardingGetFlag(highlyResponsive));
				transformedCaseForwarding.setCanSuggestCPIN(caseForwardingGetFlag(cpin));
				transformedCaseForwarding.setIsContactInformationCorrect(caseForwardingGetFlag(locationInd));
				
				transformedCaseForwardingResponse.setCode(CODE_SUCCESS);
				transformedCaseForwardingResponse.setMessage(MESSAGE_SUCCESS);
				transformedCaseForwardingResponse.setDescription("");
				transformedCaseForwardingResponse.setSource("");
				transformedCaseForwardingResponse.setResult(transformedCaseForwarding);
			}else {
				transformedCaseForwardingResponse.setCode("1001");
				transformedCaseForwardingResponse.setMessage(MESSAGE_SUCCESS);
				transformedCaseForwardingResponse.setDescription("No data was found for the Customer ID.");
				transformedCaseForwardingResponse.setSource("");
			}
		} catch (DataAccessException e) {
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			transformedCaseForwardingResponse.setCode(CODE_ERROR);
			transformedCaseForwardingResponse.setMessage(MESSAGE_ERROR);
			transformedCaseForwardingResponse.setDescription(exceptionDetails.getMessage());
			transformedCaseForwardingResponse.setSource("Mongo-API CaseForwardService.java [method]getCaseForwarding()");
			logger.error(exceptionDetails.toString());
		}
		
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return transformedCaseForwardingResponse;
	}
	
	public boolean caseForwardingGetFlag(String flag){
		boolean isFlag = false;
		if (flag != null && flag.equalsIgnoreCase("Y")) {
			isFlag = true;
		}
		return isFlag;
	}
	
	public ResponseObject<TransformedCaseForwardingContactInfo> getCaseForwardingContactInfo(String customerId, String apId) {
		ResponseObject<TransformedCaseForwardingContactInfo> transformedCaseForwardingContactInfoResponse = new ResponseObject<>();
		CaseForwardingContactInfo caseForwardingContactInfo = new CaseForwardingContactInfo();
		TransformedCaseForwardingContactInfo transformedCaseForwardingContactInfo = new TransformedCaseForwardingContactInfo();
		
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		try {
			String bkcCompanyPhoneFlag;
			String bkcEmailFlag;
			String bkcHomePhoneFlag;
			String bkcMobilePhoneFlag;
			String bkcRegisterAddressFlag;
			String bkcStatementAddressFlag;
			String ccCompanyPhoneFlag;
			String ccEmailFlag;
			String ccHomePhoneFlag;
			String ccMobilePhoneFlag;
			String ccRegisterAddressFlag;
			String ccStatementAddressFlag;
			
			caseForwardingContactInfo = caseForwardingContactInfoMongoRepository.showCaseForwardingContactInfo(customerId);
			
			if(caseForwardingContactInfo != null) {
				logger.info("caseForwardingContactInfo is: " + caseForwardingContactInfo.toString());
				bkcCompanyPhoneFlag = caseForwardingContactInfo.getBkcCompanyPhoneFlag();
				bkcEmailFlag = caseForwardingContactInfo.getBkcEmailFlag();
				bkcHomePhoneFlag = caseForwardingContactInfo.getBkcHomePhoneFlag();
				bkcMobilePhoneFlag = caseForwardingContactInfo.getBkcMobilePhoneFlag();
				bkcRegisterAddressFlag = caseForwardingContactInfo.getBkcRegisterAddressFlag();
				bkcStatementAddressFlag = caseForwardingContactInfo.getBkcStatementAddressFlag();
				ccCompanyPhoneFlag = caseForwardingContactInfo.getCcCompanyPhoneFlag();
				ccEmailFlag = caseForwardingContactInfo.getCcEmailFlag();
				ccHomePhoneFlag = caseForwardingContactInfo.getCcHomePhoneFlag();
				ccMobilePhoneFlag = caseForwardingContactInfo.getCcMobilePhoneFlag();
				ccRegisterAddressFlag = caseForwardingContactInfo.getCcRegisterAddressFlag();
				ccStatementAddressFlag = caseForwardingContactInfo.getCcStatementAddressFlag();
				
				transformedCaseForwardingContactInfo.setApId(apId);
				
				transformedCaseForwardingContactInfo.setBkcEmail(APIHelper.getFlag(bkcEmailFlag));
				transformedCaseForwardingContactInfo.setBkcComTel(APIHelper.getFlag(bkcCompanyPhoneFlag));
				transformedCaseForwardingContactInfo.setBkcHomeTel(APIHelper.getFlag(bkcHomePhoneFlag));
				transformedCaseForwardingContactInfo.setBkcPhone(APIHelper.getFlag(bkcMobilePhoneFlag));
				transformedCaseForwardingContactInfo.setBkcPermanentAddress(APIHelper.getFlag(bkcRegisterAddressFlag));
				transformedCaseForwardingContactInfo.setBkcResidentialAddress(APIHelper.getFlag(bkcStatementAddressFlag));
				transformedCaseForwardingContactInfo.setCcEmail(APIHelper.getFlag(ccEmailFlag));
				transformedCaseForwardingContactInfo.setCcComTel(APIHelper.getFlag(ccCompanyPhoneFlag));
				transformedCaseForwardingContactInfo.setCcHomeTel(APIHelper.getFlag(ccHomePhoneFlag));
				transformedCaseForwardingContactInfo.setCcPhone(APIHelper.getFlag(ccMobilePhoneFlag));
				transformedCaseForwardingContactInfo.setCcPermanentAddress(APIHelper.getFlag(ccRegisterAddressFlag));
				transformedCaseForwardingContactInfo.setCcResidentialAddress(APIHelper.getFlag(ccStatementAddressFlag));
			
				transformedCaseForwardingContactInfoResponse.setCode(CODE_SUCCESS);
				transformedCaseForwardingContactInfoResponse.setMessage(MESSAGE_SUCCESS);
				transformedCaseForwardingContactInfoResponse.setDescription("");
				transformedCaseForwardingContactInfoResponse.setSource("");
				transformedCaseForwardingContactInfoResponse.setResult(transformedCaseForwardingContactInfo);
			} else {
				transformedCaseForwardingContactInfoResponse.setCode("1001");
				transformedCaseForwardingContactInfoResponse.setMessage(MESSAGE_SUCCESS);
				transformedCaseForwardingContactInfoResponse.setDescription("No data was found for the Customer ID.");
				transformedCaseForwardingContactInfoResponse.setSource("");
			}
			
		} catch (DataAccessException e) {
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			transformedCaseForwardingContactInfoResponse.setCode(CODE_ERROR);
			transformedCaseForwardingContactInfoResponse.setMessage(MESSAGE_ERROR);
			transformedCaseForwardingContactInfoResponse.setDescription(exceptionDetails.getMessage());
			transformedCaseForwardingContactInfoResponse.setSource("Mongo-API CaseForwardService.java [method]getCaseForwardingContactInfo()");
			logger.error(exceptionDetails.toString());
		}
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return transformedCaseForwardingContactInfoResponse;
	}
}

package com.api.cub.mongoserviceapi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.api.cub.mongoserviceapi.domain.CaseForwardingContactInfo;

public interface CaseForwardingContactInfoMongoRepository extends MongoRepository<CaseForwardingContactInfo, String> {
	@Query(value="{'_id' : ?0}")
	CaseForwardingContactInfo showCaseForwardingContactInfo(String customerId);
}

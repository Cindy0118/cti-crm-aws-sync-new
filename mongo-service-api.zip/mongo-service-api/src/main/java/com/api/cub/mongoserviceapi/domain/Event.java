package com.api.cub.mongoserviceapi.domain;
public class Event {
	
	private String name;
	private String channel;
	private String time;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "Event [name=" + name + ", channel=" + channel + ", time=" + time + "]";
	}
	
}	

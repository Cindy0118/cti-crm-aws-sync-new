package com.api.cub.mongoserviceapi.domain;

public class JourneyDetailEvent {
	
	private String channel;
	private long time;
	private String detail;
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	@Override
	public String toString() {
		return "JourneyDetailEvent [channel=" + channel + ", time=" + time + ", detail=" + detail + "]";
	}
}

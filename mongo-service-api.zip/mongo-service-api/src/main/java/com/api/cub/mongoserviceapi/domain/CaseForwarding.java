package com.api.cub.mongoserviceapi.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="cti_crm")
public class CaseForwarding {
	@Id
	private String id;
	
	@Field("customer_id")
	private String customerId;
	
	@Field("highly_responsive")
	private String highlyResponsive;
	
	@Field("location_ind")
	private String locationInd;
	
	@Field("cpin")
	private String cpin;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getHighlyResponsive() {
		return highlyResponsive;
	}

	public void setHighlyResponsive(String highlyResponsive) {
		this.highlyResponsive = highlyResponsive;
	}

	public String getLocationInd() {
		return locationInd;
	}

	public void setLocationInd(String locationInd) {
		this.locationInd = locationInd;
	}

	public String getCpin() {
		return cpin;
	}

	public void setCpin(String cpin) {
		this.cpin = cpin;
	}

	@Override
	public String toString() {
		return "CaseForwarding [id=" + id + ", customerId=" + customerId + ", highlyResponsive=" + highlyResponsive
				+ ", locationInd=" + locationInd + ", cpin=" + cpin + "]";
	}
}

package com.api.cub.mongoserviceapi.service;

import java.util.Collections;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.api.cub.mongoserviceapi.domain.RequestTokenObject;
import com.api.cub.mongoserviceapi.domain.ResponseTokenObject;
import com.api.cub.mongoserviceapi.domain.TokenValidator;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.helper.LogServiceHelper;

@Service
public class TokenValidatorService {
	private static final Logger logger = LogManager.getLogger(TokenValidatorService.class);
	
	@Value("${validate.token.url}")
	private String validateTokenURL;
	
	public TokenValidator validateToken(RequestTokenObject requestToken){
		logger.info("*START* {}", LogServiceHelper.getCurrentClassAndMethodName());
		TokenValidator tokenValidator = new TokenValidator();
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		
		try {
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			
			HttpEntity<Object> requestBody = new HttpEntity<>(requestToken, headers);
			ResponseTokenObject responseToken = restTemplate.postForObject(validateTokenURL, requestBody, ResponseTokenObject.class);
			logger.info("responseToken is: " + responseToken.toString());
		if(responseToken.getCode().equalsIgnoreCase("0000")) {
				logger.info("Token was verified as valid.");
				tokenValidator.setCode(responseToken.getCode());
				tokenValidator.setTokenValid(true);
			}else if(responseToken.getCode().equalsIgnoreCase("1003")){
				tokenValidator.setCode(responseToken.getCode());
				tokenValidator.setErrorMessage("Token is expired.");
				logger.info("Token is expired.");
			}else if(responseToken.getCode().equalsIgnoreCase("1004")){
				tokenValidator.setCode(responseToken.getCode());
				tokenValidator.setErrorMessage("Token not found.");
				logger.info("Token not found.");
			}else if(responseToken.getCode().equalsIgnoreCase("1005")){
				tokenValidator.setCode(responseToken.getCode());
				tokenValidator.setErrorMessage("Token is not found or expired.");
				logger.info("Token is not found or expired.");
			}
		} catch (HttpClientErrorException e) {
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			tokenValidator.setErrorMessage("RestClientException occured during token validator.");
			logger.error("RestClientException occured during token validator. ", exceptionDetails.toString());
		}
		logger.info("*END* {}", LogServiceHelper.getCurrentClassAndMethodName());
		return tokenValidator;
	}

}

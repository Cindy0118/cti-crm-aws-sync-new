package com.api.cub.mongoserviceapi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.api.cub.mongoserviceapi.domain.CustomerProfile;

public interface CustomerProfileMongoRepository extends MongoRepository<CustomerProfile, String>{
	@Query(value="{'_id' : ?0}")
	CustomerProfile findCustomerProfileByCustomerId(String customerId);
}

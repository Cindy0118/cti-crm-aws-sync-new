package com.api.cub.mongoserviceapi.domain;

public class ResponseObject<T> {
	private String code;
	private String message;
	private String description;
	private String source;
	private Object result;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Object getResult() {
		return result;
	}
	public void setResult(Object result) {
		this.result = result;
	}
	@Override
	public String toString() {
		return "ResponseObject [code=" + code + ", message=" + message + ", description=" + description + ", source="
				+ source + ", result=" + result + "]";
	}
	
}

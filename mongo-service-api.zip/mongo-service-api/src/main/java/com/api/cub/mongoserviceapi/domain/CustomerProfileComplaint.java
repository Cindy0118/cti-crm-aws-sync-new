package com.api.cub.mongoserviceapi.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "cti_crm")
public class CustomerProfileComplaint {
	@Id
	private String id;
	
	@Field("start_call_date")
	private String startCallDate;
	
	@Field("start_call_time")
	private String startCallTime;
	
	@Field("detail_desc")
	private String detailDesc;
	
	public String getStartCallDate() {
		return startCallDate;
	}
	public void setStartCallDate(String startCallDate) {
		this.startCallDate = startCallDate;
	}
	public String getStartCallTime() {
		return startCallTime;
	}
	public void setStartCallTime(String startCallTime) {
		this.startCallTime = startCallTime;
	}
	public String getDetailDesc() {
		return detailDesc;
	}
	public void setDetailDesc(String detailDesc) {
		this.detailDesc = detailDesc;
	}
	@Override
	public String toString() {
		return "CustomerProfileComplaint [id=" + id + ", startCallDate=" + startCallDate + ", startCallTime="
				+ startCallTime + ", detailDesc=" + detailDesc + "]";
	}
	
	
}

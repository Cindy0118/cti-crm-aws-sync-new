package com.api.cub.mongoserviceapi.domain;

public class EncryptDataResponse {
	private Header header;
	private String code;
	private String desc;
	private String encrytedData;

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getEncrytedData() {
		return encrytedData;
	}

	public void setEncrytedData(String encrytedData) {
		this.encrytedData = encrytedData;
	}

	@Override
	public String toString() {
		return "EncryptDataResponse [header=" + header + ", code=" + code + ", desc=" + desc + ", encrytedData="
				+ encrytedData + "]";
	}
}

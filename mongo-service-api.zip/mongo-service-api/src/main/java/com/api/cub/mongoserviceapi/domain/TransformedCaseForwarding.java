package com.api.cub.mongoserviceapi.domain;


public class TransformedCaseForwarding {

	private String apId;
	private boolean isHighlyResponsive;
	private boolean canSuggestCPIN;
	private boolean isContactInformationCorrect;

	public String getApId() {
		return apId;
	}

	public void setApId(String apId) {
		this.apId = apId;
	}

	public boolean getIsHighlyResponsive() {
		return isHighlyResponsive;
	}

	public void setIsHighlyResponsive(boolean isHighlyResponsive) {
		this.isHighlyResponsive = isHighlyResponsive;
	}

	public boolean getCanSuggestCPIN() {
		return canSuggestCPIN;
	}

	public void setCanSuggestCPIN(boolean canSuggestCPIN) {
		this.canSuggestCPIN = canSuggestCPIN;
	}

	public boolean getIsContactInformationCorrect() {
		return isContactInformationCorrect;
	}

	public void setIsContactInformationCorrect(boolean isContactInformationCorrect) {
		this.isContactInformationCorrect = isContactInformationCorrect;
	}

	@Override
	public String toString() {
		return "TransformedCaseForwarding [apId=" + apId + ", isHighlyResponsive=" + isHighlyResponsive
				+ ", canSuggestCPIN=" + canSuggestCPIN + ", isContactInformationCorrect=" + isContactInformationCorrect
				+ "]";
	}
}

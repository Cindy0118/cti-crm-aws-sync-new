package com.api.cub.mongoserviceapi.domain;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "crm_journey")
public class CustomerJourney {
	@Id
	private String id;
	@Field("customer_id")
	private String customerId;
	@Field("time_slot")
	private List<TimeSlot> timeSlot;
	@Field("update_time")
	private long updateTime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public List<TimeSlot> getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(List<TimeSlot> timeSlot) {
		this.timeSlot = timeSlot;
	}

	public long getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(long updateTime) {
		this.updateTime = updateTime;
	}

	@Override
	public String toString() {
		return "CustomerJourney [id=" + id + ", customerId=" + customerId + ", timeSlot=" + timeSlot + ", updateTime="
				+ updateTime + "]";
	}

}

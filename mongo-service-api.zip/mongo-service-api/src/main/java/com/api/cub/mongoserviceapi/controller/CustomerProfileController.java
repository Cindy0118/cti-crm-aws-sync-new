package com.api.cub.mongoserviceapi.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.api.cub.mongoserviceapi.domain.EncryptDataRequest;
import com.api.cub.mongoserviceapi.domain.EncryptDataResponse;
import com.api.cub.mongoserviceapi.domain.ParameterValidationResponse;
import com.api.cub.mongoserviceapi.domain.RequestTokenObject;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TokenValidator;
import com.api.cub.mongoserviceapi.domain.TransformedCustomerProfile;
import com.api.cub.mongoserviceapi.domain.TransformedCustomerProfileComplaint;
import com.api.cub.mongoserviceapi.helper.APIHelper;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.helper.LogServiceHelper;
import com.api.cub.mongoserviceapi.helper.ParameterValidator;
import com.api.cub.mongoserviceapi.service.CustomerProfileService;
import com.api.cub.mongoserviceapi.service.EncryptedDataService;
import com.api.cub.mongoserviceapi.service.TokenValidatorService;

@CrossOrigin
@RestController
public class CustomerProfileController {
	
	private static final Logger logger = LogManager.getLogger(CustomerProfileController.class);
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	private static final String ERROR = "ERROR";
	private static final String CODE_ERROR = "1111";
	
	@Autowired
	TokenValidatorService tokenValidatorService;
	
	@Autowired
	CustomerProfileService customerProfileService;
	
	@Autowired
	EncryptedDataService encryptedDataService;
	
	@GetMapping("/profile")
	public ResponseObject<TransformedCustomerProfile> getCustomerProfile(@RequestParam(value = "ap_id") String apId,
			@RequestParam(value = "teller_id") String tellerId, @RequestParam(value = "customer_id") String customerId,
			@RequestParam(value = "branch") String branch, @RequestParam(value = "token") String token) {
		
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		TokenValidator tokenResponse = new TokenValidator();
		ResponseObject<TransformedCustomerProfile> transformedCustomerProfileResponse = new ResponseObject<>();
		EncryptDataResponse encryptDataResponse = new EncryptDataResponse();
		EncryptDataRequest encryptedDataRequest = new EncryptDataRequest();
		
		try {
			logger.info("validating parameters");
			validResponse = ParameterValidator.validateParameters(apId, tellerId, customerId, branch, token);
			if (validResponse.isValidParams()) {
				RequestTokenObject requestTokenObject = APIHelper.requestObjectTokenBuilder(apId, tellerId, branch,
						token);
				logger.info("requestTokenObject: " + requestTokenObject.toString());
				tokenResponse = tokenValidatorService.validateToken(requestTokenObject);
				if (tokenResponse.isTokenValid()) {
					encryptedDataRequest = APIHelper.encryptDataRequestBuilder(apId, branch, tellerId, "127.0.0.1", customerId, encryptedDataService.getPlainDataType(customerId), token);
					logger.info("encryptedDataRequest: " + encryptedDataRequest.toString());
					encryptDataResponse = encryptedDataService.encryptData(encryptedDataRequest);
					logger.info("encryptDataResponse: " + encryptDataResponse.toString());
					transformedCustomerProfileResponse = customerProfileService.getCustomerProfile(encryptDataResponse.getEncrytedData(), apId);
				}else {
					transformedCustomerProfileResponse.setCode(tokenResponse.getCode());
					transformedCustomerProfileResponse.setMessage(ERROR);
					transformedCustomerProfileResponse.setDescription(tokenResponse.getErrorMessage());
					transformedCustomerProfileResponse.setSource("Mongo-API Validating Token CustomerProfileController.java [method] getCustomerProfile()");
				}
			}else {
				transformedCustomerProfileResponse.setCode(validResponse.getCode());
				transformedCustomerProfileResponse.setMessage(ERROR);
				transformedCustomerProfileResponse.setDescription(validResponse.getErrorMessage());
				transformedCustomerProfileResponse.setSource("Mongo-API Validating Parameters CustomerProfileController.java [method] getCustomerProfile()");
			}
		} catch (RestClientException e) {
			transformedCustomerProfileResponse.setCode(CODE_ERROR);
			transformedCustomerProfileResponse.setMessage(ERROR);
			transformedCustomerProfileResponse.setDescription("RestClientException occured during token validator in CustomerProfileController.java");
			transformedCustomerProfileResponse.setSource("CustomerProfileController.java [method] getCustomerProfile()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("RestClientException occured during token validator.", exceptionDetails.toString());
		} catch (Exception e) {
			transformedCustomerProfileResponse.setCode(CODE_ERROR);
			transformedCustomerProfileResponse.setMessage(ERROR);
			transformedCustomerProfileResponse.setDescription("Exception occured during token validator in CustomerProfileController.java");
			transformedCustomerProfileResponse.setSource("CustomerProfileController.java [method] getCustomerProfile()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("Exception occured during token validator. ", exceptionDetails.toString());
		}
		
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return transformedCustomerProfileResponse;
	}
	
	@GetMapping("/profile/complaint")
	public ResponseObject<List<TransformedCustomerProfileComplaint>> getCustomerProfileComplaints(@RequestParam(value = "ap_id") String apId,
			@RequestParam(value = "teller_id") String tellerId, @RequestParam(value = "customer_id") String customerId,
			@RequestParam(value = "branch") String branch, @RequestParam(value = "token") String token) {
		
		ResponseObject<List<TransformedCustomerProfileComplaint>> transformedCustomerProfileComplaintResponse = new ResponseObject<>();
		logger.info("*START* {}", LogServiceHelper.getCurrentClassAndMethodName());
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		TokenValidator tokenResponse = new TokenValidator();
		EncryptDataResponse encryptDataResponse = new EncryptDataResponse();
		EncryptDataRequest encryptedDataRequest = new EncryptDataRequest();
		
		try {
			validResponse = ParameterValidator.validateParameters(apId, tellerId,
					customerId, branch, token);
			if (validResponse.isValidParams()) {
				RequestTokenObject requestTokenObject = APIHelper.requestObjectTokenBuilder(apId, tellerId, branch,
						token);
				logger.info("requestTokenObject: " + requestTokenObject.toString());
				tokenResponse = tokenValidatorService.validateToken(requestTokenObject);
				if (tokenResponse.isTokenValid()) {
					encryptedDataRequest = APIHelper.encryptDataRequestBuilder(apId, branch, tellerId, "127.0.0.1", customerId, encryptedDataService.getPlainDataType(customerId), token);
					logger.info("encryptedDataRequest: " + encryptedDataRequest.toString());
					encryptDataResponse = encryptedDataService.encryptData(encryptedDataRequest);
					logger.info("encryptDataResponse: " + encryptDataResponse.toString());
					transformedCustomerProfileComplaintResponse = customerProfileService.getCustomerProfileComplaints(encryptDataResponse.getEncrytedData());
				}else {
					transformedCustomerProfileComplaintResponse.setCode(tokenResponse.getCode());
					transformedCustomerProfileComplaintResponse.setMessage(ERROR);
					transformedCustomerProfileComplaintResponse.setDescription(tokenResponse.getErrorMessage());
					transformedCustomerProfileComplaintResponse.setSource("Mongo-API Validating Token CustomerProfileController.java [method] getCustomerProfileComplaints()");
				}
			} else {
				transformedCustomerProfileComplaintResponse.setCode(validResponse.getCode());
				transformedCustomerProfileComplaintResponse.setMessage(ERROR);
				transformedCustomerProfileComplaintResponse.setDescription(validResponse.getErrorMessage());
				transformedCustomerProfileComplaintResponse.setSource("Mongo-API Validating Parameters CustomerProfileController.java [method] getCustomerProfileComplaints()");
			}
		} catch (RestClientException e) {
			transformedCustomerProfileComplaintResponse.setCode(CODE_ERROR);
			transformedCustomerProfileComplaintResponse.setMessage(ERROR);
			transformedCustomerProfileComplaintResponse.setDescription("RestClientException occured during token validator in CustomerProfileController.java");
			transformedCustomerProfileComplaintResponse.setSource("CustomerProfileController.java [method] getCustomerProfileComplaints()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("RestClientException occured during token validator.", exceptionDetails.toString());
		} catch (Exception e) {
			transformedCustomerProfileComplaintResponse.setCode(CODE_ERROR);
			transformedCustomerProfileComplaintResponse.setMessage(ERROR);
			transformedCustomerProfileComplaintResponse.setDescription("Exception occured during token validator in CustomerProfileController.java [method] getCustomerProfileComplaints()");
			transformedCustomerProfileComplaintResponse.setSource("CustomerProfileController.java [method] getCustomerProfileComplaints()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("Exception occured during token validator. ", exceptionDetails.toString());
		}

		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return transformedCustomerProfileComplaintResponse;
	}
}

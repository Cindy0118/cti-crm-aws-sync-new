package com.api.cub.mongoserviceapi.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.api.cub.mongoserviceapi.domain.CardCampaigns;
import com.api.cub.mongoserviceapi.domain.Reminder;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TransformedCardCampaigns;
import com.api.cub.mongoserviceapi.domain.TransformedReminder;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.repository.ReminderMongoRepository;

@Service
public class ReminderService {
	private static final Logger logger = LogManager.getLogger(ReminderService.class);
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	private static final String CODE_SUCCESS = "0000";
	private static final String CODE_ERROR = "1111";
	private static final String CODE_NO_DATA = "1001";
	private static final String MESSAGE_SUCCESS = "SUCCESS";
	private static final String MESSAGE_ERROR = "ERROR";
	private static final String DESC_NO_DATA = "No records found";
	
	@Autowired
	ReminderMongoRepository reminderMongoRepository;
	
	public ResponseObject<TransformedReminder> getReminder(String customerId, String apId) {
		ResponseObject<TransformedReminder> transformedReminderResponse = new ResponseObject<>();
		Reminder reminder = new Reminder();
		TransformedReminder transformedReminder = new TransformedReminder();
		
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		try {
			reminder = reminderMongoRepository.showReminderByCustomerId(customerId);
			if(reminder != null && reminder.getCardCampaigns() != null) {
				logger.info("reminder is: " + reminder.toString());
				
				transformedReminder.setApId(apId);
				transformedReminder.setAnyActivities(isThereAnyActivities(reminder));
				transformedReminderResponse.setCode(CODE_SUCCESS);
				transformedReminderResponse.setMessage(MESSAGE_SUCCESS);
				transformedReminderResponse.setDescription("");
				transformedReminderResponse.setSource("");
				transformedReminderResponse.setResult(transformedReminder);
			} else {
				transformedReminderResponse.setCode(CODE_NO_DATA);
				transformedReminderResponse.setMessage(MESSAGE_ERROR);
				transformedReminderResponse.setDescription(DESC_NO_DATA);
				transformedReminderResponse.setSource("Mongo-API ReminderService.java [method]getReminder()");
			}
		} catch (DataAccessException e) {
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			transformedReminderResponse.setCode(CODE_ERROR);
			transformedReminderResponse.setMessage(MESSAGE_ERROR);
			transformedReminderResponse.setDescription(exceptionDetails.getMessage());
			transformedReminderResponse.setSource("Mongo-API ReminderService.java [method]getReminder()");
			logger.error(exceptionDetails.toString());
		}
		
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return transformedReminderResponse;
	}
	
	private boolean isThereAnyActivities(Reminder reminder) {
		boolean isTherAnyActivities = false;
		int cardCampaignsCount = reminder.getCardCampaigns().size();
		logger.info("cardCampaignsCount: " + cardCampaignsCount);
		if(cardCampaignsCount != 0) {
			isTherAnyActivities = true;
		}
		return isTherAnyActivities;
	}
	
	public ResponseObject<List<TransformedCardCampaigns>> getReminderActivities(String customerId) throws ParseException{
		ResponseObject<List<TransformedCardCampaigns>> reminderActivitiesResponse = new ResponseObject<>();
		Reminder reminder = new Reminder();
		
		try {
			reminder = reminderMongoRepository.showReminderByCustomerId(customerId);
			if(reminder != null) {
				logger.info("reminder is: " + reminder.toString());
				reminderActivitiesResponse.setCode(CODE_SUCCESS);
				reminderActivitiesResponse.setMessage(MESSAGE_SUCCESS);
				reminderActivitiesResponse.setDescription("");
				reminderActivitiesResponse.setSource("");
				reminderActivitiesResponse.setResult(convertResponseToActivitiesResult(reminder.getCardCampaigns()));
			} else {
				reminderActivitiesResponse.setCode(CODE_ERROR);
				reminderActivitiesResponse.setMessage(MESSAGE_ERROR);
				reminderActivitiesResponse.setDescription("Customer not found");
				reminderActivitiesResponse.setSource("Mongo-API ReminderService.java [method] getReminderActivities()");
			}
		} catch (DataAccessException e) {
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			reminderActivitiesResponse.setCode(CODE_ERROR);
			reminderActivitiesResponse.setMessage(MESSAGE_ERROR);
			reminderActivitiesResponse.setDescription(exceptionDetails.getMessage());
			reminderActivitiesResponse.setSource("Mongo-API ReminderService.java [method] getReminderActivities()");
			logger.error(exceptionDetails.toString());
		}
		
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return reminderActivitiesResponse;
	}
	
	private List<TransformedCardCampaigns> convertResponseToActivitiesResult(List<CardCampaigns> listCardCampaigns)throws ParseException {
		List<TransformedCardCampaigns> transformedCardCampaignsResponse = new ArrayList<>();
		for (CardCampaigns cardCampaigns : listCardCampaigns) {
			TransformedCardCampaigns transformedCardCampaigns = new TransformedCardCampaigns();
			transformedCardCampaigns.setActivity(cardCampaigns.getCampaignName());
			transformedCardCampaigns.setLink(cardCampaigns.getCampaignUrl());
			transformedCardCampaigns.setActiveCode(cardCampaigns.getActiveCode());
			transformedCardCampaignsResponse.add(transformedCardCampaigns);
		}
		return transformedCardCampaignsResponse;
	}
}

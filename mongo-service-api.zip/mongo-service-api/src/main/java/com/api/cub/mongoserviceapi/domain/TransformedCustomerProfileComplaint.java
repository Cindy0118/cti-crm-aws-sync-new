package com.api.cub.mongoserviceapi.domain;

public class TransformedCustomerProfileComplaint {
	private long dateTime;
	private String complaint;
	
	public long getDateTime() {
		return dateTime;
	}
	
	public void setDateTime(long dateTime) {
		this.dateTime = dateTime;
	}
	
	public String getComplaint() {
		return complaint;
	}
	
	public void setComplaint(String complaint) {
		this.complaint = complaint;
	}
	
	@Override
	public String toString() {
		return "TransformedCustomerProfileComplaint [dateTime=" + dateTime + ", complaint=" + complaint + "]";
	}
	
}

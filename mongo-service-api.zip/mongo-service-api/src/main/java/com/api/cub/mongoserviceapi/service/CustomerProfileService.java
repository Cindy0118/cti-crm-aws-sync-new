package com.api.cub.mongoserviceapi.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.api.cub.mongoserviceapi.domain.CustomerProfile;
import com.api.cub.mongoserviceapi.domain.CustomerProfileComplaint;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TransformedCustomerProfile;
import com.api.cub.mongoserviceapi.domain.TransformedCustomerProfileComplaint;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.repository.CustomerProfileMongoRepository;

@Service
public class CustomerProfileService {
	
	private static final Logger logger = LogManager.getLogger(CustomerProfileService.class);
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	private static final String CODE_SUCCESS = "0000";
	private static final String CODE_ERROR = "1111";
	private static final String CODE_NO_DATA = "1001";
	private static final String MESSAGE_SUCCESS = "SUCCESS";
	private static final String MESSAGE_ERROR = "ERROR";
	private static final String DESC_NO_DATA = "No records found";
	
	@Autowired
	CustomerProfileMongoRepository customerProfileRepo;
	
	@Value("${api.env}")
	private String apiEnv;
	
	public ResponseObject<TransformedCustomerProfile> getCustomerProfile(String customerId, String apId) throws ParseException{
		ResponseObject<TransformedCustomerProfile> transformedCustomerProfileResponse = new ResponseObject<>();
		CustomerProfile customerProfile = new CustomerProfile();
		TransformedCustomerProfile transformedCustomerProfile = new TransformedCustomerProfile();
		
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		try {
			int age;
			String birthDay;
			int birthMonth;
			customerProfile = customerProfileRepo.findCustomerProfileByCustomerId(customerId);
			if(customerProfile != null) {
				logger.info("customerProfile is: " + customerProfile.toString());
				transformedCustomerProfile.setApId(apId);
				age = (int) customerProfile.getAge();
				transformedCustomerProfile.setAge(age);
				birthDay = customerProfile.getBirthday();
				SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM-dd");
				Date date = parser.parse(birthDay);
				SimpleDateFormat formatter = new SimpleDateFormat("MM");
				birthMonth = Integer.parseInt(formatter.format(date));
				transformedCustomerProfile.setBirthMonth(birthMonth);
				
				if (customerProfile.getVipFlag() != null) {
					transformedCustomerProfile.setBankVip(customerProfile.getVipFlag());
				}
				
				if (customerProfile.getComplaint() != null) {
					transformedCustomerProfile.setComplaintCount(customerProfile.getComplaint().size());
				}
				
				transformedCustomerProfileResponse.setResult(transformedCustomerProfile);
				transformedCustomerProfileResponse.setCode(CODE_SUCCESS);
				transformedCustomerProfileResponse.setMessage(MESSAGE_SUCCESS);
				transformedCustomerProfileResponse.setDescription("");
				transformedCustomerProfileResponse.setSource("");
			} else {
				transformedCustomerProfileResponse.setCode(CODE_NO_DATA);
				transformedCustomerProfileResponse.setMessage(MESSAGE_ERROR);
				transformedCustomerProfileResponse.setDescription(DESC_NO_DATA);
				transformedCustomerProfileResponse.setSource("Mongo-API CustomerProfileService.java [method] getCustomerProfile()");
			}
		} catch(DataAccessException e) {
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			transformedCustomerProfileResponse.setCode(CODE_ERROR);
			transformedCustomerProfileResponse.setMessage(MESSAGE_ERROR);
			transformedCustomerProfileResponse.setDescription(exceptionDetails.getMessage());
			transformedCustomerProfileResponse.setSource("Mongo-API CustomerProfileService.java [method] getCustomerProfile()");
			logger.error(exceptionDetails.toString());
		}
		
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return transformedCustomerProfileResponse;
	}
	
	public ResponseObject<List<TransformedCustomerProfileComplaint>> getCustomerProfileComplaints(String customerId) throws ParseException {
		ResponseObject<List<TransformedCustomerProfileComplaint>> customerProfileComplaintResponse = new ResponseObject<>();
		CustomerProfile customerProfile = new CustomerProfile();
		
		try {
			customerProfile = customerProfileRepo.findCustomerProfileByCustomerId(customerId);
			if(customerProfile != null) {
				logger.info("customerProfile is: " + customerProfile.toString());
				customerProfileComplaintResponse.setCode(CODE_SUCCESS);
				customerProfileComplaintResponse.setMessage(MESSAGE_SUCCESS);
				customerProfileComplaintResponse.setDescription("");
				customerProfileComplaintResponse.setSource("");
				if (customerProfile.getComplaint() != null) {
					customerProfileComplaintResponse.setResult(convertResponseToComplaintResult(customerProfile.getComplaint()));
				} else {
					customerProfileComplaintResponse.setResult(new ArrayList<TransformedCustomerProfileComplaint>());
				}
			} else {
				customerProfileComplaintResponse.setCode(CODE_NO_DATA);
				customerProfileComplaintResponse.setMessage(MESSAGE_ERROR);
				customerProfileComplaintResponse.setDescription(DESC_NO_DATA);
				customerProfileComplaintResponse.setSource("Mongo-API CustomerProfileService.java [method] getCustomerProfileComplaints getCustomerJourneyDetails()");
			}
		} catch (DataAccessException e) {
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			customerProfileComplaintResponse.setCode(CODE_ERROR);
			customerProfileComplaintResponse.setMessage(MESSAGE_ERROR);
			customerProfileComplaintResponse.setDescription(exceptionDetails.getMessage());
			customerProfileComplaintResponse.setSource("Mongo-API CustomerProfileService.java [method] getCustomerProfileComplaintsgetCustomerJourneyDetails()");
			logger.error(exceptionDetails.toString());
		}
		
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return customerProfileComplaintResponse;
	}
	
	private List<TransformedCustomerProfileComplaint> convertResponseToComplaintResult(List<CustomerProfileComplaint> listCustomerProfileComplaint)throws ParseException {
		List<TransformedCustomerProfileComplaint> transformedCustomerProfileComplaintResponse = new ArrayList<>();
		for (CustomerProfileComplaint customerProfileComplaint : listCustomerProfileComplaint) {
			TransformedCustomerProfileComplaint transformedCustomerProfileComplaint = new TransformedCustomerProfileComplaint();
			String dateTime = customerProfileComplaint.getStartCallDate() + " " + customerProfileComplaint.getStartCallTime();
			logger.info("dateTime: " + dateTime);
			SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date newDate = dateFormatter.parse(dateTime);
			long date = (newDate.getTime() / 1000);
			logger.info("date: " + date);
			transformedCustomerProfileComplaint.setDateTime(date);
			transformedCustomerProfileComplaint.setComplaint(customerProfileComplaint.getDetailDesc());
			transformedCustomerProfileComplaintResponse.add(transformedCustomerProfileComplaint);
		}
		return transformedCustomerProfileComplaintResponse;
	}
}

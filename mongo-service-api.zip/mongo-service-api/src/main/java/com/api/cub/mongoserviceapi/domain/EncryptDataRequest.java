package com.api.cub.mongoserviceapi.domain;

public class EncryptDataRequest {
	private Header header;
	private String plainData;
	private String plainDataType;
	private String trustKey;

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getPlainData() {
		return plainData;
	}

	public void setPlainData(String plainData) {
		this.plainData = plainData;
	}

	public String getPlainDataType() {
		return plainDataType;
	}

	public void setPlainDataType(String plainDataType) {
		this.plainDataType = plainDataType;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return "EncryptDataRequest [header=" + header + ", plainData=" + plainData + ", plainDataType=" + plainDataType
				+ ", trustKey=" + trustKey + "]";
	}
}

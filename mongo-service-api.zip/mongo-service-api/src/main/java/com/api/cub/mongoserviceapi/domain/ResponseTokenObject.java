package com.api.cub.mongoserviceapi.domain;

public class ResponseTokenObject {
	private Header header;
	private String code;
	private String desc;
	private String trustKey;

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return "ResponseTokenObject [header=" + header + ", code=" + code + ", desc=" + desc + ", trustKey=" + trustKey
				+ "]";
	}

}

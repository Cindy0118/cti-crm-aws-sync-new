package com.api.cub.mongoserviceapi.domain;

import java.util.List;

public class TimeSlot {
	private long date;
	private List<Event> events;
	public long getDate() {
		return date;
	}
	public void setDate(long date) {
		this.date = date;
	}
	public List<Event> getEvents() {
		return events;
	}
	public void setEvents(List<Event> events) {
		this.events = events;
	}
	@Override
	public String toString() {
		return "TimeSlot [date=" + date + ", events=" + events + "]";
	}
}

package com.api.cub.mongoserviceapi.domain;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
@Document(collection="cti_crm")
public class CustomerProfile {
	@Id
	private String id;
	
	@Field("customer_id")
	private String customerId;
	
	@Field("age")
	private float age;
	
	@Field("birthday")
	private String birthday;
	
	@Field("vip_flag")
	private String vipFlag;
	
	@Field("complaint")
	private List<CustomerProfileComplaint> complaint;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getVipFlag() {
		return vipFlag;
	}
	public void setVipFlag(String vipFlag) {
		this.vipFlag = vipFlag;
	}
	public List<CustomerProfileComplaint> getComplaint() {
		return complaint;
	}
	public void setComplaint(List<CustomerProfileComplaint> complaint) {
		this.complaint = complaint;
	}
	@Override
	public String toString() {
		return "CustomerProfile [id=" + id + ", customerId=" + customerId + ", age=" + age + ", birthday="
				+ birthday + ", vipFlag=" + vipFlag +", complaint=" + complaint +"]";
	}
}

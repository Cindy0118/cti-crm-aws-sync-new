package com.api.cub.mongoserviceapi.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "cti_crm")
public class CaseForwardingContactInfo {
	@Id
	private String id;

	@Field("bkc_company_phone_flag")
	private String bkcCompanyPhoneFlag;

	@Field("bkc_email_flag")
	private String bkcEmailFlag;

	@Field("bkc_home_phone_flag")
	private String bkcHomePhoneFlag;

	@Field("bkc_mobile_phone_flag")
	private String bkcMobilePhoneFlag;

	@Field("bkc_register_address_flag")
	private String bkcRegisterAddressFlag;

	@Field("bkc_statement_address_flag")
	private String bkcStatementAddressFlag;

	@Field("cc_company_phone_flag")
	private String ccCompanyPhoneFlag;

	@Field("cc_email_flag")
	private String ccEmailFlag;

	@Field("cc_home_phone_flag")
	private String ccHomePhoneFlag;

	@Field("cc_mobile_phone_flag")
	private String ccMobilePhoneFlag;

	@Field("cc_register_address_flag")
	private String ccRegisterAddressFlag;

	@Field("cc_statement_address_flag")
	private String ccStatementAddressFlag;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBkcCompanyPhoneFlag() {
		return bkcCompanyPhoneFlag;
	}

	public void setBkcCompanyPhoneFlag(String bkcCompanyPhoneFlag) {
		this.bkcCompanyPhoneFlag = bkcCompanyPhoneFlag;
	}

	public String getBkcEmailFlag() {
		return bkcEmailFlag;
	}

	public void setBkcEmailFlag(String bkcEmailFlag) {
		this.bkcEmailFlag = bkcEmailFlag;
	}

	public String getBkcHomePhoneFlag() {
		return bkcHomePhoneFlag;
	}

	public void setBkcHomePhoneFlag(String bkcHomePhoneFlag) {
		this.bkcHomePhoneFlag = bkcHomePhoneFlag;
	}

	public String getBkcMobilePhoneFlag() {
		return bkcMobilePhoneFlag;
	}

	public void setBkcMobilePhoneFlag(String bkcMobilePhoneFlag) {
		this.bkcMobilePhoneFlag = bkcMobilePhoneFlag;
	}

	public String getBkcRegisterAddressFlag() {
		return bkcRegisterAddressFlag;
	}

	public void setBkcRegisterAddressFlag(String bkcRegisterAddressFlag) {
		this.bkcRegisterAddressFlag = bkcRegisterAddressFlag;
	}

	public String getBkcStatementAddressFlag() {
		return bkcStatementAddressFlag;
	}

	public void setBkcStatementAddressFlag(String bkcStatementAddressFlag) {
		this.bkcStatementAddressFlag = bkcStatementAddressFlag;
	}

	public String getCcCompanyPhoneFlag() {
		return ccCompanyPhoneFlag;
	}

	public void setCcCompanyPhoneFlag(String ccCompanyPhoneFlag) {
		this.ccCompanyPhoneFlag = ccCompanyPhoneFlag;
	}

	public String getCcEmailFlag() {
		return ccEmailFlag;
	}

	public void setCcEmailFlag(String ccEmailFlag) {
		this.ccEmailFlag = ccEmailFlag;
	}

	public String getCcHomePhoneFlag() {
		return ccHomePhoneFlag;
	}

	public void setCcHomePhoneFlag(String ccHomePhoneFlag) {
		this.ccHomePhoneFlag = ccHomePhoneFlag;
	}

	public String getCcMobilePhoneFlag() {
		return ccMobilePhoneFlag;
	}

	public void setCcMobilePhoneFlag(String ccMobilePhoneFlag) {
		this.ccMobilePhoneFlag = ccMobilePhoneFlag;
	}

	public String getCcRegisterAddressFlag() {
		return ccRegisterAddressFlag;
	}

	public void setCcRegisterAddressFlag(String ccRegisterAddressFlag) {
		this.ccRegisterAddressFlag = ccRegisterAddressFlag;
	}

	public String getCcStatementAddressFlag() {
		return ccStatementAddressFlag;
	}

	public void setCcStatementAddressFlag(String ccStatementAddressFlag) {
		this.ccStatementAddressFlag = ccStatementAddressFlag;
	}

	@Override
	public String toString() {
		return "CaseForwardingContactInfo [id=" + id + ", bkcCompanyPhoneFlag=" + bkcCompanyPhoneFlag
				+ ", bkcEmailFlag=" + bkcEmailFlag + ", bkcHomePhoneFlag=" + bkcHomePhoneFlag + ", bkcMobilePhoneFlag="
				+ bkcMobilePhoneFlag + ", bkcRegisterAddressFlag=" + bkcRegisterAddressFlag
				+ ", bkcStatementAddressFlag=" + bkcStatementAddressFlag + ", ccCompanyPhoneFlag=" + ccCompanyPhoneFlag
				+ ", ccEmailFlag=" + ccEmailFlag + ", ccHomePhoneFlag=" + ccHomePhoneFlag + ", ccMobilePhoneFlag="
				+ ccMobilePhoneFlag + ", ccRegisterAddressFlag=" + ccRegisterAddressFlag + ", ccStatementAddressFlag="
				+ ccStatementAddressFlag + "]";
	}
}

package com.api.cub.mongoserviceapi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.api.cub.mongoserviceapi.domain.ProblemPrediction;

public interface ProblemPredictionMongoRepository extends MongoRepository<ProblemPrediction, String> {
	@Query(value="{'_id' : ?0}")
	ProblemPrediction showProblemPredictionByCustomerId(String customerId);
}

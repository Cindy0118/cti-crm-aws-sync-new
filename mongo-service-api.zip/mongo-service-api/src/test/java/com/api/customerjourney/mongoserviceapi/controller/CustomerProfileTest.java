package com.api.customerjourney.mongoserviceapi.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.api.cub.mongoserviceapi.controller.CustomerProfileController;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TransformedCustomerProfile;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=CustomerProfileTest.class)
@WebMvcTest(value = CustomerProfileController.class, secure = false)
public class CustomerProfileTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private CustomerProfileController mockCustomerProfileController;
	
	@Test
	public void testGetCustomerProfileResponse() throws Exception {
		Mockito.when(mockCustomerProfileController.getCustomerProfile(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getMockCustomerProfileData());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/profile")
				.accept(MediaType.APPLICATION_JSON).param("ap_id", "CRMLXCRM01").param("teller_id", "13063").param("token", "token")
				.param("branch", "branch1").param("customer_id", "A123456789");
		MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
		
		ObjectMapper mapper =  new ObjectMapper();
		String expectedResult = mapper.writeValueAsString(getMockCustomerProfileData());
		String actualResult = mvcResult.getResponse().getContentAsString();
		JSONAssert.assertEquals(expectedResult, actualResult, false);
	}
	
	public ResponseObject<TransformedCustomerProfile> getMockCustomerProfileData() {
		ResponseObject<TransformedCustomerProfile> customerProfileResponse = new ResponseObject<>();
		customerProfileResponse.setCode("0000");
		customerProfileResponse.setMessage("SUCCESS");
		customerProfileResponse.setDescription("");
		customerProfileResponse.setSource("");
		TransformedCustomerProfile mockTransformedCustomerProfile = new TransformedCustomerProfile();
		mockTransformedCustomerProfile.setApId("CRMLXCRM01");
		mockTransformedCustomerProfile.setAge(18);
		mockTransformedCustomerProfile.setBirthMonth(5);
		mockTransformedCustomerProfile.setBankVip("V");
		mockTransformedCustomerProfile.setComplaintCount(0);
		customerProfileResponse.setResult(mockTransformedCustomerProfile);
		return customerProfileResponse;
	}
}

package com.api.customerjourney.mongoserviceapi.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.api.cub.mongoserviceapi.controller.CaseForwardingController;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TransformedCaseForwarding;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=CaseForwardingTest.class)
@WebMvcTest(value = CaseForwardingController.class, secure = false)
public class CaseForwardingTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private CaseForwardingController mockCaseForwardingController;
	
	@Test
	public void testGetCaseForwardingResponse() throws Exception {
		Mockito.when(mockCaseForwardingController.getCaseForwarding(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getMockCaseForwardingData());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/case_forwarding")
				.accept(MediaType.APPLICATION_JSON).param("ap_id", "CRMLXCRM01").param("teller_id", "13063").param("token", "token")
				.param("branch", "branch1").param("customer_id", "A123456789");
		MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
		
		ObjectMapper mapper =  new ObjectMapper();
		String expectedResult = mapper.writeValueAsString(getMockCaseForwardingData());
		String actualResult = mvcResult.getResponse().getContentAsString();
		JSONAssert.assertEquals(expectedResult, actualResult, false);
	}
	
	public ResponseObject<TransformedCaseForwarding> getMockCaseForwardingData() {
		ResponseObject<TransformedCaseForwarding> caseForwardingResponse = new ResponseObject<>();
		caseForwardingResponse.setCode("0000");
		caseForwardingResponse.setMessage("SUCCESS");
		caseForwardingResponse.setDescription("");
		caseForwardingResponse.setSource("");
		TransformedCaseForwarding mockTransformedCaseForwarding = new TransformedCaseForwarding();
		mockTransformedCaseForwarding.setApId("SOMEAPID");
		mockTransformedCaseForwarding.setCanSuggestCPIN(true);
		mockTransformedCaseForwarding.setIsContactInformationCorrect(false);
		mockTransformedCaseForwarding.setIsHighlyResponsive(true);
		caseForwardingResponse.setResult(mockTransformedCaseForwarding);
		
		return caseForwardingResponse;
	}
}

import React, { Component } from "react";
import { Segment, Button, Header, Dimmer, Loader } from "semantic-ui-react";
import {
  getRemindersAnyActivities,
  getRemindersPoints,
  getRemindersFlag
} from "../service/Reminder";
import AutoAccountDebitingFailureModal from "../components/modals/Reminders/AutoAccountDebitingFailureModal";
import PointsExpirationModal from "../components/modals/Reminders/PointsExpirationModal";
import NewCreditCardCustomerWelcomeGiftModal from "../components/modals/Reminders/NewCreditCardCustomerWelcomeGiftModal";
import RecommendationModal from "../components/modals/Reminders/RecommendationModal";
import classes from "../assets/css/Reminder.css";
import Constants from "../constants/Common";

class Reminder extends Component {
  state = {
    mongoResult: null,
    oracleResult: null,
    odsResult: null,
    errors: {
      mongo: null,
      oracle: null,
      ods: null
    },
    loading: true
  };

  handleRetry = async (retry = false) => {
    if (retry) {
      this.setState({ loading: true });
    }

    const [mongoResponse, oracleResponse, odsResponse] = await Promise.all([
      getRemindersAnyActivities(),
      getRemindersPoints(),
      getRemindersFlag()
    ]);

    setTimeout(() => {
      if (
        mongoResponse.status === Constants.SUCCESS_STATUS &&
        mongoResponse.data.code === Constants.SUCCESS_CODE &&
        oracleResponse.status === Constants.SUCCESS_STATUS &&
        oracleResponse.data.code === Constants.SUCCESS_CODE &&
        odsResponse.status === Constants.SUCCESS_STATUS &&
        odsResponse.data.code === Constants.SUCCESS_CODE
      ) {
        this.setState({
          mongoResult: mongoResponse.data.result,
          oracleResult: oracleResponse.data.result,
          odsResult: odsResponse.data.result,
          loading: false
        });
      } else {
        this.setState({
          mongoResult: !!mongoResponse.data
            ? mongoResponse.data.code !== Constants.SUCCESS_CODE
              ? mongoResponse.data.code
              : mongoResponse.data.result
            : Constants.ERROR_CODE,
          oracleResult: !!oracleResponse.data
            ? oracleResponse.data.code !== Constants.SUCCESS_CODE
              ? oracleResponse.data.code
              : oracleResponse.data.result
            : Constants.ERROR_CODE,
          odsResult: !!odsResponse.data
            ? odsResponse.data.code !== Constants.SUCCESS_CODE
              ? odsResponse.data.code
              : odsResponse.data.result
            : Constants.ERROR_CODE,
          loading: false
        });
      }
    }, retry ? Constants.RETRY_INTERVAL : 0);
  };

  componentDidMount() {
    this.handleRetry();
  }

  displayAutoAccountDebitingFailure() {
    let content = null;
    let autoPayFailCnt = !!this.state.oracleResult
      ? this.state.oracleResult.autoPayFailCnt
      : 0;
    let autoPayRmbFailCnt = !!this.state.oracleResult
      ? this.state.oracleResult.autoPayRmbFailCnt
      : 0;
    let autoPayUsaFailCnt = !!this.state.oracleResult
      ? this.state.oracleResult.autoPayUsaFailCnt
      : 0;

    if (autoPayFailCnt > 0 || autoPayRmbFailCnt > 0 || autoPayUsaFailCnt > 0) {
      content = (
        <AutoAccountDebitingFailureModal autoPayFailCnt={autoPayFailCnt} />
      );
    }
    return content;
  }

  displayPointsExpiration() {
    let content = null;
    let y1AsianExpireMiles = !!this.state.oracleResult
      ? this.state.oracleResult.y1AsianExpireMiles
      : 0;
    let clearedCostcoBonusBal = !!this.state.oracleResult
      ? this.state.oracleResult.clearedCostcoBonusBal
      : 0;
    let platinumNextMonExpirePs = !!this.state.oracleResult
      ? this.state.oracleResult.platinumNextMonExpirePs
      : 0;
    let generalNextMonExpirePs = !!this.state.oracleResult
      ? this.state.oracleResult.generalNextMonExpirePs
      : 0;
    let y1EvaExpireMiles = !!this.state.oracleResult
      ? this.state.oracleResult.y1EvaExpireMiles
      : 0;
    const currentMonth = new Date();
    const month = currentMonth.getMonth() + 1;

    if (
      y1AsianExpireMiles > 0 ||
      (clearedCostcoBonusBal > 0 &&
        (month === 8 || month === 9 || month === 10)) ||
      platinumNextMonExpirePs > 0 ||
      generalNextMonExpirePs > 0
    ) {
      content = (
        <PointsExpirationModal
          y1AsianExpireMiles={y1AsianExpireMiles}
          clearedCostcoBonusBal={clearedCostcoBonusBal}
          platinumNextMonExpirePs={platinumNextMonExpirePs}
          generalNextMonExpirePs={generalNextMonExpirePs}
          y1EvaExpireMiles={y1EvaExpireMiles}
        />
      );
    }
    return content;
  }

  displayNewCustomerWelcomeGift() {
    let content = null;
    let fflag = !!this.state.odsResult ? this.state.odsResult.fflag : "N";
    if (fflag === "Y") {
      content = <NewCreditCardCustomerWelcomeGiftModal />;
    }
    return content;
  }

  displayPromotionCampaign() {
    let content = null;
    let anyActivities =
      this.state.mongoResult && this.state.mongoResult.anyActivities;
    if (anyActivities) {
      content = <RecommendationModal />;
    }
    return content;
  }

  displayNoData() {
    return (
      <Header
        style={{ marginTop: "50px" }}
        textAlign="center"
        content="無資料"
        className="noData"
      />
    );
  }

  getErrorCode(source, code) {
    switch (source) {
      case "mongo":
        return `(Error: MNG-${code})`;

      case "oracle":
        return `(Error: ORC-${code})`;

      case "ods":
        return `(Error: ODS-${code})`;

      default:
        return null;
    }
  }

  displayError() {
    const temp = {
      mongo: this.state.mongoResult,
      oracle: this.state.oracleResult,
      ods: this.state.odsResult
    };

    const errors = Object.keys(temp)
      .filter(
        k => typeof temp[k] === "string" && temp[k] !== Constants.NO_DATA_CODE
      )
      .map(k => ({
        [k]: temp[k]
      }))
      .reduce((acc, curr) => {
        const key = Object.keys(curr)[0];
        return { ...acc, [key]: temp[key] };
      }, {});

    return (
      <div>
        {Object.keys(errors).map((source, index) => (
          <p key={index} style={{ color: "grey", fontSize: 10 }}>
            {this.getErrorCode(source, errors[source])}
          </p>
        ))}
      </div>
    );
  }

  render() {
    const { loading, mongoResult, oracleResult, odsResult } = this.state;
    let content = null;
    let showNoData = false;

    const validate = [mongoResult, oracleResult, odsResult].every(
      item =>
        item === null ||
        typeof item === "object" ||
        item === Constants.NO_DATA_CODE
    );

    const validateAllDataSourceError = [
      mongoResult,
      oracleResult,
      odsResult
    ].every(
      item =>
        !!item &&
        (typeof item === "string" || item instanceof String) &&
        item !== Constants.NO_DATA_CODE
    );

    if (validate) {
      showNoData = [
        this.displayAutoAccountDebitingFailure(),
        this.displayPointsExpiration(),
        this.displayNewCustomerWelcomeGift(),
        this.displayPromotionCampaign()
      ].every(item => item === null);
      content =
        !loading && showNoData ? (
          <div>{this.displayNoData()}</div>
        ) : (
          <div className={classes.buttonsContainer}>
            {this.displayAutoAccountDebitingFailure()}
            {this.displayPointsExpiration()}
            {this.displayNewCustomerWelcomeGift()}
            {this.displayPromotionCampaign()}
          </div>
        );
    } else {
      content = !loading ? (
        <div className="btnRetryContainer">
          <Header
            as="h3"
            content={Constants.SERVICE_UNAVAILABLE}
            className="serviceUnavailable"
          />
          {!validateAllDataSourceError && this.displayError()}
          <Button
            onClick={() => this.handleRetry(true)}
            disabled={loading}
            content={Constants.RETRY}
            size="large"
          />
        </div>
      ) : null;
    }

    return (
      <Segment className="segment reminderContainerHeight">
        {loading ? (
          <Dimmer active>
            <Loader content="Loading" />
          </Dimmer>
        ) : null}
        <div className="segmentHeader">貼心提醒</div>
        <div>{content}</div>
        {!loading &&
          validate &&
          !showNoData && (
            <div className={classes.bottomTextStyle}>
              長榮哩程到期提醒～施工中！
            </div>
          )}
      </Segment>
    );
  }
}
export default Reminder;

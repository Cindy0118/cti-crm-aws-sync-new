package com.cathay.service.utility;

import org.springframework.http.HttpStatus;

public class Helper {

	private Helper() {
		super();
	}

	public static String getHttpStatusCode(Throwable e) {
		String code;

		if (e.getMessage().equals("404 Not Found")) {
			code = String.valueOf(HttpStatus.NOT_FOUND.value());
		} else if (e.getMessage().equals("400 Bad Request")) {
			code = String.valueOf(HttpStatus.BAD_REQUEST.value());
		} else {
			code = String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value());
		}

		return code;
	}

	public static String getHttpStatusDescription(Throwable e, String url) {
		String description;

		if (e.getMessage().equals("404 Not Found")) {
			description = new StringBuilder(HttpStatus.NOT_FOUND.getReasonPhrase() + ", " + url).toString();
		} else if (e.getMessage().equals("400 Bad Request")) {
			description = new StringBuilder(HttpStatus.BAD_REQUEST.getReasonPhrase() + ", " + url).toString();
		} else {
			description = new StringBuilder(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase() + ", " + url).toString();
		}

		return description;
	}

}

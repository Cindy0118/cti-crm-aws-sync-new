package com.cathay.service.domain;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class GetTrustKeyRequest {

	@NotBlank
	@Size(max = 10)
	private String apId;
	@NotBlank
	private String branchId;
	@NotBlank
	private String employeeId;
	private String clientIp;
	@NotBlank
	@Size(max = 18)
	private String customerId;

	public GetTrustKeyRequest() {
		super();
	}

	public String getApId() {
		return apId;
	}

	public void setApId(String apId) {
		this.apId = apId;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return new StringBuilder("{apId=" + apId + ", branchId=" + branchId + ", employeeId=" + employeeId
				+ ", clientIp=" + clientIp + ", customerId=" + customerId + "}").toString();
	}

}

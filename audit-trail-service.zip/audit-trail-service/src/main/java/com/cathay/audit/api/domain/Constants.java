package com.cathay.audit.api.domain;

public class Constants {


	// Logging scope format
	public static final String LOGGER_START = "[START @{} ({})]";
	public static final String LOGGER_END = "[END @{} ({})]";

	// Logger Error with parameter
	public static final String LOGGER_INVALID_TRUSTKEY = "Invalid trustkey: {}";
	public static final String LOGGER_REST_CLIENT_ERROR = "Error connecting to authentication service: {}";
	public static final String LOGGER_ILLEGAL_ARGUMENT_ERROR = "An error occured while validating trust key: {}";

	// Response Code
	public static final String SUCCESS_CODE = "0000";
	public static final String ERROR_CODE = "1111";

	// Response Message
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String ERROR_MESSAGE = "Error";

	// Origin or Source
	public static final String SOURCE = "Oracle API";

	
	
	/** Error Description **/
	public static final String GENERIC_ERROR = "An error occured, please see log details";
	public static final String DATA_ACCESS_ERROR = "Data access error, there is a problem encountered with the database";
	public static final String BAD_REQUEST = "Invalid argument / request parameters";
	public static final String TYPE_MISMATCH_ERROR = "Type mismatch error, please check you request parameters";

	// Trust Key
	public static final String INVALID_TRUSTKEY = "Invalid trustkey";
	public static final String REST_CLIENT_ERROR = "Error connecting to token validation url, {}";
	public static final String ILLEGAL_ARGUMENT_ERROR = "An error occured while validating trust key";

	// Customer profile and Financial products
	public static final String CUSTOMER_NOT_FOUND = "Customer not found";
	public static final String CUSTOMER_GREETINGS_SAVE_UNSUCCESSFUL = "Saving customer greetings failed. Please check your parameters";

	// Reminders
	public static final String CAMPAIGN_NOT_FOUND = "Campaign Code is not found";

	
	
	//Query Indicator and Records not found
	public static final String QUERY_INDICATOR_NOT_FOUND = "Query indicator not found";
	public static final String RECORDS_NOT_FOUND = "Records not found";
		
	// Product Recommendation
	public static final String PRODUCT_RECOMMENDATION_SAVE_UNSUCCESSFUL = "Saving product recommendation failed. Please check your parameters";
	public static final String PITCH_CLASSIFY_NOT_FOUND = "Pitch Classification not found";
	
	// Audit Trail
	public static final String APP_AUDIT_TRAIL_SAVE_UNSUCCESSFUL = "Saving app audit trail failed.";
	public static final String USER_AUDIT_TRAIL_SAVE_UNSUCCESSFUL = "Saving user audit trail failed.";
	public static final String AUDIT_TRAIL_GENERIC_ERROR = "Save audit trail encountered an error.";
	/** Error Description **/

	
	
	/** Info Message **/
	// Trust Key
	public static final String VALIDATING_TRUSTKEY = "Validating trust key: {}";
	public static final String VALIDATION_RESPONSE = "Trust key validation response: {}";

	// Customer profile
	public static final String CUSTOMER_PROFILE_REQUEST = "Get customer profile request: {}";
	public static final String CUSTOMER_PROFILE_RESPONSE = "Get customer profile response: {}";
	public static final String CUSTOMER_GREETINGS_REQUEST = "Customer greetings request: {}";
	public static final String CUSTOMER_GREETINGS_RESPONSE = "Customer greetings response: {}";
	
	// Reminders
	public static final String REMINDERS_REQUEST = "Get Reminders Gift Details request: {}";
	public static final String REMINDERS_RESPONSE = "Get Reminders Gift Details response: {}";

	// Primary cards
	public static final String PRIMARY_CARDS_REQUEST = "Get primary cards request: {}";
	public static final String PRIMARY_CARDS_RESPONSE = "Get primary cards response: {}";
	
	// Secondary cards
	public static final String SECONDARY_CARDS_REQUEST = "Get secondary cards request: {}";
	public static final String SECONDARY_CARDS_RESPONSE = "Get secondary cards response: {}";
		
	// Business cards
	public static final String BUSINESS_CARDS_REQUEST = "Get business cards request: {}";
	public static final String BUSINESS_CARDS_RESPONSE = "Get business cards response: {}";
		
	// Primary Has Secondary cards
	public static final String PRIMARY_HAS_SECONDARY_CARDS_REQUEST = "Get primary has secondary cards request: {}";
	public static final String PRIMARY_HAS_SECONDARY_CARDS_RESPONSE = "Get primary has secondary cards response: {}";
	
	// Payment Habits
	public static final String PAYMENT_HABITS_REQUEST = "Get payment habits request: {}";
	public static final String PAYMENT_HABITS_RESPONSE = "Get payment habits response: {}";
	
	// Auto Account Debiting
	public static final String AUTO_ACCOUNT_DEBITING_REQUEST = "Get auto account debiting request: {}";
	public static final String AUTO_ACCOUNT_DEBITING_RESPONSE = "Get auto account debiting response: {}";
	
	// Utility Bills Payment
	public static final String UTILITY_BILLS_PAYMENT_REQUEST = "Get utility bills payment request: {}";
	public static final String UTILITY_BILLS_PAYMENT_RESPONSE = "Get utility bills payment response: {}";
	
	// Savings
	public static final String SAVINGS_REQUEST = "Get savings request: {}";
	public static final String SAVINGS_RESPONSE = "Get savings response: {}";
		
	// Financial products
	public static final String FINANCIAL_PRODUCTS_REQUEST = "Get customer financial products request: {}";
	public static final String FINANCIAL_PRODUCTS_RESPONSE = "Get customer financial products response: {}";
	
	// Product Recommendation
	public static final String STORE_PRODUCT_RECOMMENDATION_REQUEST = "Store customer financial products request: {}";
	public static final String STORE_PRODUCT_RECOMMENDATION_RESPONSE = "Store customer financial products response: {}";
	public static final String RETRIEVE_PRODUCT_PITCH_REQUEST = "Retrieve product pitch request: {}";
	public static final String RETRIEVE_PRODUCT_PITCH_RESPONSE = "Retrieve product pitch response: {}";
	public static final String GET_LOW_MARKETING_REQUEST = "Get low marketing request: {}";
	public static final String GET_LOW_MARKETING_RESPONSE = "Get low marketing response: {}";
	public static final String PLOAN = "PLOAN";
	
	//Audit Trail
	public static final String SAVE_AUDIT_TRAIL_REQUEST = "Save audit trail request: {}";
	public static final String SAVE_APP_AUDIT_TRAIL_RESPONSE = "Save app audit trail response: {}";
	public static final String SAVE_USER_AUDIT_TRAIL_RESPONSE = "Save user audit trail response: {}";
	public static final String APP_AUDIT_TRAIL_DESTINATION = "appAuditTrailDestination";
	public static final String USER_AUDIT_TRAIL_DESTINATION = "userAuditTrailDestination";
	/** Info Message **/
	
	private Constants() {
	}


}

package com.cathay.audit.api.repository;

import org.springframework.data.repository.CrudRepository;

import com.cathay.audit.api.domain.AppAuditTrail;

public interface AppAuditTrailRepository extends CrudRepository<AppAuditTrail, Long>{

}

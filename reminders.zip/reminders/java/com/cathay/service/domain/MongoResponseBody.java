package com.cathay.service.domain;

public class MongoResponseBody {
	private boolean anyActivities;

	public boolean anyActivities() {
		return anyActivities;
	}

	public void setAnyActivities(boolean anyActivities) {
		this.anyActivities = anyActivities;
	}

	@Override
	public String toString() {
		return "MongoResponse [anyActivities=" + anyActivities + "]";
	}
}

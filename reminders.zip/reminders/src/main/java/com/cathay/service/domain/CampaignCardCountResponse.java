package com.cathay.service.domain;

public class CampaignCardCountResponse extends BaseResponse{
	private CampaignCardCountBody result;

	public CampaignCardCountBody getResult() {
		return result;
	}

	public void setResult(CampaignCardCountBody result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "CampaignCardCountResponse [result=" + result + "]";
	}
}

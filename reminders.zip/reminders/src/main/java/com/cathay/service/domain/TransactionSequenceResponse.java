package com.cathay.service.domain;

public class TransactionSequenceResponse extends BaseResponse {
	private TransactionSequenceBody result;

	public TransactionSequenceBody getResult() {
		return result;
	}

	public void setResult(TransactionSequenceBody result) {
		this.result = result;
	}
}

package com.cathay.service.domain;

public class CampaignCountRequest {
	private Header header;
	private String campaignCode;
	private String trustKey;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}
	public String getTrustKey() {
		return trustKey;
	}
	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}
	@Override
	public String toString() {
		return "CampaignCountRequest [header=" + header + ", campaignCode=" + campaignCode + ", trustKey=" + trustKey
				+ "]";
	}
	
}

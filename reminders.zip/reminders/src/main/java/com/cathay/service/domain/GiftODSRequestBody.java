package com.cathay.service.domain;

public class GiftODSRequestBody extends ODSRequestBody{
	private String transactionSequence;

	public String getTransactionSequence() {
		return transactionSequence;
	}

	public void setTransactionSequence(String transactionSequence) {
		this.transactionSequence = transactionSequence;
	}

	@Override
	public String toString() {
		return "GiftODSRequestBody [transactionSequence=" + transactionSequence + "]";
	}
}

package com.cathay.service.domain;

public class RetrieveCustomerIdResponseBody {
	private String customerId;
	
	public RetrieveCustomerIdResponseBody() {
		super();
	}
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "RetrieveCustomerIdResponseBody [customerId=" + customerId + "]";
	}
}

package com.cathay.service.domain;

public class TransactionSequenceBody {
	
	private long currentSequence;

	public long getCurrentSequence() {
		return currentSequence;
	}

	public void setCurrentSequence(long currentSequence) {
		this.currentSequence = currentSequence;
	}
}

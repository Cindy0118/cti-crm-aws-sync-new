package com.cathay.service.utility;

public class TransactionSequenceFormatUtility {
	
	private TransactionSequenceFormatUtility() {}
	
	public static String format(long num, int size) {
		
		String numStr = Long.toString(num);
		
		StringBuilder sb = new StringBuilder();
		
		for(int i=0; i<size-numStr.length(); i++){ //the 4 is the number of digits you want. adjust accordingly
			sb.append("0");
		}
		sb.append(numStr);
		
		return sb.toString();
	}
}

package com.cathay.service.domain;

public class RemindersResponseResult extends BaseResponse{
	private RemindersResponseBody result;

	public RemindersResponseBody getResult() {
		return result;
	}

	public void setResult(RemindersResponseBody result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "RemindersResponseResult [result=" + result + "]";
	}
	
}

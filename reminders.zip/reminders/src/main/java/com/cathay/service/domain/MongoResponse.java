package com.cathay.service.domain;

public class MongoResponse extends BaseResponse{
	private MongoResponseBody result;

	public MongoResponseBody getResult() {
		return result;
	}

	public void setResult(MongoResponseBody result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "MongoResponse [result=" + result + "]";
	}
	
}

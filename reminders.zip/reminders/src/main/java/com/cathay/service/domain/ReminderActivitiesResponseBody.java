package com.cathay.service.domain;

public class ReminderActivitiesResponseBody {
	private String activity;
	private String link;
	private String activeCode;

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getActiveCode() {
		return activeCode;
	}

	public void setActiveCode(String activeCode) {
		this.activeCode = activeCode;
	}

	@Override
	public String toString() {
		return "ReminderActivitiesResponseBody [activity=" + activity + ", link=" + link + ", activeCode=" + activeCode
				+ "]";
	}
	
}

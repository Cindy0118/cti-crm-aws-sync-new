package com.cathay.service.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {
	@Bean
    @Autowired
    @Qualifier("restTemplate")
    public RestTemplate restTemplate() {
      return new RestTemplate();
    }
    
    @Bean
    @Autowired
    @Qualifier("customerIdRetrievalRestTemplate")
    public RestTemplate customerIdRetrievalRestTemplate() {
        return new RestTemplate();
      }
}

package com.cathay.service.domain;

public class Reminder2ndLayerRequestBody extends ReminderRequestBody{
	private String category;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Reminder2ndLayerRequestBody [category=" + category + "]";
	}
	
}

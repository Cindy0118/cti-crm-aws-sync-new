package com.cathay.service.domain;

public class AuditTrailResponse {
	private String code;
	private String message;
	private String description;
	private String source;
	private Object result;

	public AuditTrailResponse() {
		super();
	}

	public AuditTrailResponse(String code, String message) {
		super();
		this.code = code;
		this.message = message;
		this.description = "";
		this.source = "";
		this.result = null;
	}

	public AuditTrailResponse(String code, String message, String description, String source) {
		super();
		this.code = code;
		this.message = message;
		this.description = description;
		this.source = source;
		result = null;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "AuditTrailResponse [code=" + code + ", message=" + message + ", description=" + description
				+ ", source=" + source + ", result=" + result + "]";
	}
	
	
}

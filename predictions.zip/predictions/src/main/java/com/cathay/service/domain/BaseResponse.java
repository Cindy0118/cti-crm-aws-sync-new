package com.cathay.service.domain;

public class BaseResponse {

	private String code;
	private String message;
	private String description;
	private String source;
	private Object result;

	public BaseResponse() {
	}

	public BaseResponse(String code, String description) {
		this.code = code;
		message = Constants.ERROR_MESSAGE;
		this.description = description;
		source = Constants.SOURCE;
	}

	public BaseResponse(String code, String message, String description, String source) {
		this.code = code;
		this.message = message;
		this.description = description;
		this.source = source;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + code + ", message=" + message + ", description=" + description + ", source="
				+ source + ", result=" + result + "}").toString();
	}

}

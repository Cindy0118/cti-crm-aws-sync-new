package com.cathay.service.domain;

public class RetrieveCustomerIdResult {

	private String customerId;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

}
